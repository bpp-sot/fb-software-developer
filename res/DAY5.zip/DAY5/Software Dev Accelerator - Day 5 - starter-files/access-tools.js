function isAdult(age) {
  if (age >= 18) {
    return true;
  } else {
    return false;
  }
}

function isVerified(status) {
  if (status === true) {
    return true;
  } else {
    return false;
  }
}

let adultCheck = isAdult(22);
let verifiedCheck = isVerified(false);

console.log(adultCheck);
console.log(verifiedCheck);

// Your task: trace both functions, then run the file and change one call to see what happens
// First: predict what isAdult(22) and isVerified(false) each return
// Second: run the file and confirm the two printed lines match your prediction
// Third: change isVerified(false) to isVerified(true) and run it again
// Each printed line should clearly show true or false for its matching function