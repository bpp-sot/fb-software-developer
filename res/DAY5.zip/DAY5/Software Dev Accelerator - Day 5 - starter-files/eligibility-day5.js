function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let personOne = isEligible(30, true);
let personTwo = isEligible(17, true);
let personThree = isEligible(45, false);

console.log(personOne);
console.log(personTwo);
console.log(personThree);

// Your task: predict every line this file prints, then change one call and check again
// First: write down what personOne, personTwo and personThree will each print
// Second: run the file and confirm your predictions
// Third: change isEligible(17, true) to isEligible(19, true) and run it again
// Each printed line should clearly show true or false for its matching person