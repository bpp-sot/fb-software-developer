function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let result = isEligible(22, true);
console.log(result);

// Your task: trace the returned value through this file, then change one value and observe
// First: predict what isEligible(22, true) returns and what result will hold
// Second: run the file and confirm result prints true
// Third: change the call to isEligible(16, true) and run it again
// Each run should print a clear true or false value based on the returned result