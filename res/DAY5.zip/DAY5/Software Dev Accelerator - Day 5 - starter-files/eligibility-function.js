function checkEligibility(age, verified) {
  if (age >= 18 && verified === true) {
    console.log("Eligible");
  } else {
    console.log("Not eligible");
  }
}

checkEligibility(22, true);
checkEligibility(16, true);
checkEligibility(40, false);

// Your task: run this file and then change one value to see how reuse works
// First: run the file and read the three printed lines
// Second: change the first call from 22 to 15
// Third: run it again and compare the new output with the old output
// Each printed line should clearly show Eligible or Not eligible for its matching call