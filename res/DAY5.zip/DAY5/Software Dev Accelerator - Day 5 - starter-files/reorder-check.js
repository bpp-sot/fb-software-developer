function needsReorder(stockLevel, reorderPoint) {
  if (stockLevel < reorderPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnMilk = needsReorder(3, 10);
console.log(lowOnMilk);

// Your task: predict what this file prints before you run it
// First: work out what needsReorder(3, 10) returns
// Second: work out what lowOnMilk then holds
// Third: work out what console.log(lowOnMilk) will print
// Each prediction should state a clear true or false value