// Your task: extend the loop below to print a third property from each learner
// First: read the existing loop and predict what the two console.log lines will print
// Second: add a third console.log inside the loop to also print verified
// Third: run the file and check your output matches your prediction
// Each learner should have their name, score, and verified value printed clearly

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

for (let i = 0; i < learners.length; i++) {
  console.log(learners[i].name);
  console.log(learners[i].score);
}