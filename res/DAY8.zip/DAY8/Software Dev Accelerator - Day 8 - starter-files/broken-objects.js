// Your task: fix the two bugs in this loop so the count and collected array are correct
// First: move the counter declaration to before the loop
// Second: move the push statement inside the if block
// Third: run the file and check the count and the collected array are now correct
// Each fix should result in an accurate count and a lowStock array with only matching products

let products = [
  { name: "Nitrile gloves S", category: "PPE", stockLevel: 14 },
  { name: "Cotton bandages", category: "consumables", stockLevel: 55 },
  { name: "Insulin vials", category: "pharmacy", stockLevel: 6 },
  { name: "Thermometer digital", category: "equipment", stockLevel: 30 },
  { name: "Face shields", category: "PPE", stockLevel: 9 },
  { name: "Gauze pads", category: "consumables", stockLevel: 18 }
];

let lowStock = [];

for (let i = 0; i < products.length; i++) {
  let count = 0;
  if (products[i].stockLevel < 20) {
    count = count + 1;
  }
  lowStock.push(products[i]);
}

console.log(count);