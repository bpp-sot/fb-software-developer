// Your task: write a loop that flags high-value transactions
// First: read the existing array below
// Second: write a for loop that reads each transaction object
// Third: inside the loop, add an if statement: if amount is above 5000, set flagged to true
// Fourth: after the loop, log the flagged value for each transaction to check your work
// Each transaction over 5000 should print true and each other transaction should print false

let transactions = [
  { reference: "TXN-101", customerName: "Freya Lindqvist", amount: 2200, flagged: false },
  { reference: "TXN-102", customerName: "Ben Okafor", amount: 6100, flagged: false },
  { reference: "TXN-103", customerName: "Anya Petrov", amount: 480, flagged: false },
  { reference: "TXN-104", customerName: "Chidi Nwosu", amount: 9800, flagged: false },
  { reference: "TXN-105", customerName: "Laura Kim", amount: 3050, flagged: false },
  { reference: "TXN-106", customerName: "Omar Farouk", amount: 15200, flagged: false }
];