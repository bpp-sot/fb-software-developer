// Your task: add a conditional update inside the loop that flags low-scoring records
// First: read the existing array and loop below
// Second: inside the loop, add an if statement checking whether score is below 65
// Third: if the condition is true, set that object's flagged property to true
// Fourth: after the loop, log the flagged value for each object to check your work
// Each flagged record should print true and each unflagged record should print false

let patients = [
  { name: "Helen Wren", score: 58, flagged: false },
  { name: "Marcus Reid", score: 72, flagged: false },
  { name: "Ola Adeyemi", score: 61, flagged: false },
  { name: "Sian Blake", score: 89, flagged: false },
  { name: "Tomasz Nowak", score: 45, flagged: false }
];

for (let i = 0; i < patients.length; i++) {

}