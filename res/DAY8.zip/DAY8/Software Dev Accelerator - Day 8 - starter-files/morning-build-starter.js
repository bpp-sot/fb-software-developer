// Your task: build a loop that updates each learner's passed status and prints a report
// First: write a for loop that reads each learner in the array
// Second: inside the loop, set passed to true if score is 65 or above
// Third: inside the loop, print a line naming the learner and whether they passed
// Each learner should have a clear, human-readable line printed to the console

let learners = [
  { name: "Priya", score: 82, passed: false },
  { name: "Marcus", score: 58, passed: false },
  { name: "Leila", score: 74, passed: false },
  { name: "Tom", score: 63, passed: false },
  { name: "Yuki", score: 91, passed: false }
];