// Your task: build a stock report that updates, counts, and collects low-stock products
// First: write a for loop that checks each product's stockLevel
// Second: inside the loop, set reorderNeeded to true if stockLevel is below 20
// Third: inside the loop, increment the counter and push the product to the reorderList
// Fourth: after the loop, print the count and each product name in the reorderList
// Each low-stock product should be flagged, counted, and listed in the final report

let products = [
  { name: "Paracetamol 500mg", category: "pharmacy",
    stockLevel: 12, reorderNeeded: false },
  { name: "Vinyl gloves M", category: "PPE",
    stockLevel: 45, reorderNeeded: false },
  { name: "Saline solution", category: "pharmacy",
    stockLevel: 8, reorderNeeded: false },
  { name: "Alcohol wipes", category: "PPE",
    stockLevel: 3, reorderNeeded: false },
  { name: "Blood pressure cuff", category: "equipment",
    stockLevel: 22, reorderNeeded: false },
  { name: "Surgical tape", category: "consumables",
    stockLevel: 17, reorderNeeded: false },
  { name: "Disposable cups", category: "consumables",
    stockLevel: 60, reorderNeeded: false },
  { name: "Pulse oximeter", category: "equipment",
    stockLevel: 5, reorderNeeded: false }
];

// 1. Declare your counter variable here
// 2. Declare your reorderList array here
// 3. Write your loop below