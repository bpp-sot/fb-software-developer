// Your task: trace this array of objects by hand before running the file
// First: write down what each console.log below will print
// Second: run the file and check your predictions were correct
// Third: write a sentence explaining what learners[1].score means in plain English
// Each prediction should be checked against the real output

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

console.log(learners[0].name);
console.log(learners[1].score);
console.log(learners[2].verified);