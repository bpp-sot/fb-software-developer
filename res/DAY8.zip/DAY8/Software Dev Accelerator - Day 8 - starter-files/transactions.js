// Your task: trace this loop by hand, then run the file to check your work
// First: write down what the loop will print for iterations 3 and 4
// Second: run the file and compare the actual output with your trace
// Third: write one sentence explaining what transactions[i].amount means
// Each iteration should print the reference and amount for that transaction

let transactions = [
  { reference: "TXN-001", customerName: "Sofia Andersen",
    amount: 4750, status: "pending", flagged: false },
  { reference: "TXN-002", customerName: "David Osei",
    amount: 320, status: "cleared", flagged: false },
  { reference: "TXN-003", customerName: "Mei Lin",
    amount: 12800, status: "pending", flagged: false },
  { reference: "TXN-004", customerName: "Ravi Patel",
    amount: 95, status: "cleared", flagged: false }
];

for (let i = 0; i < transactions.length; i++) {
  console.log(transactions[i].reference);
  console.log(transactions[i].amount);
}