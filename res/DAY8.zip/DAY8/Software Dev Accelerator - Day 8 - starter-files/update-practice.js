// Your task: update two properties on a patient object using dot notation
// First: read the two console.log lines below and predict what they will print
// Second: change the score property to 95 using dot notation
// Third: change the verified property from false to true
// Each change should be reflected in the console output when you run the file

let patient = {
  name: "Grace Oduya",
  ward: "Cardiology",
  score: 84,
  verified: false,
  priority: "standard"
};

console.log(patient.score);
console.log(patient.verified);