// Your task: complete this accumulator loop so it adds up every value in the array.
// First: read the array and the total variable that starts at zero.
// Second: read the for loop header that already visits every item in the array.
// Third: add the missing line inside the loop body that updates total with the current item.
// Fourth: run the file and check the printed total is correct.
// Each pass of the loop should add the current item to the running total.

let bookings = [14, 22, 9, 31, 18, 27, 12];
let total = 0;

for (let i = 0; i < bookings.length; i++) {

}

console.log("Total: " + total);