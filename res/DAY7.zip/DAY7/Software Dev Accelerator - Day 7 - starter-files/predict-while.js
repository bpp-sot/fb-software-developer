// Your task: predict what this while loop will print before you run it.
// First: read the while loop and trace it on paper, one pass at a time.
// Second: write down every line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your written prediction to the actual output.
// Fourth: if anything surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let dosesRemaining = 4;

while (dosesRemaining > 0) {
  console.log("Doses remaining: " + dosesRemaining);
  dosesRemaining = dosesRem