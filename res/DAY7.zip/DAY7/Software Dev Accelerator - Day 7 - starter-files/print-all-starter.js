// Your task: modify this loop so it prints a clearer, more useful message for each value.
// First: read the existing loop and the array of dispatch counts.
// Second: change the console.log message so it includes a label and a unit.
// Third: add one more item to the array and run the file to confirm it is printed too.
// Each printed line should show a clear, labelled message including the value and its unit.

let dispatches = [120, 95, 140, 88, 132, 76];

for (let i = 0; i < dispatches.length; i++) {
  console.log(dispatches[i]);
}