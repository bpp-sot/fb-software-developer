// Your task: predict what this loop will print before you run it.
// First: read the array and the loop carefully without running the file yet.
// Second: write down each line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your prediction to the actual output.
// Fourth: if the output surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let parcels = [154, 89, 203, 47, 176];

for (let i = 0; i < parcels.length; i++) {
  console.log(parcels[i]);
}