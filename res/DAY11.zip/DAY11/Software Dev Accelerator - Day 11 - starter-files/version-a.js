// Your task: compare this version of the access checker against your own build
// First: read through the separate else if branches used here
// Second: notice each valid clearance level has its own distinct message written out in full
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard") {
    result.textContent = "Standard access granted";
  } else if (clearance === "elevated") {
    result.textContent = "Elevated access granted";
  } else if (clearance === "restricted") {
    result.textContent = "Restricted access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});