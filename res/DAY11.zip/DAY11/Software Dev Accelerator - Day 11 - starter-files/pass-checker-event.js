// Your task: compare this event-driven pass checker against your Day 2 pass-checker.js
// First: read through this file line by line
// Second: list which lines are genuinely new compared to the Day 2 version
// Third: list which lines are unchanged in logic from the Day 2 version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});