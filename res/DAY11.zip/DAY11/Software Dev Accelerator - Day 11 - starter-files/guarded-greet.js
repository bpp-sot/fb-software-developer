// Your task: read this worked example showing a guard against an empty typed name
// First: notice the empty string check written before the greeting is built
// Second: notice the else branch only runs once the guard passes
// Third: compare this shape against your own stock lookup guard
// Each result should show a clear, helpful message whether the box is empty or filled in

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const typedName = nameInput.value;

  if (typedName === "") {
    result.textContent = "Please type your name first";
  } else {
    result.textContent = "Hello, " + typedName;
  }
});