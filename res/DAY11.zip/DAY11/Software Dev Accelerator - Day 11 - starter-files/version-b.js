// Your task: compare this version of the access checker against your own build
// First: read through the single combined condition using logical OR
// Second: notice the message is built dynamically using the clearance variable itself
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard" || clearance === "elevated" || clearance === "restricted") {
    result.textContent = clearance + " access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});