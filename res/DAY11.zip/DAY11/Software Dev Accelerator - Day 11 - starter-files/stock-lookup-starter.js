// Your task: add a guard so an empty stock code shows a helpful message instead of a blank result
// First: read the existing addEventListener block below
// Second: add an if check for an empty string before the lookup message
// Third: test with an empty box and then with real text typed in
// Each result should show a clear, helpful message whether the box is empty or filled in

const stockInput = document.querySelector("#stockInput");
const button = document.querySelector("#lookupButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const stockCode = stockInput.value;
  result.textContent = "Looking up stock code: " + stockCode;
});