// Your task: compare this Day 2 pass checker against the event-driven version
// First: read through this file line by line
// Second: note that this version runs immediately, using a fixed score variable
// Third: identify the if/else block that is identical in shape to the newer version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const score = 72;

if (score >= 50) {
  console.log("Pass");
} else {
  console.log("Fail");
}