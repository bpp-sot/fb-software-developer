// Your task: find and fix the bug that stops the button from working
// First: run this file and click the button, notice that nothing happens
// Second: check the browser console for an error message
// Third: read the error carefully and compare it against a working example from earlier today
// Fourth: fix the bug and confirm the button now updates the result text
// Each fix should make the result text update with a clear, helpful message when clicked

const input = document.querySelector("#scoreInput")
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListner("click", function () {
  result.textContent = "Score received: " + input.value;
});