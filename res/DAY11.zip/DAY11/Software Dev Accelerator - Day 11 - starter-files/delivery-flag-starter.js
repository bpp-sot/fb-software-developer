// Your task: build a delivery tracking checker that validates a typed tracking number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty tracking number
// Third: add a check using trackingInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const trackingInput = document.querySelector("#trackingInput");
const button = document.querySelector("#checkDeliveryButton");
const result = document.querySelector("#result");