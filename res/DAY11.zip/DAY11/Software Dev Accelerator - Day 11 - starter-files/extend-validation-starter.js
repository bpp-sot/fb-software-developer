// Your task: extend a single-guard checker into a full four-branch validated version
// First: read the existing empty-input guard already written below
// Second: add a range check using else if and logical OR, catching scores below 0 or above 100
// Third: add the final pass or fail branches for valid scores
// Fourth: test with an empty box, an out-of-range number, and a valid number
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  }

});