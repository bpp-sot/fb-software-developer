// Your task: predict what prints to the console and in what order, before running this file
// First: read every line below without running it
// Second: write down what you think will print, and in what order
// Third: run the file and click the button to check your prediction
// Each prediction should be written down clearly before you run any code

const button = document.querySelector("#checkButton");

button.addEventListener("click", function () {
  console.log("Checking now");
});

console.log("Script finished loading");