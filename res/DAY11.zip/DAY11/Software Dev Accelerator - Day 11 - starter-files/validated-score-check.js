// Your task: read this fully validated score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  } else if (score < 0 || score > 100) {
    result.textContent = "Score must be between 0 and 100";
  } else if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});