// Your task: build a validated, event-driven access request checker
// First: add an addEventListener for a click on the button
// Second: read clearanceInput.value inside the click handler and store it in a variable
// Third: add a guard for a blank submission
// Fourth: add branches for standard, elevated, restricted and unrecognised values
// Fifth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid and valid clearance levels

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");