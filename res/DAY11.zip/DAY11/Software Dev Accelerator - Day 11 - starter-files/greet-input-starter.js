// Your task: wire up a button that reads a typed name and prints a greeting to the console
// First: select the input, the button and store them in variables
// Second: add an addEventListener for a click on the button
// Third: inside the click handler, read the input's value and store it in a variable
// Fourth: build a greeting message using that variable and print it
// Each greeting should print a clear, helpful message that includes the typed name

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");