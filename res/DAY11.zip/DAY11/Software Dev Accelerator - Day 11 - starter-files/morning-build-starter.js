// Your task: wire the Day 4 eligibility logic up to a real button and input
// First: add an addEventListener for a click on the button
// Second: read ageInput.value inside the click handler and store it in a variable
// Third: reuse the Day 4 if/else logic, an applicant qualifies if age is 18 or over
// Fourth: write the result to the page using result.textContent
// Each result should show a clear, helpful message of Eligible or Not eligible

const ageInput = document.querySelector("#ageInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");