// Your task: add a new property to the learner profile object and print it.
// First: read the existing learner object below and notice how each property is written.
// Second: add a new property called "city" with your city name as the value, remembering the comma after the previous property.
// Third: add a console.log line that prints the new "city" property.
// Each console.log line should print a clear, correct value for that property.

let learner = {
  name: "Priya Sharma",
  age: 24,
  cohort: "JavaScript Accelerator",
  employer: "Greenfield Health Trust"
};

console.log(learner.name);
console.log(learner.employer);