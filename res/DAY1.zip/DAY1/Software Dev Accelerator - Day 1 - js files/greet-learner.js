// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Dev Patel");
greetLearner("Amara Osei");