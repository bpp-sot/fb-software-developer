// Your task: build your own personalised learner profile using the pattern from today.
// First: change the property values in the learner object below to your own name, age, cohort, employer, and start year.
// Second: run the file and confirm the welcome message shows your own name.
// Third: write down exactly what appears in the console.
// Each console.log message should print a clear, personalised welcome message using your own details.

let learner = {
  name: "Amara Osei",
  age: 23,
  cohort: "JavaScript Accelerator",
  employer: "Central Bank of Midshire",
  startYear: 2025
};

function greetLearner(name) {
  let message = "Welcome to the programme, " + name;
  console.log(message);
}

greetLearner(learner.name);