const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});