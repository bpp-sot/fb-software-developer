// Your task: run a fetch request to a public API and see live data arrive in the console.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to print the data to the console
// Each step should print a clear, helpful result so you can confirm the request worked