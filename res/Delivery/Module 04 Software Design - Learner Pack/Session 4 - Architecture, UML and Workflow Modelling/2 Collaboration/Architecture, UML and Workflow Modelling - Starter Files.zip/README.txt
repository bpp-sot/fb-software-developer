Session 4 starter file: Architecture, UML and Workflow Modelling
Kestrel Moor Homes is a fictional organisation and its data is synthetic.

What is in this zip
- Session 4 - Class, sequence and swimlane (starter).drawio: three pages with blank frames and labels only.
  Page "Class diagram" (Activity 1): three empty bands, Presentation, Application, Data and integration, and a note frame.
  Page "Sequence" (Activity 2): a Tenant lifeline and five blank lifelines to name from your class diagram; no messages.
  Page "Swimlane" (Activity 3 extension): three empty lanes, Tenant, Contact centre, Repairs team.

How to open it
1. Unzip this file to your device.
2. Go to app.diagrams.net in your browser (no account needed). If asked where to save, choose Device. Choose Open Existing
   Diagram and pick the .drawio file. Or use the draw.io desktop app.
3. Switch pages with the tabs at the bottom of the window.
4. Save to your device with File, Save as. To share a page in Teams, use File, Export as, PNG.

Working in pairs in Teams
- Download this zip from the Files tab and save your own copy before you edit; never edit the class copy.
- One of you drives and shares their screen. Before the breakout room closes, the driver posts the .drawio file
  in the breakout chat so you both keep it. In a trio, swap the driver at each activity.

If draw.io does not work for you
- Draw the diagrams with PowerPoint shapes, or on paper, and share a screenshot or a clear photo in your breakout room chat.

Your diagrams: This can be portfolio evidence if your skills coach agrees it shows your own work.
Keep your files general: no personal or customer data, credentials or confidential material.
