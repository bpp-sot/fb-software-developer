Session 5 starter files: Secure by Design and Reusable Patterns
Module 4: Software Design (Firebrand). Fictional organisation and synthetic data.

What is in this zip
- Session 5 - Contractor design (starter).drawio: the external agency's draft design for photo upload and appointment notifications, with three pages:
  1 Agency class diagram and 2 Agency sequence diagram (the same diagrams as Figures 1 and 2 in the Supporting Material, Part A),
  and 3 Your revised design, which already holds a copy of the agency's classes for you to change in Activity 2.

How to open it
1. Download this zip from the class channel Files tab, unzip it and save the .drawio file to your own device. Never edit the class copy.
2. Go to app.diagrams.net in your browser (no account needed), choose Device, then Open Existing Diagram, and pick the .drawio file.
   The draw.io desktop app also opens it.
3. Switch pages with the tabs at the bottom of the screen. Save with File, Save as, Device. Export a PNG with File, Export as, PNG.
4. Before your breakout room closes, the driver posts the .drawio file and a PNG in the breakout chat, so both partners keep a copy.

No draw.io?
Use PowerPoint shapes (Insert, Shapes) or draw on paper, photograph the result and post it in your breakout chat.

Your revised design and decision record: This can be portfolio evidence if your skills coach agrees it shows your own work.

Keep it general: no personal or customer data, credentials or confidential material in your files, and no employer data in AI tools your employer has not approved.
