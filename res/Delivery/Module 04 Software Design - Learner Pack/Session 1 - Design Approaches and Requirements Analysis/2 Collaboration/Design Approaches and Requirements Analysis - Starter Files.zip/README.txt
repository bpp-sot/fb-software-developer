Session 1 starter file: Session 1 - Concept map and task flow (starter).drawio

How to open it
1. Extract the zip (right-click, Extract All).
2. In a browser, open app.diagrams.net (no account needed). Choose File, Open from, Device, and pick the .drawio file.
   Or open it in the draw.io desktop app.
   Save your own copy first: never edit the class copy in the Teams Files tab.
3. Use the tabs at the bottom to move between the three pages: Concept map, Task flow and Open questions.
   Each page has a title, empty frames and a small key. Everything else is yours to draw.
   Core: the concept map, the portal task flow and Questions 1 and 2. The today flow and Question 3 are extension.
4. Save often with File, Save as, Device. Keep the .drawio ending so it reopens as a diagram.

No draw.io?
Use PowerPoint shapes and connectors (one slide per page), or draw on paper and photograph it.
Before the breakout room closes, post your file or photograph in the breakout chat so you keep it.
This can be portfolio evidence if your skills coach agrees it shows your own work.

Data reminder: the Kestrel Moor Homes data is synthetic, but treat it as real. Do not paste it into AI tools.
