Session 3 Starter Files: Use Cases, User Stories and Test Scenarios
Kestrel Moor Homes is a fictional organisation and its repair data is synthetic.

What is in this zip
- Session 3 - Analysis workbook.docx: the workbook for Activities 1 to 3. Part 1 is your use case and request check, Part 2 your user stories,
  acceptance criteria and INVEST check, Part 3 the tests you write for your partner (and the could-not-test table), and
  Part 4 a criterion you rewrite after feedback. It holds headings and labels only. Rows and tables marked (extension)
  are for when you finish the core.

Before you edit
- A Word file inside a zip cannot be opened in Word online from the Teams Files tab. Download this zip, extract it, and
  save the workbook to your own OneDrive (or your device) with your name in the file name. Open your own copy in Word or
  Word online. Never edit the class copy in the Files tab.
- No Word? Use LibreOffice Writer (free) or upload your copy to Google Docs; the tables keep their layout.
- No computer to hand? Copy the table headings onto paper, fill them in, and photograph each page into the breakout chat.

Working with a partner
- In pair work the driver shares their screen and types in their own copy. Before the breakout room closes, the driver
  posts the workbook in the breakout chat and the partner saves it to their own OneDrive, so you both keep the work.

Keep your workbook: Session 4 starts from your use case. This can be portfolio evidence if your skills coach agrees it
shows your own work.

Optional diagram: to draw your use case as a UML use case diagram, use draw.io in the browser at app.diagrams.net (no account needed; save to your device), or the draw.io desktop app, PowerPoint shapes, or paper
photographed. The written use case in the workbook is what Activity 1 asks for.

Keep workplace examples general: no personal or customer data, credentials or confidential material, and no employer data in unapproved AI tools.
