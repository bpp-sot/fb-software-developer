Session 6 starter file: Session 6 - Design pack (starter).drawio
Module 4: Software Design. Session 6: Design Review and Stakeholder Presentation.

What it is
A draw.io file with four pages for your design pack: Wireframes, Analysis, Model and Traceability.
The pages hold titles, blank phone frames and empty grids only. Everything you put in them is your own design.

How to open it
1. Go to app.diagrams.net in a browser (no account needed). Choose "Open Existing Diagram"
   (or File, then Open from, then Device) and pick the .drawio file. You can also drag the file onto the page.
2. draw.io desktop works too (version 32.6.1, checked October 2026).
3. The page tabs are at the bottom of the window. To type in a grid cell or frame, double-click it.
4. Save with File, then Save as, to your own device. To share during the review board, share your
   draw.io window, or use File, then Export as, then PNG.

No draw.io?
Use PowerPoint shapes (one slide per page, a table for the traceability grid), or draw on paper and
photograph each page with your phone. The traceability table and security checks can go in a Word table.

Keep it confidential
No personal or customer data, credentials or confidential material, and no employer data in AI tools
your employer has not approved. Invent example values that are obviously fake, such as "Customer 0001".
