Session 2 starter files: UI and UX Design, Wireframes and Prototypes
Firebrand, Module 4 Software Design. Kestrel Moor Homes is a fictional organisation.

WHAT IS HERE
Session 2 - Wireframes (starter).drawio: a Components page with shapes to copy (labels, a text box, buttons, an error
summary and message, a note), then one page per screen for Activity 2, each a blank phone frame with its title:
Screen 1 option A, Screen 1 option B, Screen 2 what is wrong, Screen 2 error, Screen 3 emergency stop, Screen 4 confirmation.

HOW TO OPEN IT IN DRAW.IO
1. Download Starter Files.zip from the Files tab and unzip it on your own device. Work on your own copy,
   never on the file in the Files tab.
2. Go to https://app.diagrams.net in a browser (no account needed). When it asks where to save, choose Device.
   Or use the draw.io desktop app.
3. Choose File, Open from, Device, and pick the .drawio file.
4. Use the page tabs at the bottom to move between screens. Copy shapes from the Components page.
   To start a screen from an earlier one, right-click its page tab and choose Duplicate.
5. To link a shape to a page: right-click the shape, choose Edit Link, pick the page in the second option, click OK.
   To test: hover over the shape and click the link that appears.
6. Save with File, Save as, Device. Before your breakout room closes, post the .drawio in the breakout chat
   so your partner can open it in Activity 3.

This can be portfolio evidence if your skills coach agrees it shows your own work.

NO DRAW.IO?
- PowerPoint: one slide per screen, drawn with shapes. Link a shape to a slide with Insert, Link,
  Place in This Document (This Document on a Mac), then test it in Slide Show.
- Paper: one sheet per screen, arrows for the links, then photograph each sheet and post the photos in the breakout chat.
  In Activity 3 your partner says what they would tap and you turn to that page.

Keep your files general: no personal or customer data, credentials or confidential material.
