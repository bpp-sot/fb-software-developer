// Your task: explain this refund check to a customer service colleague using no technical words at all.
// First: write what the code decides in one plain sentence as a comment.
// Second: remove any word from that sentence a non-developer would not know.
// Third: read it to a partner playing the customer service role and ask them to flag any word they did not understand.
// Each explanation should be fully understandable to someone with no coding background.

let orderAge = 45;
let refundWindow = 30;

if (orderAge > refundWindow) {
  console.log("Outside the refund window.");
} else {
  console.log("Refund can be processed.");
}