// Your task: rename every variable in this stock check so the file explains itself.
// First: read the comparison below and work out what a, b and c represent.
// Second: replace a, b and c with descriptive names everywhere they appear.
// Third: run the file and confirm the output logic is unchanged.
// Each variable name should make the comparison and result clear on first read.

let a = 250;
let b = 300;
let c = false;

if (a < b) {
  c = true;
}

console.log(c);