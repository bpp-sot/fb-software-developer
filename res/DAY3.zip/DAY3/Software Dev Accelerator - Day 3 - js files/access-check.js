// Your task: explain this access check two ways, once for a developer and once for a non-technical manager.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one was clearer.
// Each explanation should give a clear, accurate sentence for its intended audience.

let accessLevel = 2;
let requiredLevel = 3;

if (accessLevel >= requiredLevel) {
  console.log("Access granted.");
} else {
  console.log("Access not granted.");
}