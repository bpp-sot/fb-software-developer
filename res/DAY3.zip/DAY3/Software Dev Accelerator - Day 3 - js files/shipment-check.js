// Your task: rewrite both messages so a customer checking their order understands them.
// First: replace "late" with a message the customer could act on.
// Second: replace "ok" with a message that reassures without sounding robotic.
// Third: run the file with daysInTransit at 9, then set it to 3, and check both messages.
// Each message should print a clear, helpful sentence for the customer reading it.

let daysInTransit = 9;
let maxTransitDays = 5;

if (daysInTransit > maxTransitDays) {
  console.log("late");
} else {
  console.log("ok");
}