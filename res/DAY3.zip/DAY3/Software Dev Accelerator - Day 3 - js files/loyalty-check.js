// Your task: explain this loyalty check two ways, once for a developer and once for a non-technical colleague.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one they understood faster.
// Each explanation should give a clear, accurate sentence for its intended audience.

let pointsBalance = 420;
let rewardThreshold = 400;

if (pointsBalance >= rewardThreshold) {
  console.log("Reward unlocked.");
} else {
  console.log("Keep collecting points.");
}