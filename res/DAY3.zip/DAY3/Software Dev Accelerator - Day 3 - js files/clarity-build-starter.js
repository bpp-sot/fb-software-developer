// Your task: rewrite this file so it reads clearly to a new teammate, using everything you practised today.
// First: rename x, y and z to descriptive names and fix or remove the misleading comment.
// Second: rewrite "yes" and "no" into clear, full sentences.
// Third: run the file and confirm the logic still works for both outcomes.
// Each part of the file should read clearly on its own, with no explanation needed.

// set x to 5
let x = 5;
let y = 3;
let z = false;

if (x > y) {
  z = true;
}

if (z === true) {
  console.log("yes");
} else {
  console.log("no");
}