// Your task: rewrite the console messages so a non-technical reader understands them.
// First: replace "temp high" with a clear, full-sentence warning.
// Second: replace "ok" with a clear, reassuring message.
// Third: run the file with temperature set to 39, then set it to 36, and check both messages.
// Each message should print a clear, helpful sentence for someone with no technical background.

let temperature = 39;
let safeLimit = 38;

if (temperature > safeLimit) {
  console.log("temp high");
} else {
  console.log("ok");
}