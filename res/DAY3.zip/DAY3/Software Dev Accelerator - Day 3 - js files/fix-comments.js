// Your task: fix every comment in this fraud check so each one earns its place.
// First: delete the comment that only restates the code.
// Second: replace the vague "check" comment with a comment saying what the check actually decides.
// Third: add one comment explaining why riskLimit might be set to 70.
// Each remaining comment should add real meaning that the code on its own cannot give.

// set score to 80
let fraudScore = 80;
let riskLimit = 70;

// check
if (fraudScore > riskLimit) {
  console.log("review needed");
}