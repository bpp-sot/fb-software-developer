// Your task: run this improved draft with age 16 and compare its output to eligibility-v1.js.
// First: run this file with age 16 and note the output.
// Second: compare the message here to the message you got from eligibility-v1.js with age 16.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 18 && identityVerified === true) {
  console.log("Eligible to open a savings account.");
} else {
  console.log("Not eligible to open a savings account yet.");
}