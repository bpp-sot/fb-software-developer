let message = document.querySelector("#pannel-message");

message.textContent = "Ready";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.