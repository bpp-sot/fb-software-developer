// Your task: update the status panel so it reports the system as healthy.
// First: select #panel-title and store it in a variable called title.
// Second: select #panel-message and store it in a variable called message.
// Third: assign "All Systems Normal" to the title's text.
// Fourth: assign a short reassuring sentence to the message's text.
// Each update should display a clear, helpful message on the page.