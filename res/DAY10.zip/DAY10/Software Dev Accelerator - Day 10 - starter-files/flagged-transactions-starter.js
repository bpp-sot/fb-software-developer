let transactions = [
  { id: "T2001", amount: 450 },
  { id: "T2002", amount: 1250 },
  { id: "T2003", amount: 980 },
  { id: "T2004", amount: 3200 },
  { id: "T2005", amount: 1100 }
];

// Your task: apply the dashboard pattern to flag large transactions.
// First: loop through transactions and count how many have amount greater than 1000.
// Second: loop through transactions and build a comma-separated list of flagged transaction ids.
// Third: select #flagged-count and update its text with the count.
// Fourth: select #flagged-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.