// Your task: select the paragraph on the page and log it, then read its plain text.
// First: use querySelector to select #page-message and store it in a variable called message.
// Second: log message to the console and check what it shows.
// Third: read message.textContent into a variable called messageText and log that too.
// Each console.log should print a clear, helpful result you can check against the page.