let status = document.querySelector("#status-line");

let currentText = status.textContent;

// Your task: find and fix the one bug in this script.
// First: read the two lines above and work out what they actually do.
// Second: fix the bug so the page genuinely changes, using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.