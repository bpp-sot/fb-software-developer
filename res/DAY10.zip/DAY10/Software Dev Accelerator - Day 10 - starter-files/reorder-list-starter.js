let stock = [
  { name: "Filing box", quantity: 4 },
  { name: "Printer paper", quantity: 0 },
  { name: "Desk lamp", quantity: 12 },
  { name: "Staplers", quantity: 2 },
  { name: "Notebooks", quantity: 9 }
];

// Your task: build a reorder list on the page for items running low on stock.
// First: create an empty string called nameList to collect matching names.
// Second: loop through stock and add each item's name to nameList when quantity is less than 5.
// Third: select #reorder-summary and assign the finished list to its text.
// Each update should display a clear, helpful list of products needing reorder.