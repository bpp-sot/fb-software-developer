// Your task: change the heading text shown on welcome.html.
// First: select #page-title and store it in a variable called heading.
// Second: assign a new string to heading.textContent.
// Third: refresh the browser and confirm the new heading appears on the page.
// Each change should display a clear, helpful message to whoever is looking at the page.