// Your task: update two elements with the same string, one using textContent and one using innerHTML.
// First: select #status-a and assign it the string "<i>Confirmed</i>" using textContent.
// Second: select #status-b and assign it the same string using innerHTML.
// Third: refresh the browser and compare how each element displays the string.
// Each element should show a clear, different result so the distinction is obvious.