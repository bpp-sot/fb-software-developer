let appointments = [
  { patient: "Amara Okafor", urgent: true },
  { patient: "Liam Doyle", urgent: false },
  { patient: "Priya Shah", urgent: true },
  { patient: "Noah Bennett", urgent: false },
  { patient: "Sofia Mendes", urgent: true }
];

let urgentCount = 0;

for (let i = 0; i < appointments.length; i++) {
  if (appointments[i].urgent === true) {
    urgentCount = urgentCount + 1;
  }
}

console.log("Urgent appointments: " + urgentCount);

// Your task: move this report from the console onto the page.
// First: select #appointment-summary and store it in a variable called summary.
// Second: replace the console.log line above with a textContent assignment.
// Third: refresh the browser and confirm the count appears where "Loading..." used to be.
// Each update should display a clear, helpful message on the page.