// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let patients = [
  { name: "Amara Okafor", flagged: true },
  { name: "Liam Doyle", flagged: false },
  { name: "Priya Shah", flagged: true }
];

let nameList = "";

for (let i = 0; i < patients.length; i++) {
  if (patients[i].flagged === true) {
    nameList = nameList + patients[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
