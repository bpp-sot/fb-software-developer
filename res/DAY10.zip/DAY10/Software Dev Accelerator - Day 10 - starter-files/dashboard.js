let deliveries = [
  { id: "D1021", status: "delayed" },
  { id: "D1022", status: "on time" },
  { id: "D1034", status: "delayed" },
  { id: "D1045", status: "on time" },
  { id: "D1050", status: "delayed" }
];

// Your task: build a dashboard that reports delayed delivery counts and ids.
// First: loop through deliveries and count how many have status "delayed".
// Second: loop through deliveries and build a comma-separated list of delayed ids.
// Third: select #delayed-count and update its text with the count.
// Fourth: select #delayed-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.