# JSFiddle Activity — Day 7: Predict Loop

## Day 7 — Predict Loop — Alternative Scenario

**Source JavaScript:** `predict-loop.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Fundraising Campaign

Use loops and accumulators to process donations, targets and supporter activity. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this loop will print before you run it.
// First: read the array and the loop carefully without running the file yet.
// Second: write down each line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your prediction to the actual output.
// Fourth: if the output surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let parcels = [154, 89, 203, 47, 176];

for (let i = 0; i < parcels.length; i++) {
  console.log(parcels[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
