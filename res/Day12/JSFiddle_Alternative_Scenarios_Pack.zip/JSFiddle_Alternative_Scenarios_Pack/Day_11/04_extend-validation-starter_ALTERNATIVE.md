# JSFiddle Activity — Day 11: Extend Validation Starter

## Day 11 — Extend Validation Starter — Alternative Scenario

**Source JavaScript:** `extend-validation-starter.js`  
**Corresponding HTML:** `extend-validation-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: extend a single-guard checker into a full four-branch validated version
// First: read the existing empty-input guard already written below
// Second: add a range check using else if and logical OR, catching scores below 0 or above 100
// Third: add the final pass or fail branches for valid scores
// Fourth: test with an empty box, an out-of-range number, and a valid number
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  }

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
