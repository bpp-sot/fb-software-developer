# JSFiddle Activity — Day 11: Validated Score Check Details

## Day 11 — Validated Score Check Details — Alternative Scenario

**Source JavaScript:** `validated-score-check.js`  
**Corresponding HTML:** `validated-score-check.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this fully validated score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  } else if (score < 0 || score > 100) {
    result.textContent = "Score must be between 0 and 100";
  } else if (score >= 50) {
    result.textContent = "Approved";
  } else {
    result.textContent = "Review Required";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
