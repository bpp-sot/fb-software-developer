# JSFiddle Activity — Day 11: Predict Click Starter

## Day 11 — Predict Click Starter — Alternative Scenario

**Source JavaScript:** `predict-click-starter.js`  
**Corresponding HTML:** `predict-click-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<button id="checkButton">Check Details</button>
```

### JavaScript panel
```javascript
// Your task: predict what prints to the console and in what order, before running this file
// First: read every line below without running it
// Second: write down what you think will print, and in what order
// Third: run the file and click the button to check your prediction
// Each prediction should be written down clearly before you run any code

const button = document.querySelector("#checkButton");

button.addEventListener("click", function () {
  console.log("Check Detailsing now");
});

console.log("Script finished loading");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
