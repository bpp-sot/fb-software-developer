# JSFiddle Activity — Day 11: Welcome Customer Input Starter

## Day 11 — Welcome Customer Input Starter — Alternative Scenario

**Source JavaScript:** `greet-input-starter.js`  
**Corresponding HTML:** `greet-input-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="learnerName" type="text" />
  <button id="greetButton">Welcome Customer</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire up a button that reads a typed name and prints a greeting to the console
// First: select the input, the button and store them in variables
// Second: add an addEventListener for a click on the button
// Third: inside the click handler, read the input's value and store it in a variable
// Fourth: build a greeting message using that variable and print it
// Each greeting should print a clear, helpful message that includes the typed name

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
