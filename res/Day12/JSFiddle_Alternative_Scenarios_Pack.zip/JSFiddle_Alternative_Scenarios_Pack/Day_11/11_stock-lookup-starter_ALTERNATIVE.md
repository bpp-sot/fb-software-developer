# JSFiddle Activity — Day 11: Stock Find Product Starter

## Day 11 — Stock Find Product Starter — Alternative Scenario

**Source JavaScript:** `stock-lookup-starter.js`  
**Corresponding HTML:** `stock-lookup-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="stockInput" type="text" />
  <button id="lookupButton">Look up</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: add a guard so an empty stock code shows a helpful message instead of a blank result
// First: read the existing addEventListener block below
// Second: add an if check for an empty string before the lookup message
// Third: test with an empty box and then with real text typed in
// Each result should show a clear, helpful message whether the box is empty or filled in

const stockInput = document.querySelector("#stockInput");
const button = document.querySelector("#lookupButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const stockCode = stockInput.value;
  result.textContent = "Looking up stock code: " + stockCode;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
