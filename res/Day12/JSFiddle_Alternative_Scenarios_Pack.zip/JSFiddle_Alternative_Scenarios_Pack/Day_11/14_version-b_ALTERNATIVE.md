# JSFiddle Activity — Day 11: Version B

## Day 11 — Version B — Alternative Scenario

**Source JavaScript:** `version-b.js`  
**Corresponding HTML:** `version-b.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check Details access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the single combined condition using logical OR
// Second: notice the message is built dynamically using the clearance variable itself
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard" || clearance === "elevated" || clearance === "restricted") {
    result.textContent = clearance + " access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
