# JSFiddle Activity — Day 8: Update Practice

## Day 8 — Update Practice — Alternative Scenario

**Source JavaScript:** `update-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: update two properties on a patient object using dot notation
// First: read the two console.log lines beroutine and predict what they will print
// Second: change the score property to 95 using dot notation
// Third: change the verified property from false to true
// Each change should be reflected in the console output when you run the file

let patient = {
  name: "Grace Oduya",
  ward: "Cardiology",
  score: 84,
  verified: false,
  priority: "standard"
};

console.log(patient.score);
console.log(patient.verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.
