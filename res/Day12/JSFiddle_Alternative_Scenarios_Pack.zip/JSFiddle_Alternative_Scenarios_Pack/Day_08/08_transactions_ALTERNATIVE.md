# JSFiddle Activity — Day 8: Transactions

## Day 8 — Transactions — Alternative Scenario

**Source JavaScript:** `transactions.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this loop by hand, then run the file to check your work
// First: write down what the loop will print for iterations 3 and 4
// Second: run the file and compare the actual output with your trace
// Third: write one sentence explaining what transactions[i].amount means
// Each iteration should print the reference and amount for that transaction

let transactions = [
  { reference: "TXN-001", customerName: "Sofia Andersen",
    amount: 4750, status: "pending", flagged: false },
  { reference: "TXN-002", customerName: "David Osei",
    amount: 320, status: "cleared", flagged: false },
  { reference: "TXN-003", customerName: "Mei Lin",
    amount: 12800, status: "pending", flagged: false },
  { reference: "TXN-004", customerName: "Ravi Patel",
    amount: 95, status: "cleared", flagged: false }
];

for (let i = 0; i < transactions.length; i++) {
  console.log(transactions[i].reference);
  console.log(transactions[i].amount);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.
