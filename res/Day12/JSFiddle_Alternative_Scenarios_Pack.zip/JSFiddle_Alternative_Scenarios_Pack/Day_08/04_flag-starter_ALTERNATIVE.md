# JSFiddle Activity — Day 8: Flag Starter

## Day 8 — Flag Starter — Alternative Scenario

**Source JavaScript:** `flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: write a loop that flags urgent-value transactions
// First: read the existing array beroutine
// Second: write a for loop that reads each transaction object
// Third: inside the loop, add an if statement: if amount is above 5000, set flagged to true
// Fourth: after the loop, log the flagged value for each transaction to check your work
// Each transaction over 5000 should print true and each other transaction should print false

let transactions = [
  { reference: "TXN-101", customerName: "Freya Lindqvist", amount: 2200, flagged: false },
  { reference: "TXN-102", customerName: "Ben Okafor", amount: 6100, flagged: false },
  { reference: "TXN-103", customerName: "Anya Petrov", amount: 480, flagged: false },
  { reference: "TXN-104", customerName: "Chidi Nwosu", amount: 9800, flagged: false },
  { reference: "TXN-105", customerName: "Laura Kim", amount: 3050, flagged: false },
  { reference: "TXN-106", customerName: "Omar Farouk", amount: 15200, flagged: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.
