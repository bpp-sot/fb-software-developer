# JSFiddle Activity — Day 8: Predict Array

## Day 8 — Predict Array — Alternative Scenario

**Source JavaScript:** `predict-array.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this array of objects by hand before running the file
// First: write down what each console.log beroutine will print
// Second: run the file and check your predictions were correct
// Third: write a sentence explaining what learners[1].score means in plain English
// Each prediction should be checked against the real output

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

console.log(learners[0].name);
console.log(learners[1].score);
console.log(learners[2].verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.
