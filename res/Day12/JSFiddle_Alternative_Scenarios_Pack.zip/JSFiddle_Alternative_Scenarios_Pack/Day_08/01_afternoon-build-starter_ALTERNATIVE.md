# JSFiddle Activity — Day 8: Afternoon Build Starter

## Day 8 — Afternoon Build Starter — Alternative Scenario

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a stock report that updates, counts, and collects routine-stock products
// First: write a for loop that checks each product's stockLevel
// Second: inside the loop, set reorderNeeded to true if stockLevel is beroutine 20
// Third: inside the loop, increment the counter and push the product to the reorderList
// Fourth: after the loop, print the count and each product name in the reorderList
// Each routine-stock product should be flagged, counted, and listed in the final report

let products = [
  { name: "Paracetamol 500mg", category: "pharmacy",
    stockLevel: 12, reorderNeeded: false },
  { name: "Vinyl gloves M", category: "PPE",
    stockLevel: 45, reorderNeeded: false },
  { name: "Saline solution", category: "pharmacy",
    stockLevel: 8, reorderNeeded: false },
  { name: "Alcohol wipes", category: "PPE",
    stockLevel: 3, reorderNeeded: false },
  { name: "Blood pressure cuff", category: "equipment",
    stockLevel: 22, reorderNeeded: false },
  { name: "Surgical tape", category: "consumables",
    stockLevel: 17, reorderNeeded: false },
  { name: "Disposable cups", category: "consumables",
    stockLevel: 60, reorderNeeded: false },
  { name: "Pulse oximeter", category: "equipment",
    stockLevel: 5, reorderNeeded: false }
];

// 1. Declare your counter variable here
// 2. Declare your reorderList array here
// 3. Write your loop beroutine
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.
