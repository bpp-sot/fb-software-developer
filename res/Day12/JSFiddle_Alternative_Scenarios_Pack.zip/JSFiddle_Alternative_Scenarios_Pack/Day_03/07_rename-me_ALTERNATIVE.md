# JSFiddle Activity — Day 3: Rename Me

## Day 3 — Rename Me — Alternative Scenario

**Source JavaScript:** `rename-me.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rename every variable in this stock check so the file explains itself.
// First: read the comparison below and work out what a, b and c represent.
// Second: replace a, b and c with descriptive names everywhere they appear.
// Third: run the file and confirm the output logic is unchanged.
// Each variable name should make the comparison and result clear on first read.

let a = 250;
let b = 300;
let c = false;

if (a < b) {
  c = true;
}

console.log(c);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
