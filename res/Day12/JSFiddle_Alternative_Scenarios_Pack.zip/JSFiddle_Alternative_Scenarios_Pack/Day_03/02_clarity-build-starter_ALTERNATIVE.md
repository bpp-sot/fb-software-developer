# JSFiddle Activity — Day 3: Clarity Build Starter

## Day 3 — Clarity Build Starter — Alternative Scenario

**Source JavaScript:** `clarity-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite this file so it reads clearly to a new teammate, using everything you practised today.
// First: rename x, y and z to descriptive names and fix or remove the misleading comment.
// Second: rewrite "yes" and "no" into clear, full sentences.
// Third: run the file and confirm the logic still works for both outcomes.
// Each part of the file should read clearly on its own, with no explanation needed.

// set x to 5
let x = 5;
let y = 3;
let z = false;

if (x > y) {
  z = true;
}

if (z === true) {
  console.log("yes");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
