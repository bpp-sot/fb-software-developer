# JSFiddle Activity — Day 3: Access Check

## Day 3 — Access Check — Alternative Scenario

**Source JavaScript:** `access-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this access check two ways, once for a developer and once for a non-technical manager.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one was clearer.
// Each explanation should give a clear, accurate sentence for its intended audience.

let accessLevel = 2;
let requiredLevel = 3;

if (accessLevel >= requiredLevel) {
  console.log("Access granted.");
} else {
  console.log("Access not granted.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
