# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard — Alternative Scenario

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Hotel Operations Dashboard</h1>
<p id="delayed-count">Waiting for update...</p>
<p id="delayed-list">Waiting for update...</p>
```

### JavaScript panel
```javascript
let deliveries = [
  { id: "R201", status: "delayed" },
  { id: "R202", status: "on time" },
  { id: "R214", status: "delayed" },
  { id: "R225", status: "on time" },
  { id: "R230", status: "delayed" }
];

// Your task: build a dashboard that reports delayed delivery counts and ids.
// First: loop through deliveries and count how many have status "delayed".
// Second: loop through deliveries and build a comma-separated list of delayed ids.
// Third: select #delayed-count and update its text with the count.
// Fourth: select #delayed-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
