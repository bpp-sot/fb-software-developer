# JSFiddle Activity — Day 10: Unclear Dom

## Day 10 — Unclear Dom — Alternative Scenario

**Source JavaScript:** `unclear-dom.js`  
**Corresponding HTML:** `unclear-dom.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Stock Dashboard</h1>
<p id="s">Waiting for update...</p>
```

### JavaScript panel
```javascript
let x = document.querySelector("#s");

x.textContent = "Low stock items: 2";

// Your task: rename the unclear variables above without changing what the code does.
// First: read through both lines and identify what each variable actually represents.
// Second: rename each variable to something descriptive of its purpose.
// Third: update every place the old variable name was used.
// Each renamed version should run identically and be easy for a colleague to understand.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
