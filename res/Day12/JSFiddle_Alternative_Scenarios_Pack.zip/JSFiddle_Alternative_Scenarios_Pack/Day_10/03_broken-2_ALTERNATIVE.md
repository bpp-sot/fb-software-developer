# JSFiddle Activity — Day 10: Broken 2

## Day 10 — Broken 2 — Alternative Scenario

**Source JavaScript:** `broken-2.js`  
**Corresponding HTML:** `broken-2.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<p id="panel-message">Ready</p>
```

### JavaScript panel
```javascript
let message = document.querySelector("#pannel-message");

message.textContent = "Ready";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
