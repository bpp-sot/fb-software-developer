# Day 10 — Alternative JSFiddle Scenarios

**Activities:** 13

# JSFiddle Activity — Day 10: Appointments Console

## Day 10 — Appointments Console — Alternative Scenario

**Source JavaScript:** `appointments-console.js`  
**Corresponding HTML:** `appointments.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Conference Booking Dashboard</h1>
<p id="appointment-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
let appointments = [
  { patient: "Elena Rossi", urgent: true },
  { patient: "Marcus Green", urgent: false },
  { patient: "Hannah Cole", urgent: true },
  { patient: "Owen Price", urgent: false },
  { patient: "Leila Khan", urgent: true }
];

let urgentCount = 0;

for (let i = 0; i < appointments.length; i++) {
  if (appointments[i].urgent === true) {
    urgentCount = urgentCount + 1;
  }
}

console.log("Urgent appointments: " + urgentCount);

// Your task: move this report from the console onto the page.
// First: select #appointment-summary and store it in a variable called summary.
// Second: replace the console.log line above with a textContent assignment.
// Third: refresh the browser and confirm the count appears where "Waiting for update..." used to be.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 1

## Day 10 — Broken 1 — Alternative Scenario

**Source JavaScript:** `broken-1.js`  
**Corresponding HTML:** `broken-1.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
```

### JavaScript panel
```javascript
let title = document.querySelector("page-title");

title.textContent = "Updated";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 2

## Day 10 — Broken 2 — Alternative Scenario

**Source JavaScript:** `broken-2.js`  
**Corresponding HTML:** `broken-2.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<p id="panel-message">Ready</p>
```

### JavaScript panel
```javascript
let message = document.querySelector("#pannel-message");

message.textContent = "Ready";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 3

## Day 10 — Broken 3 — Alternative Scenario

**Source JavaScript:** `broken-3.js`  
**Corresponding HTML:** `broken-3.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<p id="status-line">Room status</p>
```

### JavaScript panel
```javascript
let status = document.querySelector("#status-line");

let currentText = status.textContent;

// Your task: find and fix the one bug in this script.
// First: read the two lines above and work out what they actually do.
// Second: fix the bug so the page genuinely changes, using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Change Heading

## Day 10 — Change Heading — Alternative Scenario

**Source JavaScript:** `change-heading.js`  
**Corresponding HTML:** `welcome.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
<p id="page-message">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Your task: change the heading text shown on welcome.html.
// First: select #page-title and store it in a variable called heading.
// Second: assign a new string to heading.textContent.
// Third: refresh the browser and confirm the new heading appears on the page.
// Each change should display a clear, helpful message to whoever is looking at the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard — Alternative Scenario

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Hotel Operations Dashboard</h1>
<p id="delayed-count">Waiting for update...</p>
<p id="delayed-list">Waiting for update...</p>
```

### JavaScript panel
```javascript
let deliveries = [
  { id: "R201", status: "delayed" },
  { id: "R202", status: "on time" },
  { id: "R214", status: "delayed" },
  { id: "R225", status: "on time" },
  { id: "R230", status: "delayed" }
];

// Your task: build a dashboard that reports delayed delivery counts and ids.
// First: loop through deliveries and count how many have status "delayed".
// Second: loop through deliveries and build a comma-separated list of delayed ids.
// Third: select #delayed-count and update its text with the count.
// Fourth: select #delayed-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Find Message

## Day 10 — Find Message — Alternative Scenario

**Source JavaScript:** `find-message.js`  
**Corresponding HTML:** `welcome.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
<p id="page-message">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Your task: select the paragraph on the page and log it, then read its plain text.
// First: use querySelector to select #page-message and store it in a variable called message.
// Second: log message to the console and check what it shows.
// Third: read message.textContent into a variable called messageText and log that too.
// Each console.log should print a clear, helpful result you can check against the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Flagged Patients

## Day 10 — Flagged Patients — Alternative Scenario

**Source JavaScript:** `flagged-patients.js`  
**Corresponding HTML:** `flagged-patients.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Patient Dashboard</h1>
<p id="flag-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let patients = [
  { name: "Elena Rossi", flagged: true },
  { name: "Marcus Green", flagged: false },
  { name: "Hannah Cole", flagged: true }
];

let nameList = "";

for (let i = 0; i < patients.length; i++) {
  if (patients[i].flagged === true) {
    nameList = nameList + patients[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Flagged Transactions Starter

## Day 10 — Flagged Transactions Starter — Alternative Scenario

**Source JavaScript:** `flagged-transactions-starter.js`  
**Corresponding HTML:** `flagged-transactions.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Transaction Dashboard</h1>
<p id="flagged-count">Waiting for update...</p>
<p id="flagged-list">Waiting for update...</p>
```

### JavaScript panel
```javascript
let transactions = [
  { id: "T2001", amount: 450 },
  { id: "T2002", amount: 1250 },
  { id: "T2003", amount: 980 },
  { id: "T2004", amount: 3200 },
  { id: "T2005", amount: 1100 }
];

// Your task: apply the dashboard pattern to flag large transactions.
// First: loop through transactions and count how many have amount greater than 1000.
// Second: loop through transactions and build a comma-separated list of flagged transaction ids.
// Third: select #flagged-count and update its text with the count.
// Fourth: select #flagged-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Properties Practice

## Day 10 — Properties Practice — Alternative Scenario

**Source JavaScript:** `properties-practice.js`  
**Corresponding HTML:** `properties-practice.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Status Display</h1>
<p id="status-a">Pending</p>
<p id="status-b">Pending</p>
```

### JavaScript panel
```javascript
// Your task: update two elements with the same string, one using textContent and one using innerHTML.
// First: select #status-a and assign it the string "<i>Confirmed</i>" using textContent.
// Second: select #status-b and assign it the same string using innerHTML.
// Third: refresh the browser and compare how each element displays the string.
// Each element should show a clear, different result so the distinction is obvious.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Reorder List Starter

## Day 10 — Reorder List Starter — Alternative Scenario

**Source JavaScript:** `reorder-list-starter.js`  
**Corresponding HTML:** `reorder-list.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Stock Room Dashboard</h1>
<p id="reorder-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
let stock = [
  { name: "Filing box", quantity: 4 },
  { name: "Printer paper", quantity: 0 },
  { name: "Desk lamp", quantity: 12 },
  { name: "Staplers", quantity: 2 },
  { name: "Notebooks", quantity: 9 }
];

// Your task: build a reorder list on the page for items running low on stock.
// First: create an empty string called nameList to collect matching names.
// Second: loop through stock and add each item's name to nameList when quantity is less than 5.
// Third: select #reorder-summary and assign the finished list to its text.
// Each update should display a clear, helpful list of products needing reorder.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Status Panel

## Day 10 — Status Panel — Alternative Scenario

**Source JavaScript:** `status-panel.js`  
**Corresponding HTML:** `status-panel.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="panel-title">System Status</h1>
<p id="panel-message">Checking...</p>
```

### JavaScript panel
```javascript
// Your task: update the status panel so it reports the system as healthy.
// First: select #panel-title and store it in a variable called title.
// Second: select #panel-message and store it in a variable called message.
// Third: assign "All Systems Normal" to the title's text.
// Fourth: assign a short reassuring sentence to the message's text.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Unclear Dom

## Day 10 — Unclear Dom — Alternative Scenario

**Source JavaScript:** `unclear-dom.js`  
**Corresponding HTML:** `unclear-dom.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Stock Dashboard</h1>
<p id="s">Waiting for update...</p>
```

### JavaScript panel
```javascript
let x = document.querySelector("#s");

x.textContent = "Low stock items: 2";

// Your task: rename the unclear variables above without changing what the code does.
// First: read through both lines and identify what each variable actually represents.
// Second: rename each variable to something descriptive of its purpose.
// Third: update every place the old variable name was used.
// Each renamed version should run identically and be easy for a colleague to understand.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

