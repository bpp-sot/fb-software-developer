# JSFiddle Activity — Day 14: My Learner Profile

## Day 14 — My Learner Profile — Alternative Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Freelancer / Contractor Profile

Reuse the final profile pattern as a contractor or project-team profile. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This is the file you will copy into your git-practice folder for today's activity.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: turn this project folder into a Git repository ready to track changes.
// First: create a new folder called git-practice on your desktop and copy this file into it.
// Second: open a terminal in that folder and run git init.
// Third: confirm the terminal shows the "Initialized empty Git repository" message.
// Each step should print a clear, helpful confirmation in your terminal before you move on.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
