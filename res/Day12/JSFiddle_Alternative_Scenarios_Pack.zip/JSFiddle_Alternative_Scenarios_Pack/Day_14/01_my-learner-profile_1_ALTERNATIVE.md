# JSFiddle Activity — Day 14: My Learner Profile (1)

## Day 14 — My Learner Profile (1) — Alternative Scenario

**Source JavaScript:** `my-learner-profile (1).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Freelancer / Contractor Profile

Reuse the final profile pattern as a contractor or project-team profile. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file is already staged and ready to become your first Git commit.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: record this file as your first permanent entry in your project's history.
// First: run git add my-learner-profile.js in your git-practice folder.
// Second: run git commit -m with a short, honest message describing the file.
// Third: read the confirmation output Git gives you after the commit.
// Fourth: compare your commit message with a neighbour's message.
// Each step should print a clear, helpful message confirming what Git has done.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
