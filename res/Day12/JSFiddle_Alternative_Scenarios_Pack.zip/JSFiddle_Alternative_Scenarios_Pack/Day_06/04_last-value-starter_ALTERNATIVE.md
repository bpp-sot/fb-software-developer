# JSFiddle Activity — Day 6: Last Value Starter

## Day 6 — Last Value Starter — Alternative Scenario

**Source JavaScript:** `last-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the most recent reading in the list.
// First: call getLast with the readings array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "Most recent reading:".
// Each label and value should print together, clearly showing the last reading.

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let readings = [4, 7, 2, 9, 5];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
