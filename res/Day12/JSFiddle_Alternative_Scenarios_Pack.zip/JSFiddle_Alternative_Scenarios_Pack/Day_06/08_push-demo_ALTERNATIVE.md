# JSFiddle Activity — Day 6: Push Demo

## Day 6 — Push Demo — Alternative Scenario

**Source JavaScript:** `push-demo.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: an empty array that grows as values are pushed onto it.

let alerts = [];

console.log(alerts.length);

alerts.push("Fridge door open");
alerts.push("Low battery");

console.log(alerts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
