# JSFiddle Activity — Day 2: Pass Checker V3

## Day 2 — Pass Checker V3 — Alternative Scenario

**Source JavaScript:** `pass-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated pass checker with three different scores and record what happens.
// First: run the file with candidateScore set to 105 and write down the output.
// Second: change candidateScore to 84, run it again, and write down the output.
// Third: change candidateScore to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
