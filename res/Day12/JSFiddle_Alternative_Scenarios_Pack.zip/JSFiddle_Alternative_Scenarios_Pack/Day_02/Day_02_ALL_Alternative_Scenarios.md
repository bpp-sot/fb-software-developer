# Day 2 — Alternative JSFiddle Scenarios

**Activities:** 5

# JSFiddle Activity — Day 2: Pass Checker V2

## Day 2 — Pass Checker V2 — Alternative Scenario

**Source JavaScript:** `pass-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateScore and the value of passMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker V3

## Day 2 — Pass Checker V3 — Alternative Scenario

**Source JavaScript:** `pass-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated pass checker with three different scores and record what happens.
// First: run the file with candidateScore set to 105 and write down the output.
// Second: change candidateScore to 84, run it again, and write down the output.
// Third: change candidateScore to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker V4

## Day 2 — Pass Checker V4 — Alternative Scenario

**Source JavaScript:** `pass-checker-v4.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this file with pass-checker.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 60;
let passMark = 60;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker

## Day 2 — Pass Checker — Alternative Scenario

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's pass checker with pass-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 84;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Alternative Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationScore = 110;
let passMark = 75;

// Your task: build a responsible checker that validates the score and age before deciding pass or fail.
// First: check if applicationScore is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationScore meets or exceeds passMark and print a pass message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

