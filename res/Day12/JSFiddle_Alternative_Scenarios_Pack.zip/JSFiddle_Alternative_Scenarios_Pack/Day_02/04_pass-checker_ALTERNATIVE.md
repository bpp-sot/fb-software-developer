# JSFiddle Activity — Day 2: Pass Checker

## Day 2 — Pass Checker — Alternative Scenario

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's pass checker with pass-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 84;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
