# Day 13 — Alternative JSFiddle Scenarios

**Activities:** 5

# JSFiddle Activity — Day 13: Daily Tip Widget Starter

## Day 13 — Daily Tip Widget Starter — Alternative Scenario

**Source JavaScript:** `advice-generator-starter.js`  
**Corresponding HTML:** `advice-generator.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Daily Tip Widget</h1>
  <button id="new-advice-button">New Advice</button>
  <p id="advice-display">Loading advice...</p>
```

### JavaScript panel
```javascript
const newAdviceButton = document.querySelector("#new-advice-button");
const adviceBox = document.querySelector("#advice-display");

newAdviceButton.addEventListener("click", function() {
  // Your task: build a working advice generator that shows new advice on every click.
  // First: call fetch with the web address "https://api.adviceslip.com/advice"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.slip.advice and set it as the adviceBox textContent
  // Each click should display a new piece of advice on the page

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Dog Photo Starter

## Day 13 — Dog Photo Starter — Alternative Scenario

**Source JavaScript:** `dog-photo-starter.js`  
**Corresponding HTML:** `dog-photo.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Image Refresh Widget</h1>
  <button id="new-dog-button">New Dog Photo</button>
  <img id="dog-photo" src="" alt="A random dog">
```

### JavaScript panel
```javascript
const dogButton = document.querySelector("#new-dog-button");
const dogImage = document.querySelector("#dog-photo");

dogButton.addEventListener("click", function() {
  // Your task: fetch a new random dog photo every time the button is clicked and show it.
  // First: call fetch with the web address "https://dog.ceo/api/breeds/image/random"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.message and set it as the dogImage src
  // Each click should replace the current photo with a new random dog picture

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Fact Display Starter

## Day 13 — Fact Display Starter — Alternative Scenario

**Source JavaScript:** `fact-display-starter.js`  
**Corresponding HTML:** `fact-display.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Random Fact Widget</h1>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const factBox = document.querySelector("#fact-display");

// Your task: fetch a random cat fact and display just the fact text on the page.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to read data.fact and set it as the factBox textContent
// Each step should leave the page showing a real fact instead of the placeholder text
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Live Data Test Starter

## Day 13 — Live Data Test Starter — Alternative Scenario

**Source JavaScript:** `first-fetch-starter.js`  
**Corresponding HTML:** `first-fetch-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Live Data Test</h1>
  <p>Open the browser console to see the result.</p>
```

### JavaScript panel
```javascript
// Your task: run a fetch request to a public API and see live data arrive in the console.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to print the data to the console
// Each step should print a clear, helpful result so you can confirm the request worked
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: New Fact Starter

## Day 13 — New Fact Starter — Alternative Scenario

**Source JavaScript:** `new-fact-starter.js`  
**Corresponding HTML:** `new-fact.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Fact Refresh Widget</h1>
  <button id="new-fact-button">New Fact</button>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

