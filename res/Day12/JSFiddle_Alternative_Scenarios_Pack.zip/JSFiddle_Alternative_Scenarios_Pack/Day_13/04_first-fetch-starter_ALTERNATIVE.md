# JSFiddle Activity — Day 13: Live Data Test Starter

## Day 13 — Live Data Test Starter — Alternative Scenario

**Source JavaScript:** `first-fetch-starter.js`  
**Corresponding HTML:** `first-fetch-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Live Data Test</h1>
  <p>Open the browser console to see the result.</p>
```

### JavaScript panel
```javascript
// Your task: run a fetch request to a public API and see live data arrive in the console.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to print the data to the console
// Each step should print a clear, helpful result so you can confirm the request worked
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
