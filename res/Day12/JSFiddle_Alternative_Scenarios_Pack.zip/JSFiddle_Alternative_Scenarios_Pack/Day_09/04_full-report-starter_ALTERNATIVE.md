# JSFiddle Activity — Day 9: Full Report Starter

## Day 9 — Full Report Starter — Alternative Scenario

**Source JavaScript:** `full-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];
let atRiskNames = [];
let totalScore = 0;

// Your task: build one loop that updates all four variables and prints a complete report.
// First: write a for loop counting passes and collecting pass names.
// Second: inside the same loop, collect at-risk names and add to totalScore.
// Third: after the loop, calculate averageScore and print all five results.
// Each printed result should be a clear, correct value matching a hand-worked trace.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
