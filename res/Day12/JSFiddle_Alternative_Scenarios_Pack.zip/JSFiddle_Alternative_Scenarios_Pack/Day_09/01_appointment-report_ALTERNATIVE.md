# JSFiddle Activity — Day 9: Appointment Report

## Day 9 — Appointment Report — Alternative Scenario

**Source JavaScript:** `appointment-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let appointments = [
  { patient: "Grace Okoro", waitDays: 12, urgent: true },
  { patient: "Liam Foster", waitDays: 34, urgent: false },
  { patient: "Nadia Hussain", waitDays: 21, urgent: true },
  { patient: "Robert Chen", waitDays: 8, urgent: false }
];

let totalWaitDays = 0;
let overdueUrgent = [];

// Your task: apply the same report pattern to this appointment dataset.
// First: write a for loop adding each waitDays value to totalWaitDays.
// Second: inside the loop, push patients where urgent is true and waitDays > 14 to overdueUrgent.
// Third: print totalWaitDays and overdueUrgent after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
