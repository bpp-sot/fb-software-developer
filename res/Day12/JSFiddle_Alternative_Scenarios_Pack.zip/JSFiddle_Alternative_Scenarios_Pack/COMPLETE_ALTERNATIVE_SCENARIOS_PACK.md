# Complete JSFiddle Alternative Scenarios Pack

**89 parallel practice activities across Days 1–14.**

# JSFiddle Activity — Day 1: Greet Learner

## Day 1 — Greet Learner — Alternative Scenario

**Source JavaScript:** `greet-learner.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Events & Staff Onboarding

Reinterpret the examples as onboarding temporary staff for a live-events company. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Maya Chen");
greetLearner("Leo Martins");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: Learner Profile

## Day 1 — Learner Profile — Alternative Scenario

**Source JavaScript:** `learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Events & Staff Onboarding

Reinterpret the examples as onboarding temporary staff for a live-events company. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a new property to the learner profile object and print it.
// First: read the existing learner object below and notice how each property is written.
// Second: add a new property called "city" with your city name as the value, remembering the comma after the previous property.
// Third: add a console.log line that prints the new "city" property.
// Each console.log line should print a clear, correct value for that property.

let learner = {
  name: "Sofia Reed",
  age: 24,
  cohort: "Event Operations Bootcamp",
  employer: "Northstar Live Events"
};

console.log(learner.name);
console.log(learner.employer);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: My Learner Profile

## Day 1 — My Learner Profile — Alternative Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Events & Staff Onboarding

Reinterpret the examples as onboarding temporary staff for a live-events company. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build your own personalised learner profile using the pattern from today.
// First: change the property values in the learner object below to your own name, age, cohort, employer, and start year.
// Second: run the file and confirm the welcome message shows your own name.
// Third: write down exactly what appears in the console.
// Each console.log message should print a clear, personalised welcome message using your own details.

let learner = {
  name: "Leo Martins",
  age: 23,
  cohort: "Event Operations Bootcamp",
  employer: "Riverside Conference Group",
  startYear: 2025
};

function greetLearner(name) {
  let message = "Welcome to the event team, " + name;
  console.log(message);
}

greetLearner(learner.name);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker V2

## Day 2 — Pass Checker V2 — Alternative Scenario

**Source JavaScript:** `pass-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateScore and the value of passMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker V3

## Day 2 — Pass Checker V3 — Alternative Scenario

**Source JavaScript:** `pass-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated pass checker with three different scores and record what happens.
// First: run the file with candidateScore set to 105 and write down the output.
// Second: change candidateScore to 84, run it again, and write down the output.
// Third: change candidateScore to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker V4

## Day 2 — Pass Checker V4 — Alternative Scenario

**Source JavaScript:** `pass-checker-v4.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this file with pass-checker.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 60;
let passMark = 60;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Pass Checker

## Day 2 — Pass Checker — Alternative Scenario

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's pass checker with pass-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 84;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Alternative Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Supplier Quality Checks

Treat the scores and pass/fail decisions as supplier quality-control results rather than learner marks. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationScore = 110;
let passMark = 75;

// Your task: build a responsible checker that validates the score and age before deciding pass or fail.
// First: check if applicationScore is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationScore meets or exceeds passMark and print a pass message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Access Check

## Day 3 — Access Check — Alternative Scenario

**Source JavaScript:** `access-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this access check two ways, once for a developer and once for a non-technical manager.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one was clearer.
// Each explanation should give a clear, accurate sentence for its intended audience.

let accessLevel = 2;
let requiredLevel = 3;

if (accessLevel >= requiredLevel) {
  console.log("Access granted.");
} else {
  console.log("Access not granted.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Clarity Build Starter

## Day 3 — Clarity Build Starter — Alternative Scenario

**Source JavaScript:** `clarity-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite this file so it reads clearly to a new teammate, using everything you practised today.
// First: rename x, y and z to descriptive names and fix or remove the misleading comment.
// Second: rewrite "yes" and "no" into clear, full sentences.
// Third: run the file and confirm the logic still works for both outcomes.
// Each part of the file should read clearly on its own, with no explanation needed.

// set x to 5
let x = 5;
let y = 3;
let z = false;

if (x > y) {
  z = true;
}

if (z === true) {
  console.log("yes");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Fix Comments

## Day 3 — Fix Comments — Alternative Scenario

**Source JavaScript:** `fix-comments.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix every comment in this fraud check so each one earns its place.
// First: delete the comment that only restates the code.
// Second: replace the vague "check" comment with a comment saying what the check actually decides.
// Third: add one comment explaining why riskLimit might be set to 70.
// Each remaining comment should add real meaning that the code on its own cannot give.

// set score to 80
let fraudScore = 80;
let riskLimit = 70;

// check
if (fraudScore > riskLimit) {
  console.log("review needed");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Loyalty Check

## Day 3 — Loyalty Check — Alternative Scenario

**Source JavaScript:** `loyalty-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this loyalty check two ways, once for a developer and once for a non-technical colleague.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one they understood faster.
// Each explanation should give a clear, accurate sentence for its intended audience.

let pointsBalance = 420;
let rewardThreshold = 400;

if (pointsBalance >= rewardThreshold) {
  console.log("Reward unlocked.");
} else {
  console.log("Keep collecting points.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Messages Starter

## Day 3 — Messages Starter — Alternative Scenario

**Source JavaScript:** `messages-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite the console messages so a non-technical reader understands them.
// First: replace "temp high" with a clear, full-sentence warning.
// Second: replace "ok" with a clear, reassuring message.
// Third: run the file with temperature set to 39, then set it to 36, and check both messages.
// Each message should print a clear, helpful sentence for someone with no technical background.

let temperature = 39;
let safeLimit = 38;

if (temperature > safeLimit) {
  console.log("temp high");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Refund Check

## Day 3 — Refund Check — Alternative Scenario

**Source JavaScript:** `refund-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this refund check to a customer service colleague using no technical words at all.
// First: write what the code decides in one plain sentence as a comment.
// Second: remove any word from that sentence a non-developer would not know.
// Third: read it to a partner playing the customer service role and ask them to flag any word they did not understand.
// Each explanation should be fully understandable to someone with no coding background.

let orderAge = 45;
let refundWindow = 30;

if (orderAge > refundWindow) {
  console.log("Outside the refund window.");
} else {
  console.log("Refund can be processed.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Rename Me

## Day 3 — Rename Me — Alternative Scenario

**Source JavaScript:** `rename-me.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rename every variable in this stock check so the file explains itself.
// First: read the comparison below and work out what a, b and c represent.
// Second: replace a, b and c with descriptive names everywhere they appear.
// Third: run the file and confirm the output logic is unchanged.
// Each variable name should make the comparison and result clear on first read.

let a = 250;
let b = 300;
let c = false;

if (a < b) {
  c = true;
}

console.log(c);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 3: Shipment Check

## Day 3 — Shipment Check — Alternative Scenario

**Source JavaScript:** `shipment-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Online Retail & Customer Service

Apply the conditions and messages to an online retailer handling accounts, loyalty, refunds and shipments. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite both messages so a customer checking their order understands them.
// First: replace "late" with a message the customer could act on.
// Second: replace "ok" with a message that reassures without sounding robotic.
// Third: run the file with daysInTransit at 9, then set it to 3, and check both messages.
// Each message should print a clear, helpful sentence for the customer reading it.

let daysInTransit = 9;
let maxTransitDays = 5;

if (daysInTransit > maxTransitDays) {
  console.log("late");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 4: Eligibility V1

## Day 4 — Eligibility V1 — Alternative Scenario

**Source JavaScript:** `eligibility-v1.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Gym Membership Eligibility

Use the eligibility logic for customer membership or promotional eligibility decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this first draft with age 16 so you can compare it to the improved version.
// First: run this file with age 16 and note the output.
// Second: open eligibility-v2.js, set age to 16 there as well, and run it.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 21 && identityVerified === true) {
  console.log("eligible");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 4: Eligibility V2

## Day 4 — Eligibility V2 — Alternative Scenario

**Source JavaScript:** `eligibility-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Gym Membership Eligibility

Use the eligibility logic for customer membership or promotional eligibility decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this improved draft with age 16 and compare its output to eligibility-v1.js.
// First: run this file with age 16 and note the output.
// Second: compare the message here to the message you got from eligibility-v1.js with age 16.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 21 && identityVerified === true) {
  console.log("Eligible to open a savings account.");
} else {
  console.log("Not eligible to open a savings account yet.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 5: Access Tools

## Day 5 — Access Tools — Alternative Scenario

**Source JavaScript:** `access-tools.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isAdult(age) {
  if (age >= 18) {
    return true;
  } else {
    return false;
  }
}

function isVerified(status) {
  if (status === true) {
    return true;
  } else {
    return false;
  }
}

let adultCheck = isAdult(22);
let verifiedCheck = isVerified(false);

console.log(adultCheck);
console.log(verifiedCheck);

// Your task: trace both functions, then run the file and change one call to see what happens
// First: predict what isAdult(22) and isVerified(false) each return
// Second: run the file and confirm the two printed lines match your prediction
// Third: change isVerified(false) to isVerified(true) and run it again
// Each printed line should clearly show true or false for its matching function
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 5: Eligibility Day5

## Day 5 — Eligibility Day5 — Alternative Scenario

**Source JavaScript:** `eligibility-day5.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let personOne = isEligible(30, true);
let personTwo = isEligible(17, true);
let personThree = isEligible(45, false);

console.log(personOne);
console.log(personTwo);
console.log(personThree);

// Your task: predict every line this file prints, then change one call and check again
// First: write down what personOne, personTwo and personThree will each print
// Second: run the file and confirm your predictions
// Third: change isEligible(17, true) to isEligible(19, true) and run it again
// Each printed line should clearly show true or false for its matching person
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 5: Eligibility Function

## Day 5 — Eligibility Function — Alternative Scenario

**Source JavaScript:** `eligibility-function.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function checkEligibility(age, verified) {
  if (age >= 18 && verified === true) {
    console.log("Eligible");
  } else {
    console.log("Not eligible");
  }
}

checkEligibility(22, true);
checkEligibility(16, true);
checkEligibility(40, false);

// Your task: run this file and then change one value to see how reuse works
// First: run the file and read the three printed lines
// Second: change the first call from 22 to 15
// Third: run it again and compare the new output with the old output
// Each printed line should clearly show Eligible or Not eligible for its matching call
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 5: Eligibility Return

## Day 5 — Eligibility Return — Alternative Scenario

**Source JavaScript:** `eligibility-return.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let result = isEligible(22, true);
console.log(result);

// Your task: trace the returned value through this file, then change one value and observe
// First: predict what isEligible(22, true) returns and what result will hold
// Second: run the file and confirm result prints true
// Third: change the call to isEligible(16, true) and run it again
// Each run should print a clear true or false value based on the returned result
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 5: Reorder Check

## Day 5 — Reorder Check — Alternative Scenario

**Source JavaScript:** `reorder-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsReorder(stockLevel, reorderPoint) {
  if (stockLevel < reorderPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnBeans = needsReorder(3, 10);
console.log(lowOnBeans);

// Your task: predict what this file prints before you run it
// First: work out what needsReorder(3, 10) returns
// Second: work out what lowOnBeans then holds
// Third: work out what console.log(lowOnBeans) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Access Log

## Day 6 — Access Log — Alternative Scenario

**Source JavaScript:** `access-log.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file with one more push and predict the results.
// First: predict the current length and last index before running the file.
// Second: add one more push of a value you choose.
// Third: predict the new length and the new last index, then run to check.
// Each prediction should be confirmed by the printed output.

let failedAttempts = [1, 1, 0];

failedAttempts.push(1);

console.log(failedAttempts.length);
console.log(failedAttempts[failedAttempts.length - 1]);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: First Value Starter

## Day 6 — First Value Starter — Alternative Scenario

**Source JavaScript:** `first-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the first transaction in the list.
// First: call getFirst with the transactions array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "First transaction:".
// Each label and value should print together, clearly showing the first transaction.

function getFirst(list) {
  return list[0];
}

let transactions = [40, 132, 18, 60];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Index Practice

## Day 6 — Index Practice — Alternative Scenario

**Source JavaScript:** `index-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: edit the code below so it prints three different wait times from the list.
// First: change the second console.log so it prints the third wait time.
// Second: change the third console.log so it prints the last wait time.
// Third: run the file and check three different numbers appear.
// Fourth: write down which index gave you the last value, and why.
// Each console.log should print a different, correct wait time from the array.

let waitTimes = [12, 5, 30, 8, 21];

console.log(waitTimes[0]);
console.log(waitTimes[0]);
console.log(waitTimes[0]);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Last Value Starter

## Day 6 — Last Value Starter — Alternative Scenario

**Source JavaScript:** `last-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the most recent reading in the list.
// First: call getLast with the readings array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "Most recent reading:".
// Each label and value should print together, clearly showing the last reading.

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let readings = [4, 7, 2, 9, 5];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Length Practice

## Day 6 — Length Practice — Alternative Scenario

**Source JavaScript:** `length-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file so it also reports the last stock level in the list.
// First: add a variable that stores the last index using .length minus one.
// Second: add a console.log that prints the last stock level using that index.
// Third: add a clear label line before it, like "Last stock level:".
// Each console.log should print a clear, correctly labelled value.

let stockLevels = [200, 45, 130, 90, 15, 60];

console.log("Number of items:");
console.log(stockLevels.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: My First Array

## Day 6 — My First Array — Alternative Scenario

**Source JavaScript:** `my-first-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: create your own array of related values from a sector you know and print it.
// First: choose a context, such as wait times, transaction amounts, or stock levels.
// Second: create an array with a clear, descriptive name and at least four values.
// Third: print the whole array with console.log so all the values show at once.
// Each array should print a clear, complete list of values.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Order Report Starter

## Day 6 — Order Report Starter — Alternative Scenario

**Source JavaScript:** `order-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete the weekly order report using the arrays and functions given.
// First: print how many days were recorded using .length with a clear label.
// Second: call getFirst and print the first day's total with a label.
// Third: call getLast and print the last day's total with a label.
// Each fact should print with a clear, correct label so the report reads easily.

function getFirst(list) {
  return list[0];
}

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let dailyOrders = [120, 145, 98, 160, 132];

console.log("Weekly order report");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Push Demo

## Day 6 — Push Demo — Alternative Scenario

**Source JavaScript:** `push-demo.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: an empty array that grows as values are pushed onto it.

let alerts = [];

console.log(alerts.length);

alerts.push("Fridge door open");
alerts.push("Low battery");

console.log(alerts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Push Practice

## Day 6 — Push Practice — Alternative Scenario

**Source JavaScript:** `push-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add two more items to the basket and report the new count.
// First: use .push to add one more product name to the basket.
// Second: use .push again to add a second product name.
// Third: add a label line and print the new count with .length.
// Each addition should grow the basket, and the printed count should reflect it clearly.

let basket = ["Shampoo", "Towel"];

console.log("Items at start:");
console.log(basket.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Scores Array

## Day 6 — Scores Array — Alternative Scenario

**Source JavaScript:** `scores-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: a single named array holding five related score values.

let scores = [72, 65, 90, 48, 81];

console.log(scores);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 6: Transactions Read

## Day 6 — Transactions Read — Alternative Scenario

**Source JavaScript:** `transactions-read.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Café & Retail Data

Use the same array skills with café orders, prices, till values and stock records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what each line below will print, then run the file to check.
// First: write down your predicted output for all four console.log lines.
// Second: run the file and compare the real output to your predictions.
// Third: note any line where your prediction was different, and why.
// Each prediction should be checked against the real, printed value.

let amounts = [40, 132, 9, 300, 15];

console.log(amounts[0]);
console.log(amounts[4]);
console.log(amounts[2]);
console.log(amounts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 7: Accumulator Starter

## Day 7 — Accumulator Starter — Alternative Scenario

**Source JavaScript:** `accumulator-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Fundraising Campaign

Use loops and accumulators to process donations, targets and supporter activity. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete this accumulator loop so it adds up every value in the array.
// First: read the array and the total variable that starts at zero.
// Second: read the for loop header that already visits every item in the array.
// Third: add the missing line inside the loop body that updates total with the current item.
// Fourth: run the file and check the printed total is correct.
// Each pass of the loop should add the current item to the running total.

let bookings = [14, 22, 9, 31, 18, 27, 12];
let total = 0;

for (let i = 0; i < bookings.length; i++) {

}

console.log("Total: " + total);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 7: Predict Loop

## Day 7 — Predict Loop — Alternative Scenario

**Source JavaScript:** `predict-loop.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Fundraising Campaign

Use loops and accumulators to process donations, targets and supporter activity. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this loop will print before you run it.
// First: read the array and the loop carefully without running the file yet.
// Second: write down each line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your prediction to the actual output.
// Fourth: if the output surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let parcels = [154, 89, 203, 47, 176];

for (let i = 0; i < parcels.length; i++) {
  console.log(parcels[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 7: Predict While

## Day 7 — Predict While — Alternative Scenario

**Source JavaScript:** `predict-while.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Fundraising Campaign

Use loops and accumulators to process donations, targets and supporter activity. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this while loop will print before you run it.
// First: read the while loop and trace it on paper, one pass at a time.
// Second: write down every line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your written prediction to the actual output.
// Fourth: if anything surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let dosesRemaining = 4;

while (dosesRemaining > 0) {
  console.log("Doses remaining: " + dosesRemaining);
  dosesRemaining = dosesRemaining - 1;
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 7: Print All Starter

## Day 7 — Print All Starter — Alternative Scenario

**Source JavaScript:** `print-all-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Fundraising Campaign

Use loops and accumulators to process donations, targets and supporter activity. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: modify this loop so it prints a clearer, more useful message for each value.
// First: read the existing loop and the array of dispatch counts.
// Second: change the console.log message so it includes a label and a unit.
// Third: add one more item to the array and run the file to confirm it is printed too.
// Each printed line should show a clear, labelled message including the value and its unit.

let dispatches = [120, 95, 140, 88, 132, 76];

for (let i = 0; i < dispatches.length; i++) {
  console.log(dispatches[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Afternoon Build Starter

## Day 8 — Afternoon Build Starter — Alternative Scenario

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a stock report that updates, counts, and collects routine-stock products
// First: write a for loop that checks each product's stockLevel
// Second: inside the loop, set reorderNeeded to true if stockLevel is beroutine 20
// Third: inside the loop, increment the counter and push the product to the reorderList
// Fourth: after the loop, print the count and each product name in the reorderList
// Each routine-stock product should be flagged, counted, and listed in the final report

let products = [
  { name: "Paracetamol 500mg", category: "pharmacy",
    stockLevel: 12, reorderNeeded: false },
  { name: "Vinyl gloves M", category: "PPE",
    stockLevel: 45, reorderNeeded: false },
  { name: "Saline solution", category: "pharmacy",
    stockLevel: 8, reorderNeeded: false },
  { name: "Alcohol wipes", category: "PPE",
    stockLevel: 3, reorderNeeded: false },
  { name: "Blood pressure cuff", category: "equipment",
    stockLevel: 22, reorderNeeded: false },
  { name: "Surgical tape", category: "consumables",
    stockLevel: 17, reorderNeeded: false },
  { name: "Disposable cups", category: "consumables",
    stockLevel: 60, reorderNeeded: false },
  { name: "Pulse oximeter", category: "equipment",
    stockLevel: 5, reorderNeeded: false }
];

// 1. Declare your counter variable here
// 2. Declare your reorderList array here
// 3. Write your loop beroutine
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Broken Objects

## Day 8 — Broken Objects — Alternative Scenario

**Source JavaScript:** `broken-objects.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix the two bugs in this loop so the count and collected array are correct
// First: move the counter declaration to before the loop
// Second: move the push statement inside the if block
// Third: run the file and check the count and the collected array are now correct
// Each fix should result in an accurate count and a routineStock array with only matching products

let products = [
  { name: "Nitrile gloves S", category: "PPE", stockLevel: 14 },
  { name: "Cotton bandages", category: "consumables", stockLevel: 55 },
  { name: "Insulin vials", category: "pharmacy", stockLevel: 6 },
  { name: "Thermometer digital", category: "equipment", stockLevel: 30 },
  { name: "Face shields", category: "PPE", stockLevel: 9 },
  { name: "Gauze pads", category: "consumables", stockLevel: 18 }
];

let routineStock = [];

for (let i = 0; i < products.length; i++) {
  let count = 0;
  if (products[i].stockLevel < 20) {
    count = count + 1;
  }
  routineStock.push(products[i]);
}

console.log(count);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Count Flag Starter

## Day 8 — Count Flag Starter — Alternative Scenario

**Source JavaScript:** `count-flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: combine a flag update with a running count in one loop
// First: read the existing array and empty loop beroutine
// Second: declare a flaggedCount variable set to 0 before the loop
// Third: inside the loop, flag records where score is beroutine 60 and add to the count
// Fourth: after the loop, print the total number of flagged records
// Each routine-scoring record should be flagged and the final count should print clearly

let assessments = [
  { name: "Elena Cruz", score: 55, flagged: false },
  { name: "Noah Bright", score: 71, flagged: false },
  { name: "Aisha Bello", score: 48, flagged: false },
  { name: "Kofi Mensah", score: 66, flagged: false },
  { name: "Ines Duarte", score: 59, flagged: false },
  { name: "Sam Foster", score: 82, flagged: false },
  { name: "Wei Zhang", score: 37, flagged: false },
  { name: "Rosa Alvarez", score: 91, flagged: false }
];

for (let i = 0; i < assessments.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Flag Starter

## Day 8 — Flag Starter — Alternative Scenario

**Source JavaScript:** `flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: write a loop that flags urgent-value transactions
// First: read the existing array beroutine
// Second: write a for loop that reads each transaction object
// Third: inside the loop, add an if statement: if amount is above 5000, set flagged to true
// Fourth: after the loop, log the flagged value for each transaction to check your work
// Each transaction over 5000 should print true and each other transaction should print false

let transactions = [
  { reference: "TXN-101", customerName: "Freya Lindqvist", amount: 2200, flagged: false },
  { reference: "TXN-102", customerName: "Ben Okafor", amount: 6100, flagged: false },
  { reference: "TXN-103", customerName: "Anya Petrov", amount: 480, flagged: false },
  { reference: "TXN-104", customerName: "Chidi Nwosu", amount: 9800, flagged: false },
  { reference: "TXN-105", customerName: "Laura Kim", amount: 3050, flagged: false },
  { reference: "TXN-106", customerName: "Omar Farouk", amount: 15200, flagged: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Loop Read Starter

## Day 8 — Loop Read Starter — Alternative Scenario

**Source JavaScript:** `loop-read-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend the loop beroutine to print a third property from each learner
// First: read the existing loop and predict what the two console.log lines will print
// Second: add a third console.log inside the loop to also print verified
// Third: run the file and check your output matches your prediction
// Each learner should have their name, score, and verified value printed clearly

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

for (let i = 0; i < learners.length; i++) {
  console.log(learners[i].name);
  console.log(learners[i].score);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Morning Build Starter

## Day 8 — Morning Build Starter — Alternative Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a loop that updates each learner's passed status and prints a report
// First: write a for loop that reads each learner in the array
// Second: inside the loop, set passed to true if score is 65 or above
// Third: inside the loop, print a line naming the learner and whether they passed
// Each learner should have a clear, human-readable line printed to the console

let learners = [
  { name: "Priya", score: 82, passed: false },
  { name: "Marcus", score: 58, passed: false },
  { name: "Leila", score: 74, passed: false },
  { name: "Tom", score: 63, passed: false },
  { name: "Yuki", score: 91, passed: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Predict Array

## Day 8 — Predict Array — Alternative Scenario

**Source JavaScript:** `predict-array.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this array of objects by hand before running the file
// First: write down what each console.log beroutine will print
// Second: run the file and check your predictions were correct
// Third: write a sentence explaining what learners[1].score means in plain English
// Each prediction should be checked against the real output

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

console.log(learners[0].name);
console.log(learners[1].score);
console.log(learners[2].verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Transactions

## Day 8 — Transactions — Alternative Scenario

**Source JavaScript:** `transactions.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this loop by hand, then run the file to check your work
// First: write down what the loop will print for iterations 3 and 4
// Second: run the file and compare the actual output with your trace
// Third: write one sentence explaining what transactions[i].amount means
// Each iteration should print the reference and amount for that transaction

let transactions = [
  { reference: "TXN-001", customerName: "Sofia Andersen",
    amount: 4750, status: "pending", flagged: false },
  { reference: "TXN-002", customerName: "David Osei",
    amount: 320, status: "cleared", flagged: false },
  { reference: "TXN-003", customerName: "Mei Lin",
    amount: 12800, status: "pending", flagged: false },
  { reference: "TXN-004", customerName: "Ravi Patel",
    amount: 95, status: "cleared", flagged: false }
];

for (let i = 0; i < transactions.length; i++) {
  console.log(transactions[i].reference);
  console.log(transactions[i].amount);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Update Loop Starter

## Day 8 — Update Loop Starter — Alternative Scenario

**Source JavaScript:** `update-loop-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a conditional update inside the loop that flags routine-scoring records
// First: read the existing array and loop beroutine
// Second: inside the loop, add an if statement checking whether score is beroutine 65
// Third: if the condition is true, set that object's flagged property to true
// Fourth: after the loop, log the flagged value for each object to check your work
// Each flagged record should print true and each unflagged record should print false

let patients = [
  { name: "Helen Wren", score: 58, flagged: false },
  { name: "Marcus Reid", score: 72, flagged: false },
  { name: "Ola Adeyemi", score: 61, flagged: false },
  { name: "Sian Blake", score: 89, flagged: false },
  { name: "Tomasz Nowak", score: 45, flagged: false }
];

for (let i = 0; i < patients.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 8: Update Practice

## Day 8 — Update Practice — Alternative Scenario

**Source JavaScript:** `update-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — IT Support Desk

Treat the objects and flags as support-ticket records, priorities and status updates. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: update two properties on a patient object using dot notation
// First: read the two console.log lines beroutine and predict what they will print
// Second: change the score property to 95 using dot notation
// Third: change the verified property from false to true
// Each change should be reflected in the console output when you run the file

let patient = {
  name: "Grace Oduya",
  ward: "Cardiology",
  score: 84,
  verified: false,
  priority: "standard"
};

console.log(patient.score);
console.log(patient.verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, folroutine the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Appointment Report

## Day 9 — Appointment Report — Alternative Scenario

**Source JavaScript:** `appointment-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let appointments = [
  { patient: "Grace Okoro", waitDays: 12, urgent: true },
  { patient: "Liam Foster", waitDays: 34, urgent: false },
  { patient: "Nadia Hussain", waitDays: 21, urgent: true },
  { patient: "Robert Chen", waitDays: 8, urgent: false }
];

let totalWaitDays = 0;
let overdueUrgent = [];

// Your task: apply the same report pattern to this appointment dataset.
// First: write a for loop adding each waitDays value to totalWaitDays.
// Second: inside the loop, push patients where urgent is true and waitDays > 14 to overdueUrgent.
// Third: print totalWaitDays and overdueUrgent after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Broken Report

## Day 9 — Broken Report — Alternative Scenario

**Source JavaScript:** `broken-report.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 }
];

let passCount = 0;

for (let i = 0; i <= learners.length; i++) {
  if (learners[i].score >= 50) {
    passCount = passCount + 1;
  }
}

console.log(passCount);

// Your task: find and explain the bug that breaks this loop.
// First: read the loop condition carefully before running anything.
// Second: predict what learners.length equals and what the loop will do.
// Third: run the file and compare the actual error to your prediction.
// Each answer should be a clear, written sentence identifying the bug and why it happens.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Delivery Report

## Day 9 — Delivery Report — Alternative Scenario

**Source JavaScript:** `delivery-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let deliveries = [
  { driver: "Jodie Marsh", parcels: 42, onTimeRate: 96 },
  { driver: "Tomasz Nowak", parcels: 18, onTimeRate: 71 },
  { driver: "Aisha Bello", parcels: 35, onTimeRate: 88 }
];

let totalParcels = 0;
let lowPerformers = [];

// Your task: apply the same report pattern to this delivery dataset.
// First: write a for loop adding each driver's parcels to totalParcels.
// Second: inside the loop, push drivers with onTimeRate below 80 to lowPerformers.
// Third: print both totalParcels and lowPerformers after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Full Report Starter

## Day 9 — Full Report Starter — Alternative Scenario

**Source JavaScript:** `full-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];
let atRiskNames = [];
let totalScore = 0;

// Your task: build one loop that updates all four variables and prints a complete report.
// First: write a for loop counting passes and collecting pass names.
// Second: inside the same loop, collect at-risk names and add to totalScore.
// Third: after the loop, calculate averageScore and print all five results.
// Each printed result should be a clear, correct value matching a hand-worked trace.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Morning Build Starter

## Day 9 — Morning Build Starter — Alternative Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Travel & Transport Reporting

Use the report patterns for bookings, journeys, delays and transport summaries. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];

// Your task: build a loop that prints each learner's name, then checks who passed.
// First: write a for loop that prints each learner's name only.
// Second: run it and confirm all four names print correctly.
// Third: add an if statement checking score >= 50 inside the loop.
// Each stage should print a clear, correct result before you move to the next one.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Appointments Console

## Day 10 — Appointments Console — Alternative Scenario

**Source JavaScript:** `appointments-console.js`  
**Corresponding HTML:** `appointments.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Conference Booking Dashboard</h1>
<p id="appointment-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
let appointments = [
  { patient: "Elena Rossi", urgent: true },
  { patient: "Marcus Green", urgent: false },
  { patient: "Hannah Cole", urgent: true },
  { patient: "Owen Price", urgent: false },
  { patient: "Leila Khan", urgent: true }
];

let urgentCount = 0;

for (let i = 0; i < appointments.length; i++) {
  if (appointments[i].urgent === true) {
    urgentCount = urgentCount + 1;
  }
}

console.log("Urgent appointments: " + urgentCount);

// Your task: move this report from the console onto the page.
// First: select #appointment-summary and store it in a variable called summary.
// Second: replace the console.log line above with a textContent assignment.
// Third: refresh the browser and confirm the count appears where "Waiting for update..." used to be.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 1

## Day 10 — Broken 1 — Alternative Scenario

**Source JavaScript:** `broken-1.js`  
**Corresponding HTML:** `broken-1.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
```

### JavaScript panel
```javascript
let title = document.querySelector("page-title");

title.textContent = "Updated";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 2

## Day 10 — Broken 2 — Alternative Scenario

**Source JavaScript:** `broken-2.js`  
**Corresponding HTML:** `broken-2.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<p id="panel-message">Ready</p>
```

### JavaScript panel
```javascript
let message = document.querySelector("#pannel-message");

message.textContent = "Ready";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Broken 3

## Day 10 — Broken 3 — Alternative Scenario

**Source JavaScript:** `broken-3.js`  
**Corresponding HTML:** `broken-3.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<p id="status-line">Room status</p>
```

### JavaScript panel
```javascript
let status = document.querySelector("#status-line");

let currentText = status.textContent;

// Your task: find and fix the one bug in this script.
// First: read the two lines above and work out what they actually do.
// Second: fix the bug so the page genuinely changes, using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Change Heading

## Day 10 — Change Heading — Alternative Scenario

**Source JavaScript:** `change-heading.js`  
**Corresponding HTML:** `welcome.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
<p id="page-message">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Your task: change the heading text shown on welcome.html.
// First: select #page-title and store it in a variable called heading.
// Second: assign a new string to heading.textContent.
// Third: refresh the browser and confirm the new heading appears on the page.
// Each change should display a clear, helpful message to whoever is looking at the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard — Alternative Scenario

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Hotel Operations Dashboard</h1>
<p id="delayed-count">Waiting for update...</p>
<p id="delayed-list">Waiting for update...</p>
```

### JavaScript panel
```javascript
let deliveries = [
  { id: "R201", status: "delayed" },
  { id: "R202", status: "on time" },
  { id: "R214", status: "delayed" },
  { id: "R225", status: "on time" },
  { id: "R230", status: "delayed" }
];

// Your task: build a dashboard that reports delayed delivery counts and ids.
// First: loop through deliveries and count how many have status "delayed".
// Second: loop through deliveries and build a comma-separated list of delayed ids.
// Third: select #delayed-count and update its text with the count.
// Fourth: select #delayed-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Find Message

## Day 10 — Find Message — Alternative Scenario

**Source JavaScript:** `find-message.js`  
**Corresponding HTML:** `welcome.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="page-title">Conference Portal</h1>
<p id="page-message">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Your task: select the paragraph on the page and log it, then read its plain text.
// First: use querySelector to select #page-message and store it in a variable called message.
// Second: log message to the console and check what it shows.
// Third: read message.textContent into a variable called messageText and log that too.
// Each console.log should print a clear, helpful result you can check against the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Flagged Patients

## Day 10 — Flagged Patients — Alternative Scenario

**Source JavaScript:** `flagged-patients.js`  
**Corresponding HTML:** `flagged-patients.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Patient Dashboard</h1>
<p id="flag-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let patients = [
  { name: "Elena Rossi", flagged: true },
  { name: "Marcus Green", flagged: false },
  { name: "Hannah Cole", flagged: true }
];

let nameList = "";

for (let i = 0; i < patients.length; i++) {
  if (patients[i].flagged === true) {
    nameList = nameList + patients[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Flagged Transactions Starter

## Day 10 — Flagged Transactions Starter — Alternative Scenario

**Source JavaScript:** `flagged-transactions-starter.js`  
**Corresponding HTML:** `flagged-transactions.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Transaction Dashboard</h1>
<p id="flagged-count">Waiting for update...</p>
<p id="flagged-list">Waiting for update...</p>
```

### JavaScript panel
```javascript
let transactions = [
  { id: "T2001", amount: 450 },
  { id: "T2002", amount: 1250 },
  { id: "T2003", amount: 980 },
  { id: "T2004", amount: 3200 },
  { id: "T2005", amount: 1100 }
];

// Your task: apply the dashboard pattern to flag large transactions.
// First: loop through transactions and count how many have amount greater than 1000.
// Second: loop through transactions and build a comma-separated list of flagged transaction ids.
// Third: select #flagged-count and update its text with the count.
// Fourth: select #flagged-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Properties Practice

## Day 10 — Properties Practice — Alternative Scenario

**Source JavaScript:** `properties-practice.js`  
**Corresponding HTML:** `properties-practice.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Status Display</h1>
<p id="status-a">Pending</p>
<p id="status-b">Pending</p>
```

### JavaScript panel
```javascript
// Your task: update two elements with the same string, one using textContent and one using innerHTML.
// First: select #status-a and assign it the string "<i>Confirmed</i>" using textContent.
// Second: select #status-b and assign it the same string using innerHTML.
// Third: refresh the browser and compare how each element displays the string.
// Each element should show a clear, different result so the distinction is obvious.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Reorder List Starter

## Day 10 — Reorder List Starter — Alternative Scenario

**Source JavaScript:** `reorder-list-starter.js`  
**Corresponding HTML:** `reorder-list.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Stock Room Dashboard</h1>
<p id="reorder-summary">Waiting for update...</p>
```

### JavaScript panel
```javascript
let stock = [
  { name: "Filing box", quantity: 4 },
  { name: "Printer paper", quantity: 0 },
  { name: "Desk lamp", quantity: 12 },
  { name: "Staplers", quantity: 2 },
  { name: "Notebooks", quantity: 9 }
];

// Your task: build a reorder list on the page for items running low on stock.
// First: create an empty string called nameList to collect matching names.
// Second: loop through stock and add each item's name to nameList when quantity is less than 5.
// Third: select #reorder-summary and assign the finished list to its text.
// Each update should display a clear, helpful list of products needing reorder.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Status Panel

## Day 10 — Status Panel — Alternative Scenario

**Source JavaScript:** `status-panel.js`  
**Corresponding HTML:** `status-panel.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1 id="panel-title">System Status</h1>
<p id="panel-message">Checking...</p>
```

### JavaScript panel
```javascript
// Your task: update the status panel so it reports the system as healthy.
// First: select #panel-title and store it in a variable called title.
// Second: select #panel-message and store it in a variable called message.
// Third: assign "All Systems Normal" to the title's text.
// Fourth: assign a short reassuring sentence to the message's text.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 10: Unclear Dom

## Day 10 — Unclear Dom — Alternative Scenario

**Source JavaScript:** `unclear-dom.js`  
**Corresponding HTML:** `unclear-dom.html`  
**Type:** Provided activity script

### Alternative practice scenario — Hotel & Conference Dashboard

Use DOM manipulation to update conference bookings, hotel operations and guest-facing page content. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Stock Dashboard</h1>
<p id="s">Waiting for update...</p>
```

### JavaScript panel
```javascript
let x = document.querySelector("#s");

x.textContent = "Low stock items: 2";

// Your task: rename the unclear variables above without changing what the code does.
// First: read through both lines and identify what each variable actually represents.
// Second: rename each variable to something descriptive of its purpose.
// Third: update every place the old variable name was used.
// Each renamed version should run identically and be easy for a colleague to understand.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Afternoon Build Starter

## Day 11 — Afternoon Build Starter — Alternative Scenario

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `afternoon-build-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check Details access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a validated, event-driven access request checker
// First: add an addEventListener for a click on the button
// Second: read clearanceInput.value inside the click handler and store it in a variable
// Third: add a guard for a blank submission
// Fourth: add branches for standard, elevated, restricted and unrecognised values
// Fifth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid and valid clearance levels

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Broken Click

## Day 11 — Broken Click — Alternative Scenario

**Source JavaScript:** `broken-click.js`  
**Corresponding HTML:** `broken-click.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: find and fix the bug that stops the button from working
// First: run this file and click the button, notice that nothing happens
// Second: check the browser console for an error message
// Third: read the error carefully and compare it against a working example from earlier today
// Fourth: fix the bug and confirm the button now updates the result text
// Each fix should make the result text update with a clear, helpful message when clicked

const input = document.querySelector("#scoreInput")
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListner("click", function () {
  result.textContent = "Score received: " + input.value;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Delivery Flag Starter

## Day 11 — Delivery Flag Starter — Alternative Scenario

**Source JavaScript:** `delivery-flag-starter.js`  
**Corresponding HTML:** `delivery-flag-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="trackingInput" type="text" />
  <button id="checkDeliveryButton">Check Details delivery</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a delivery tracking checker that validates a typed tracking number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty tracking number
// Third: add a check using trackingInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const trackingInput = document.querySelector("#trackingInput");
const button = document.querySelector("#checkDeliveryButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Extend Validation Starter

## Day 11 — Extend Validation Starter — Alternative Scenario

**Source JavaScript:** `extend-validation-starter.js`  
**Corresponding HTML:** `extend-validation-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: extend a single-guard checker into a full four-branch validated version
// First: read the existing empty-input guard already written below
// Second: add a range check using else if and logical OR, catching scores below 0 or above 100
// Third: add the final pass or fail branches for valid scores
// Fourth: test with an empty box, an out-of-range number, and a valid number
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  }

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Welcome Customer Input Starter

## Day 11 — Welcome Customer Input Starter — Alternative Scenario

**Source JavaScript:** `greet-input-starter.js`  
**Corresponding HTML:** `greet-input-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="learnerName" type="text" />
  <button id="greetButton">Welcome Customer</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire up a button that reads a typed name and prints a greeting to the console
// First: select the input, the button and store them in variables
// Second: add an addEventListener for a click on the button
// Third: inside the click handler, read the input's value and store it in a variable
// Fourth: build a greeting message using that variable and print it
// Each greeting should print a clear, helpful message that includes the typed name

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Guarded Welcome Customer

## Day 11 — Guarded Welcome Customer — Alternative Scenario

**Source JavaScript:** `guarded-greet.js`  
**Corresponding HTML:** `guarded-greet.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="learnerName" type="text" />
  <button id="greetButton">Welcome Customer</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this worked example showing a guard against an empty typed name
// First: notice the empty string check written before the greeting is built
// Second: notice the else branch only runs once the guard passes
// Third: compare this shape against your own stock lookup guard
// Each result should show a clear, helpful message whether the box is empty or filled in

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const typedName = nameInput.value;

  if (typedName === "") {
    result.textContent = "Please type your name first";
  } else {
    result.textContent = "Hello, " + typedName;
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Morning Build Starter

## Day 11 — Morning Build Starter — Alternative Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `morning-build-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="ageInput" type="text" />
  <button id="checkButton">Check Details eligibility</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire the Day 4 eligibility logic up to a real button and input
// First: add an addEventListener for a click on the button
// Second: read ageInput.value inside the click handler and store it in a variable
// Third: reuse the Day 4 if/else logic, an applicant qualifies if age is 18 or over
// Fourth: write the result to the page using result.textContent
// Each result should show a clear, helpful message of Eligible or Not eligible

const ageInput = document.querySelector("#ageInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Approved Check Detailser Event

## Day 11 — Approved Check Detailser Event — Alternative Scenario

**Source JavaScript:** `pass-checker-event.js`  
**Corresponding HTML:** `pass-checker-event.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this event-driven pass checker against your Day 2 pass-checker.js
// First: read through this file line by line
// Second: list which lines are genuinely new compared to the Day 2 version
// Third: list which lines are unchanged in logic from the Day 2 version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score >= 50) {
    result.textContent = "Approved";
  } else {
    result.textContent = "Review Required";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Approved Check Detailser

## Day 11 — Approved Check Detailser — Alternative Scenario

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this Day 2 pass checker against the event-driven version
// First: read through this file line by line
// Second: note that this version runs immediately, using a fixed score variable
// Third: identify the if/else block that is identical in shape to the newer version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const score = 84;

if (score >= 50) {
  console.log("Approved");
} else {
  console.log("Review Required");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Predict Click Starter

## Day 11 — Predict Click Starter — Alternative Scenario

**Source JavaScript:** `predict-click-starter.js`  
**Corresponding HTML:** `predict-click-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<button id="checkButton">Check Details</button>
```

### JavaScript panel
```javascript
// Your task: predict what prints to the console and in what order, before running this file
// First: read every line below without running it
// Second: write down what you think will print, and in what order
// Third: run the file and click the button to check your prediction
// Each prediction should be written down clearly before you run any code

const button = document.querySelector("#checkButton");

button.addEventListener("click", function () {
  console.log("Check Detailsing now");
});

console.log("Script finished loading");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Stock Find Product Starter

## Day 11 — Stock Find Product Starter — Alternative Scenario

**Source JavaScript:** `stock-lookup-starter.js`  
**Corresponding HTML:** `stock-lookup-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="stockInput" type="text" />
  <button id="lookupButton">Look up</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: add a guard so an empty stock code shows a helpful message instead of a blank result
// First: read the existing addEventListener block below
// Second: add an if check for an empty string before the lookup message
// Third: test with an empty box and then with real text typed in
// Each result should show a clear, helpful message whether the box is empty or filled in

const stockInput = document.querySelector("#stockInput");
const button = document.querySelector("#lookupButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const stockCode = stockInput.value;
  result.textContent = "Looking up stock code: " + stockCode;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Validated Score Check Details

## Day 11 — Validated Score Check Details — Alternative Scenario

**Source JavaScript:** `validated-score-check.js`  
**Corresponding HTML:** `validated-score-check.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check Details</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this fully validated score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  } else if (score < 0 || score > 100) {
    result.textContent = "Score must be between 0 and 100";
  } else if (score >= 50) {
    result.textContent = "Approved";
  } else {
    result.textContent = "Review Required";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Version A

## Day 11 — Version A — Alternative Scenario

**Source JavaScript:** `version-a.js`  
**Corresponding HTML:** `version-a.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check Details access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the separate else if branches used here
// Second: notice each valid clearance level has its own distinct message written out in full
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard") {
    result.textContent = "Standard access granted";
  } else if (clearance === "elevated") {
    result.textContent = "Elevated access granted";
  } else if (clearance === "restricted") {
    result.textContent = "Restricted access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 11: Version B

## Day 11 — Version B — Alternative Scenario

**Source JavaScript:** `version-b.js`  
**Corresponding HTML:** `version-b.html`  
**Type:** Provided activity script

### Alternative practice scenario — Retail Store Interactions

Use inputs, buttons, events and validation in customer-service, stock and store workflows. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check Details access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the single combined condition using logical OR
// Second: notice the message is built dynamically using the clearance variable itself
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard" || clearance === "elevated" || clearance === "restricted") {
    result.textContent = clearance + " access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 12: Refactor Starter

## Day 12 — Refactor Starter — Alternative Scenario

**Source JavaScript:** `refactor-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Alternative practice scenario — Sports Club Administration

Refactor functions that could process registrations, prices, scores and member records. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function reviewSubmission(wordCount, hasReferences, isLate) {
  let verdict = "";

  if (wordCount >= 500) {
    verdict = verdict + "Meets word count. ";
  } else {
    verdict = verdict + "Below word count. ";
  }

  if (hasReferences) {
    verdict = verdict + "References included. ";
  } else {
    verdict = verdict + "References missing. ";
  }

  if (isLate) {
    verdict = verdict + "Submitted late, one grade band lower.";
  } else {
    verdict = verdict + "Submitted on time.";
  }

  return verdict;
}

console.log(reviewSubmission(620, true, false));
console.log(reviewSubmission(410, false, true));
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Daily Tip Widget Starter

## Day 13 — Daily Tip Widget Starter — Alternative Scenario

**Source JavaScript:** `advice-generator-starter.js`  
**Corresponding HTML:** `advice-generator.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Daily Tip Widget</h1>
  <button id="new-advice-button">New Advice</button>
  <p id="advice-display">Loading advice...</p>
```

### JavaScript panel
```javascript
const newAdviceButton = document.querySelector("#new-advice-button");
const adviceBox = document.querySelector("#advice-display");

newAdviceButton.addEventListener("click", function() {
  // Your task: build a working advice generator that shows new advice on every click.
  // First: call fetch with the web address "https://api.adviceslip.com/advice"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.slip.advice and set it as the adviceBox textContent
  // Each click should display a new piece of advice on the page

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Dog Photo Starter

## Day 13 — Dog Photo Starter — Alternative Scenario

**Source JavaScript:** `dog-photo-starter.js`  
**Corresponding HTML:** `dog-photo.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Image Refresh Widget</h1>
  <button id="new-dog-button">New Dog Photo</button>
  <img id="dog-photo" src="" alt="A random dog">
```

### JavaScript panel
```javascript
const dogButton = document.querySelector("#new-dog-button");
const dogImage = document.querySelector("#dog-photo");

dogButton.addEventListener("click", function() {
  // Your task: fetch a new random dog photo every time the button is clicked and show it.
  // First: call fetch with the web address "https://dog.ceo/api/breeds/image/random"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.message and set it as the dogImage src
  // Each click should replace the current photo with a new random dog picture

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Fact Display Starter

## Day 13 — Fact Display Starter — Alternative Scenario

**Source JavaScript:** `fact-display-starter.js`  
**Corresponding HTML:** `fact-display.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Random Fact Widget</h1>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const factBox = document.querySelector("#fact-display");

// Your task: fetch a random cat fact and display just the fact text on the page.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to read data.fact and set it as the factBox textContent
// Each step should leave the page showing a real fact instead of the placeholder text
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: Live Data Test Starter

## Day 13 — Live Data Test Starter — Alternative Scenario

**Source JavaScript:** `first-fetch-starter.js`  
**Corresponding HTML:** `first-fetch-starter.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Live Data Test</h1>
  <p>Open the browser console to see the result.</p>
```

### JavaScript panel
```javascript
// Your task: run a fetch request to a public API and see live data arrive in the console.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to print the data to the console
// Each step should print a clear, helpful result so you can confirm the request worked
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 13: New Fact Starter

## Day 13 — New Fact Starter — Alternative Scenario

**Source JavaScript:** `new-fact-starter.js`  
**Corresponding HTML:** `new-fact.html`  
**Type:** Debug/starter activity

### Alternative practice scenario — Public API Widgets

Use fetch() as the basis of small content widgets that could appear inside a public-facing website. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<h1>Fact Refresh Widget</h1>
  <button id="new-fact-button">New Fact</button>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 14: My Learner Profile (1)

## Day 14 — My Learner Profile (1) — Alternative Scenario

**Source JavaScript:** `my-learner-profile (1).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Freelancer / Contractor Profile

Reuse the final profile pattern as a contractor or project-team profile. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file is already staged and ready to become your first Git commit.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: record this file as your first permanent entry in your project's history.
// First: run git add my-learner-profile.js in your git-practice folder.
// Second: run git commit -m with a short, honest message describing the file.
// Third: read the confirmation output Git gives you after the commit.
// Fourth: compare your commit message with a neighbour's message.
// Each step should print a clear, helpful message confirming what Git has done.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 14: My Learner Profile (2)

## Day 14 — My Learner Profile (2) — Alternative Scenario

**Source JavaScript:** `my-learner-profile (2).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Freelancer / Contractor Profile

Reuse the final profile pattern as a contractor or project-team profile. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file already has one commit in its history. You will now make a second change.

let learnerName = "Sam";
let learnerCourse = "Level 4 Software Developer Apprenticeship";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: commit a second, real change to this file with its own clear message.
// First: change the learnerCourse value above to reflect a new course name.
// Second: save the file, then stage and commit the change with a new message.
// Third: run git log to confirm both commits now appear in your project's history.
// Each step should print a clear, helpful message confirming what Git has recorded.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 14: My Learner Profile

## Day 14 — My Learner Profile — Alternative Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Freelancer / Contractor Profile

Reuse the final profile pattern as a contractor or project-team profile. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This is the file you will copy into your git-practice folder for today's activity.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: turn this project folder into a Git repository ready to track changes.
// First: create a new folder called git-practice on your desktop and copy this file into it.
// Second: open a terminal in that folder and run git init.
// Third: confirm the terminal shows the "Initialized empty Git repository" message.
// Each step should print a clear, helpful confirmation in your terminal before you move on.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

