# JSFiddle Activity — Day 5: Reorder Check

## Day 5 — Reorder Check — Alternative Scenario

**Source JavaScript:** `reorder-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsReorder(stockLevel, reorderPoint) {
  if (stockLevel < reorderPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnBeans = needsReorder(3, 10);
console.log(lowOnBeans);

// Your task: predict what this file prints before you run it
// First: work out what needsReorder(3, 10) returns
// Second: work out what lowOnBeans then holds
// Third: work out what console.log(lowOnBeans) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
