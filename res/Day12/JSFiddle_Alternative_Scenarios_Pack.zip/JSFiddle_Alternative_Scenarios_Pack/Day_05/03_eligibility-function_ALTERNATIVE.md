# JSFiddle Activity — Day 5: Eligibility Function

## Day 5 — Eligibility Function — Alternative Scenario

**Source JavaScript:** `eligibility-function.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Warehouse Operations

Apply functions and return values to warehouse access, reorder and stock-handling decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function checkEligibility(age, verified) {
  if (age >= 18 && verified === true) {
    console.log("Eligible");
  } else {
    console.log("Not eligible");
  }
}

checkEligibility(22, true);
checkEligibility(16, true);
checkEligibility(40, false);

// Your task: run this file and then change one value to see how reuse works
// First: run the file and read the three printed lines
// Second: change the first call from 22 to 15
// Third: run it again and compare the new output with the old output
// Each printed line should clearly show Eligible or Not eligible for its matching call
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
