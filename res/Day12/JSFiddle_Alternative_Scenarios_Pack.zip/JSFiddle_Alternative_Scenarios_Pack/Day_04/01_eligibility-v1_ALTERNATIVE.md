# JSFiddle Activity — Day 4: Eligibility V1

## Day 4 — Eligibility V1 — Alternative Scenario

**Source JavaScript:** `eligibility-v1.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Alternative practice scenario — Gym Membership Eligibility

Use the eligibility logic for customer membership or promotional eligibility decisions. The **JavaScript concept stays the same**, but the sample values and presentation have been varied so delegates can practise transfer rather than memorise one example.

**Delegate extension:** once it works, change at least **two values/messages** of your own, predict the result, then click **Run** to check.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this first draft with age 16 so you can compare it to the improved version.
// First: run this file with age 16 and note the output.
// Second: open eligibility-v2.js, set age to 16 there as well, and run it.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 21 && identityVerified === true) {
  console.log("eligible");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
