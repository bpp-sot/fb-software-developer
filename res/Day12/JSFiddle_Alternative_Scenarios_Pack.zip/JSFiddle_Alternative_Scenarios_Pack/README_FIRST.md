# JSFiddle Alternative Scenarios Pack

This companion pack mirrors the main 14-day JSFiddle Delegate Pack, but provides a second practice context for every activity.

## Use
- HTML block -> JSFiddle HTML panel
- JavaScript block -> JavaScript panel
- CSS block -> CSS panel
- Run and use the Console where needed

These are parallel practice activities, not answer sheets. Starter/debugging exercises remain starter/debugging exercises.
