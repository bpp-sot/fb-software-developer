# Day 9 — Credit & Data Compliance Scenarios

**Theme:** Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics.

**Activities:** 5

# JSFiddle Activity — Day 9: Appointment Report

## Day 9 — Appointment Report — Credit & Data Compliance Scenario

**Source JavaScript:** `appointment-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let appointments = [
  { patient: "Grace Okoro", waitDays: 12, urgent: true },
  { patient: "Liam Foster", waitDays: 34, urgent: false },
  { patient: "Nadia Hussain", waitDays: 21, urgent: true },
  { patient: "Robert Chen", waitDays: 8, urgent: false }
];

let totalWaitDays = 0;
let overdueUrgent = [];

// Your task: apply the same report pattern to this appointment dataset.
// First: write a for loop adding each waitDays value to totalWaitDays.
// Second: inside the loop, push patients where urgent is true and waitDays > 14 to overdueUrgent.
// Third: print totalWaitDays and overdueUrgent after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Broken Report

## Day 9 — Broken Report — Credit & Data Compliance Scenario

**Source JavaScript:** `broken-report.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Meera Shah", score: 45, attendance: 88 }
];

let passCount = 0;

for (let i = 0; i <= learners.length; i++) {
  if (learners[i].score >= 50) {
    passCount = passCount + 1;
  }
}

console.log(passCount);

// Your task: find and explain the bug that breaks this loop.
// First: read the loop condition carefully before running anything.
// Second: predict what learners.length equals and what the loop will do.
// Third: run the file and compare the actual error to your prediction.
// Each answer should be a clear, written sentence identifying the bug and why it happens.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Delivery Report

## Day 9 — Delivery Report — Credit & Data Compliance Scenario

**Source JavaScript:** `delivery-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let deliveries = [
  { driver: "Jodie Marsh", parcels: 42, onTimeRate: 96 },
  { driver: "Tomasz Nowak", parcels: 18, onTimeRate: 71 },
  { driver: "Aisha Bello", parcels: 35, onTimeRate: 88 }
];

let totalParcels = 0;
let lowPerformers = [];

// Your task: apply the same report pattern to this delivery dataset.
// First: write a for loop adding each driver's parcels to totalParcels.
// Second: inside the loop, push drivers with onTimeRate below 80 to lowPerformers.
// Third: print both totalParcels and lowPerformers after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Full Report Starter

## Day 9 — Full Report Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `full-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Meera Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];
let atRiskNames = [];
let totalScore = 0;

// Your task: build one loop that updates all four variables and prints a complete report.
// First: write a for loop counting passes and collecting pass names.
// Second: inside the same loop, collect at-risk names and add to totalScore.
// Third: after the loop, calculate averageScore and print all five results.
// Each printed result should be a clear, correct value matching a hand-worked trace.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 9: Morning Build Starter

## Day 9 — Morning Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Meera Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];

// Your task: build a loop that prints each learner's name, then checks who passed.
// First: write a for loop that prints each learner's name only.
// Second: run it and confirm all four names print correctly.
// Third: add an if statement checking score >= 50 inside the loop.
// Each stage should print a clear, correct result before you move to the next one.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

