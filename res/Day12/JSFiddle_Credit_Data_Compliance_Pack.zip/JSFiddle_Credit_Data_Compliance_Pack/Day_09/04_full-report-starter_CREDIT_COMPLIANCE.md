# JSFiddle Activity — Day 9: Full Report Starter

## Day 9 — Full Report Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `full-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit & Compliance Reporting

Build reports from application outcomes, exception cases, overdue reviews and operational metrics. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Meera Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];
let atRiskNames = [];
let totalScore = 0;

// Your task: build one loop that updates all four variables and prints a complete report.
// First: write a for loop counting passes and collecting pass names.
// Second: inside the same loop, collect at-risk names and add to totalScore.
// Third: after the loop, calculate averageScore and print all five results.
// Each printed result should be a clear, correct value matching a hand-worked trace.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
