# JSFiddle Activity — Day 8: Loop Read Starter

## Day 8 — Loop Read Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `loop-read-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Case Management & Data Quality

Use objects and loops for suspicious-activity cases, missing data, risk flags and remediation. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend the loop below to print a third property from each learner
// First: read the existing loop and predict what the two console.log lines will print
// Second: add a third console.log inside the loop to also print verified
// Third: run the file and check your output matches your prediction
// Each learner should have their name, score, and verified value printed clearly

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

for (let i = 0; i < learners.length; i++) {
  console.log(learners[i].name);
  console.log(learners[i].score);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
