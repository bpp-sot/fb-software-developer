# JSFiddle Activity — Day 8: Broken Objects

## Day 8 — Broken Objects — Credit & Data Compliance Scenario

**Source JavaScript:** `broken-objects.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Case Management & Data Quality

Use objects and loops for suspicious-activity cases, missing data, risk flags and remediation. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix the two bugs in this loop so the count and collected array are correct
// First: move the counter declaration to before the loop
// Second: move the push statement inside the if block
// Third: run the file and check the count and the collected array are now correct
// Each fix should result in an accurate count and a lowStock array with only matching products

let products = [
  { name: "Nitrile gloves S", category: "PPE", stockLevel: 14 },
  { name: "Cotton bandages", category: "consumables", stockLevel: 55 },
  { name: "Insulin vials", category: "pharmacy", stockLevel: 6 },
  { name: "Thermometer digital", category: "equipment", stockLevel: 30 },
  { name: "Face shields", category: "PPE", stockLevel: 9 },
  { name: "Gauze pads", category: "consumables", stockLevel: 18 }
];

let lowStock = [];

for (let i = 0; i < products.length; i++) {
  let count = 0;
  if (products[i].stockLevel < 20) {
    count = count + 1;
  }
  lowStock.push(products[i]);
}

console.log(count);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
