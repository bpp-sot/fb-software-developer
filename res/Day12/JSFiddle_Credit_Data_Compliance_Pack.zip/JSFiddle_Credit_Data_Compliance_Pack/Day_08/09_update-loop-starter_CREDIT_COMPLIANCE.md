# JSFiddle Activity — Day 8: Update Loop Starter

## Day 8 — Update Loop Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `update-loop-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Case Management & Data Quality

Use objects and loops for suspicious-activity cases, missing data, risk flags and remediation. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a conditional update inside the loop that flags low-scoring records
// First: read the existing array and loop below
// Second: inside the loop, add an if statement checking whether score is below 65
// Third: if the condition is true, set that object's flagged property to true
// Fourth: after the loop, log the flagged value for each object to check your work
// Each flagged record should print true and each unflagged record should print false

let patients = [
  { name: "Helen Wren", score: 58, flagged: false },
  { name: "Marcus Reid", score: 72, flagged: false },
  { name: "Ola Adeyemi", score: 61, flagged: false },
  { name: "Sian Blake", score: 89, flagged: false },
  { name: "Tomasz Nowak", score: 45, flagged: false }
];

for (let i = 0; i < patients.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
