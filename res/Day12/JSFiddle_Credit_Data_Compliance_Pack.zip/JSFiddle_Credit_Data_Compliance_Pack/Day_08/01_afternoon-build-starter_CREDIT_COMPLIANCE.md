# JSFiddle Activity — Day 8: Afternoon Build Starter

## Day 8 — Afternoon Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Case Management & Data Quality

Use objects and loops for suspicious-activity cases, missing data, risk flags and remediation. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a stock report that updates, counts, and collects low-stock products
// First: write a for loop that checks each product's stockLevel
// Second: inside the loop, set reorderNeeded to true if stockLevel is below 20
// Third: inside the loop, increment the counter and push the product to the reorderList
// Fourth: after the loop, print the count and each product name in the reorderList
// Each low-stock product should be flagged, counted, and listed in the final report

let products = [
  { name: "Paracetamol 500mg", category: "pharmacy",
    stockLevel: 12, reorderNeeded: false },
  { name: "Vinyl gloves M", category: "PPE",
    stockLevel: 45, reorderNeeded: false },
  { name: "Saline solution", category: "pharmacy",
    stockLevel: 8, reorderNeeded: false },
  { name: "Alcohol wipes", category: "PPE",
    stockLevel: 3, reorderNeeded: false },
  { name: "Blood pressure cuff", category: "equipment",
    stockLevel: 22, reorderNeeded: false },
  { name: "Surgical tape", category: "consumables",
    stockLevel: 17, reorderNeeded: false },
  { name: "Disposable cups", category: "consumables",
    stockLevel: 60, reorderNeeded: false },
  { name: "Pulse oximeter", category: "equipment",
    stockLevel: 5, reorderNeeded: false }
];

// 1. Declare your counter variable here
// 2. Declare your reorderList array here
// 3. Write your loop below
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
