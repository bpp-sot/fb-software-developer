# JSFiddle Activity — Day 5: Reapplication Check

## Day 5 — Reapplication Check — Credit & Data Compliance Scenario

**Source JavaScript:** `reapplication-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Functions

Apply functions and return values to access-control, KYC and approval decisions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsReapplication(stockLevel, reapplicationPoint) {
  if (stockLevel < reapplicationPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnMilk = needsReapplication(3, 10);
console.log(lowOnMilk);

// Your task: predict what this file prints before you run it
// First: work out what needsReapplication(3, 10) returns
// Second: work out what lowOnMilk then holds
// Third: work out what console.log(lowOnMilk) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
