# JSFiddle Activity — Day 5: Eligibility Return

## Day 5 — Eligibility Return — Credit & Data Compliance Scenario

**Source JavaScript:** `eligibility-return.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Functions

Apply functions and return values to access-control, KYC and approval decisions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let result = isEligible(22, true);
console.log(result);

// Your task: trace the returned value through this file, then change one value and observe
// First: predict what isEligible(22, true) returns and what result will hold
// Second: run the file and confirm result prints true
// Third: change the call to isEligible(16, true) and run it again
// Each run should print a clear true or false value based on the returned result
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
