# JSFiddle Activity — Day 5: Eligibility Day5

## Day 5 — Eligibility Day5 — Credit & Data Compliance Scenario

**Source JavaScript:** `eligibility-day5.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Functions

Apply functions and return values to access-control, KYC and approval decisions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let personOne = isEligible(30, true);
let personTwo = isEligible(17, true);
let personThree = isEligible(45, false);

console.log(personOne);
console.log(personTwo);
console.log(personThree);

// Your task: predict every line this file prints, then change one call and check again
// First: write down what personOne, personTwo and personThree will each print
// Second: run the file and confirm your predictions
// Third: change isEligible(17, true) to isEligible(19, true) and run it again
// Each printed line should clearly show true or false for its matching person
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
