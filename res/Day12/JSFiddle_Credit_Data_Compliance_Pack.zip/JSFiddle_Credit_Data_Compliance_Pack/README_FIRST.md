# JSFiddle Credit Risk & Data Compliance Pack

This pack mirrors the original 14-day JSFiddle delegate pack but recasts the exercises around credit risk, customer data and compliance.

## Typical contexts
- affordability and credit scoring
- KYC / customer identity checks
- AML and transaction monitoring
- consent and data completeness
- access control and audit logging
- exception / remediation cases
- overdue reviews
- compliance reporting
- customer and transaction data quality

## JSFiddle workflow
1. Paste HTML into the HTML panel.
2. Paste JavaScript into the JavaScript panel.
3. Paste CSS if supplied.
4. Click Run and use the Console where relevant.

Starter and debugging exercises remain intentionally incomplete/broken where appropriate.

All policy thresholds and compliance rules in this pack are fictional training examples only.
