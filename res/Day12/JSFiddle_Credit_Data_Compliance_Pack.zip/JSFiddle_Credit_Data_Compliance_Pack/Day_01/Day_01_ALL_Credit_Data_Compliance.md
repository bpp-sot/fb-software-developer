# Day 1 — Credit & Data Compliance Scenarios

**Theme:** Customer Data & Consent

Use basic variables and strings for customer records, consent status and onboarding details.

**Activities:** 3

# JSFiddle Activity — Day 1: Greet Learner

## Day 1 — Greet Learner — Credit & Data Compliance Scenario

**Source JavaScript:** `greet-learner.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer Data & Consent

Use basic variables and strings for customer records, consent status and onboarding details. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Amina Yusuf");
greetLearner("Thomas Reid");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: Learner Profile

## Day 1 — Learner Profile — Credit & Data Compliance Scenario

**Source JavaScript:** `learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer Data & Consent

Use basic variables and strings for customer records, consent status and onboarding details. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a new property to the learner profile object and print it.
// First: read the existing learner object below and notice how each property is written.
// Second: add a new property called "city" with your city name as the value, remembering the comma after the previous property.
// Third: add a console.log line that prints the new "city" property.
// Each console.log line should print a clear, correct value for that property.

let learner = {
  name: "Ella Morgan",
  age: 24,
  cohort: "Credit & Data Compliance Academy",
  employer: "Northbank Compliance"
};

console.log(learner.name);
console.log(learner.employer);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: My Learner Profile

## Day 1 — My Learner Profile — Credit & Data Compliance Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer Data & Consent

Use basic variables and strings for customer records, consent status and onboarding details. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build your own personalised learner profile using the pattern from today.
// First: change the property values in the learner object below to your own name, age, cohort, employer, and start year.
// Second: run the file and confirm the welcome message shows your own name.
// Third: write down exactly what appears in the console.
// Each console.log message should print a clear, personalised welcome message using your own details.

let learner = {
  name: "Thomas Reid",
  age: 23,
  cohort: "Credit & Data Compliance Academy",
  employer: "Westbridge Credit Risk",
  startYear: 2025
};

function greetLearner(name) {
  let message = "Welcome to Credit & Data Compliance, " + name;
  console.log(message);
}

greetLearner(learner.name);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

