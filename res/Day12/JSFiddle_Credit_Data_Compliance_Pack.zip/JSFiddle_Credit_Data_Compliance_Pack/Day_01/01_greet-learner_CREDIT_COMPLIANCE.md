# JSFiddle Activity — Day 1: Greet Learner

## Day 1 — Greet Learner — Credit & Data Compliance Scenario

**Source JavaScript:** `greet-learner.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer Data & Consent

Use basic variables and strings for customer records, consent status and onboarding details. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Amina Yusuf");
greetLearner("Thomas Reid");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
