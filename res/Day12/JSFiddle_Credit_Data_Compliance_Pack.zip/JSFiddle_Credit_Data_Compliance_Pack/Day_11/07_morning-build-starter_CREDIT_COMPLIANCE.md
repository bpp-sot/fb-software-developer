# JSFiddle Activity — Day 11: Morning Build Starter

## Day 11 — Morning Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `morning-build-starter.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="ageInput" type="text" />
  <button id="checkButton">Check eligibility</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire the Day 4 eligibility logic up to a real button and input
// First: add an addEventListener for a click on the button
// Second: read ageInput.value inside the click handler and store it in a variable
// Third: reuse the Day 4 if/else logic, an applicant qualifies if age is 18 or over
// Fourth: write the result to the page using result.textContent
// Each result should show a clear, helpful message of Eligible or Not eligible

const ageInput = document.querySelector("#ageInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
