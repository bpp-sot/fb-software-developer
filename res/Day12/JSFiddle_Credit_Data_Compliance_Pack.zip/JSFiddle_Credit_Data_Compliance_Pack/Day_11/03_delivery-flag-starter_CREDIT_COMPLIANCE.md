# JSFiddle Activity — Day 11: Application Flag Starter

## Day 11 — Application Flag Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `application-flag-starter.js`  
**Corresponding HTML:** `application-flag-starter.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="case referenceInput" type="text" />
  <button id="checkApplicationButton">Check application</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a application case reference checker that validates a typed case reference number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty case reference number
// Third: add a check using case referenceInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const case referenceInput = document.querySelector("#case referenceInput");
const button = document.querySelector("#checkApplicationButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
