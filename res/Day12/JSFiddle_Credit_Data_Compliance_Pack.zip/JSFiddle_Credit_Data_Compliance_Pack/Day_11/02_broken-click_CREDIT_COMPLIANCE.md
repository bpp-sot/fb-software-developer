# JSFiddle Activity — Day 11: Broken Click

## Day 11 — Broken Click — Credit & Data Compliance Scenario

**Source JavaScript:** `broken-click.js`  
**Corresponding HTML:** `broken-click.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="credit scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: find and fix the bug that stops the button from working
// First: run this file and click the button, notice that nothing happens
// Second: check the browser console for an error message
// Third: read the error carefully and compare it against a working example from earlier today
// Fourth: fix the bug and confirm the button now updates the result text
// Each fix should make the result text update with a clear, helpful message when clicked

const input = document.querySelector("#credit scoreInput")
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListner("click", function () {
  result.textContent = "Credit Score received: " + input.value;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
