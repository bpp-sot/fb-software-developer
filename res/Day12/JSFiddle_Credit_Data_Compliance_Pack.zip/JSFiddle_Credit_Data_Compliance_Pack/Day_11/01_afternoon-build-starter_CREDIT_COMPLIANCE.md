# JSFiddle Activity — Day 11: Afternoon Build Starter

## Day 11 — Afternoon Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `afternoon-build-starter.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="risk bandInput" type="text" />
  <button id="checkAccessButton">Check access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a validated, event-driven access request checker
// First: add an addEventListener for a click on the button
// Second: read risk bandInput.value inside the click handler and store it in a variable
// Third: add a guard for a blank submission
// Fourth: add branches for standard, elevated, restricted and unrecognised values
// Fifth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid and valid risk band levels

const risk bandInput = document.querySelector("#risk bandInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
