# JSFiddle Activity — Day 11: Validated Credit Score Check

## Day 11 — Validated Credit Score Check — Credit & Data Compliance Scenario

**Source JavaScript:** `validated-credit score-check.js`  
**Corresponding HTML:** `validated-credit score-check.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="credit scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this fully validated credit score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample credit scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const credit scoreInput = document.querySelector("#credit scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const credit score = credit scoreInput.value;

  if (credit score === "") {
    result.textContent = "Please enter a credit score";
  } else if (credit score < 0 || credit score > 100) {
    result.textContent = "Credit Score must be between 0 and 100";
  } else if (credit score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
