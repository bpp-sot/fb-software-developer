# JSFiddle Activity — Day 11: Guarded Greet

## Day 11 — Guarded Greet — Credit & Data Compliance Scenario

**Source JavaScript:** `guarded-greet.js`  
**Corresponding HTML:** `guarded-greet.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Interactive Compliance Forms

Use inputs, buttons, events and validation for credit, consent and KYC workflows. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<input id="customerName" type="text" />
  <button id="greetButton">Greet</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this worked example showing a guard against an empty typed name
// First: notice the empty string check written before the greeting is built
// Second: notice the else branch only runs once the guard passes
// Third: compare this shape against your own stock lookup guard
// Each result should show a clear, helpful message whether the box is empty or filled in

const nameInput = document.querySelector("#customerName");
const button = document.querySelector("#greetButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const typedName = nameInput.value;

  if (typedName === "") {
    result.textContent = "Please type your name first";
  } else {
    result.textContent = "Hello, " + typedName;
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
