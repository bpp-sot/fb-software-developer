# JSFiddle Activity — Day 12: Refactor Starter

## Day 12 — Refactor Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `refactor-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Reusable Risk & Compliance Functions

Refactor functions that evaluate applications, records, limits, exceptions and completeness. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function reviewApplication(declaredIncome, hasKycEvidence, isOverdueReview) {
  let verdict = "";

  if (declaredIncome >= 500) {
    verdict = verdict + "Meets word count. ";
  } else {
    verdict = verdict + "Below word count. ";
  }

  if (hasKycEvidence) {
    verdict = verdict + "References included. ";
  } else {
    verdict = verdict + "References missing. ";
  }

  if (isOverdueReview) {
    verdict = verdict + "Submitted late, one grade band lower.";
  } else {
    verdict = verdict + "Submitted on time.";
  }

  return verdict;
}

console.log(reviewApplication(620, true, false));
console.log(reviewApplication(410, false, true));
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
