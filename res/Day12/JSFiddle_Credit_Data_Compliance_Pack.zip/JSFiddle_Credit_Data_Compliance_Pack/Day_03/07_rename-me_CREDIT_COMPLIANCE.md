# JSFiddle Activity — Day 3: Rename Me

## Day 3 — Rename Me — Credit & Data Compliance Scenario

**Source JavaScript:** `rename-me.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — KYC, AML & Customer Checks

Apply conditions to identity checks, sanctions screening, payment reviews and account restrictions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rename every variable in this stock check so the file explains itself.
// First: read the comparison below and work out what a, b and c represent.
// Second: replace a, b and c with descriptive names everywhere they appear.
// Third: run the file and confirm the output logic is unchanged.
// Each variable name should make the comparison and result clear on first read.

let a = 250;
let b = 300;
let c = false;

if (a < b) {
  c = true;
}

console.log(c);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
