# JSFiddle Activity — Day 3: Fix Comments

## Day 3 — Fix Comments — Credit & Data Compliance Scenario

**Source JavaScript:** `fix-comments.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — KYC, AML & Customer Checks

Apply conditions to identity checks, sanctions screening, payment reviews and account restrictions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix every comment in this fraud check so each one earns its place.
// First: delete the comment that only restates the code.
// Second: replace the vague "check" comment with a comment saying what the check actually decides.
// Third: add one comment explaining why riskLimit might be set to 70.
// Each remaining comment should add real meaning that the code on its own cannot give.

// set score to 80
let fraudScore = 80;
let riskLimit = 70;

// check
if (fraudScore > riskLimit) {
  console.log("review needed");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
