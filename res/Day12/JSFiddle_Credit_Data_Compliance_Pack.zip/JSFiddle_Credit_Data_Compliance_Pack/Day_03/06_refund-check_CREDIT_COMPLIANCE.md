# JSFiddle Activity — Day 3: Payment Reversal Check

## Day 3 — Payment Reversal Check — Credit & Data Compliance Scenario

**Source JavaScript:** `payment reversal-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — KYC, AML & Customer Checks

Apply conditions to identity checks, sanctions screening, payment reviews and account restrictions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this payment reversal check to a customer service colleague using no technical words at all.
// First: write what the code decides in one plain sentence as a comment.
// Second: remove any word from that sentence a non-developer would not know.
// Third: read it to a partner playing the customer service role and ask them to flag any word they did not understand.
// Each explanation should be fully understandable to someone with no coding background.

let orderAge = 45;
let payment reversalWindow = 30;

if (orderAge > payment reversalWindow) {
  console.log("Outside the payment reversal window.");
} else {
  console.log("Payment Reversal can be processed.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
