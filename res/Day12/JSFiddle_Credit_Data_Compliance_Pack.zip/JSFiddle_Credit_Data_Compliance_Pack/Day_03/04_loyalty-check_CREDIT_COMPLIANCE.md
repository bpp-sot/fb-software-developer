# JSFiddle Activity — Day 3: Loyalty Check

## Day 3 — Loyalty Check — Credit & Data Compliance Scenario

**Source JavaScript:** `loyalty-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — KYC, AML & Customer Checks

Apply conditions to identity checks, sanctions screening, payment reviews and account restrictions. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this loyalty check two ways, once for a developer and once for a non-technical colleague.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one they understood faster.
// Each explanation should give a clear, accurate sentence for its intended audience.

let pointsBalance = 420;
let rewardThreshold = 400;

if (pointsBalance >= rewardThreshold) {
  console.log("Reward unlocked.");
} else {
  console.log("Keep collecting points.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
