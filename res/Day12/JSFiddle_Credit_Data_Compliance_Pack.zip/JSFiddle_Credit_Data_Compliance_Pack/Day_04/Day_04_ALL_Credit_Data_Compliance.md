# Day 4 — Credit & Data Compliance Scenarios

**Theme:** Eligibility & Policy Rules

Use conditional logic for age, income, debt-to-income, residency and product-policy rules.

**Activities:** 2

# JSFiddle Activity — Day 4: Eligibility V1

## Day 4 — Eligibility V1 — Credit & Data Compliance Scenario

**Source JavaScript:** `eligibility-v1.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Eligibility & Policy Rules

Use conditional logic for age, income, debt-to-income, residency and product-policy rules. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this first draft with age 16 so you can compare it to the improved version.
// First: run this file with age 16 and note the output.
// Second: open eligibility-v2.js, set age to 16 there as well, and run it.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 18 && identityVerified === true) {
  console.log("eligible");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 4: Eligibility V2

## Day 4 — Eligibility V2 — Credit & Data Compliance Scenario

**Source JavaScript:** `eligibility-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Eligibility & Policy Rules

Use conditional logic for age, income, debt-to-income, residency and product-policy rules. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this improved draft with age 16 and compare its output to eligibility-v1.js.
// First: run this file with age 16 and note the output.
// Second: compare the message here to the message you got from eligibility-v1.js with age 16.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 18 && identityVerified === true) {
  console.log("Eligible to open a savings account.");
} else {
  console.log("Not eligible to open a savings account yet.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

