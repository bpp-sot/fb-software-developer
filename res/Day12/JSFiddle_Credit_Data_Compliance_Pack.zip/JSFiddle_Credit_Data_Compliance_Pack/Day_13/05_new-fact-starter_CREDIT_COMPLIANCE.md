# JSFiddle Activity — Day 13: New Fact Starter

## Day 13 — New Fact Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `new-fact-starter.js`  
**Corresponding HTML:** `new-fact.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Compliance Data/API Widgets

Use fetch() patterns for simple internal widgets and reference-data lookups. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Reference Refresh Widget</h1>
  <button id="new-fact-button">New Fact</button>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
