# JSFiddle Activity — Day 6: Risk Scores Array

## Day 6 — Risk Scores Array — Credit & Data Compliance Scenario

**Source JavaScript:** `riskRisk Scores-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer & Transaction Data

Use arrays to work with customer records, balances, transactions and compliance flags. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: a single named array holding five related score values.

let riskRisk Scores = [72, 65, 90, 48, 81];

console.log(riskRisk Scores);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
