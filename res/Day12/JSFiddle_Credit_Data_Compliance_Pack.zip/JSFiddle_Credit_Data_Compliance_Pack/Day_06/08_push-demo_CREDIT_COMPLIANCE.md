# JSFiddle Activity — Day 6: Push Demo

## Day 6 — Push Demo — Credit & Data Compliance Scenario

**Source JavaScript:** `push-demo.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer & Transaction Data

Use arrays to work with customer records, balances, transactions and compliance flags. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: an empty array that grows as values are pushed onto it.

let alerts = [];

console.log(alerts.length);

alerts.push("Fridge door open");
alerts.push("Low battery");

console.log(alerts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
