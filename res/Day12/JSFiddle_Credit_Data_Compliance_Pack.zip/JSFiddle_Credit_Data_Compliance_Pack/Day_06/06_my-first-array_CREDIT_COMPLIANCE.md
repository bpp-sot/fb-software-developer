# JSFiddle Activity — Day 6: My First Array

## Day 6 — My First Array — Credit & Data Compliance Scenario

**Source JavaScript:** `my-first-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer & Transaction Data

Use arrays to work with customer records, balances, transactions and compliance flags. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: create your own array of related values from a sector you know and print it.
// First: choose a context, such as wait times, transaction amounts, or stock levels.
// Second: create an array with a clear, descriptive name and at least four values.
// Third: print the whole array with console.log so all the values show at once.
// Each array should print a clear, complete list of values.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
