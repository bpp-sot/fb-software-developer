# JSFiddle Activity — Day 6: Access Log

## Day 6 — Access Log — Credit & Data Compliance Scenario

**Source JavaScript:** `access-log.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Customer & Transaction Data

Use arrays to work with customer records, balances, transactions and compliance flags. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file with one more push and predict the results.
// First: predict the current length and last index before running the file.
// Second: add one more push of a value you choose.
// Third: predict the new length and the new last index, then run to check.
// Each prediction should be confirmed by the printed output.

let failedAttempts = [1, 1, 0];

failedAttempts.push(1);

console.log(failedAttempts.length);
console.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
