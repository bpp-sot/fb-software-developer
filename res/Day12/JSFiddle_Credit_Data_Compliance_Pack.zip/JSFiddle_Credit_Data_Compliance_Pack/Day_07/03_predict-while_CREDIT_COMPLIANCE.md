# JSFiddle Activity — Day 7: Predict While

## Day 7 — Predict While — Credit & Data Compliance Scenario

**Source JavaScript:** `predict-while.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Monitoring & Thresholds

Use loops and accumulators to process transaction values, alert thresholds and monitoring totals. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this while loop will print before you run it.
// First: read the while loop and trace it on paper, one pass at a time.
// Second: write down every line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your written prediction to the actual output.
// Fourth: if anything surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let dosesRemaining = 4;

while (dosesRemaining > 0) {
  console.log("Doses remaining: " + dosesRemaining);
  dosesRemaining = dosesRem
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
