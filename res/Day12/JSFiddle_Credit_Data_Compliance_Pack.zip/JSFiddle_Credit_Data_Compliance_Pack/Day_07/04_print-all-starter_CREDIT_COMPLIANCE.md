# JSFiddle Activity — Day 7: Print All Starter

## Day 7 — Print All Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `print-all-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Monitoring & Thresholds

Use loops and accumulators to process transaction values, alert thresholds and monitoring totals. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: modify this loop so it prints a clearer, more useful message for each value.
// First: read the existing loop and the array of dispatch counts.
// Second: change the console.log message so it includes a label and a unit.
// Third: add one more item to the array and run the file to confirm it is printed too.
// Each printed line should show a clear, labelled message including the value and its unit.

let dispatches = [120, 95, 140, 88, 132, 76];

for (let i = 0; i < dispatches.length; i++) {
  console.log(dispatches[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
