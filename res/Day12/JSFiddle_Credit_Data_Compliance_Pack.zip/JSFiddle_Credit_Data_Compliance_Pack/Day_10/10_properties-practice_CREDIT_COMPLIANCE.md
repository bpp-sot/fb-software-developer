# JSFiddle Activity — Day 10: Properties Practice

## Day 10 — Properties Practice — Credit & Data Compliance Scenario

**Source JavaScript:** `properties-practice.js`  
**Corresponding HTML:** `properties-practice.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Status Display</h1>
<p id="status-a">Pending</p>
<p id="status-b">Pending</p>
```

### JavaScript panel
```javascript
// Your task: update two elements with the same string, one using textContent and one using innerHTML.
// First: select #status-a and assign it the string "<i>Confirmed</i>" using textContent.
// Second: select #status-b and assign it the same string using innerHTML.
// Third: refresh the browser and compare how each element displays the string.
// Each element should show a clear, different result so the distinction is obvious.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
