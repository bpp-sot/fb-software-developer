# JSFiddle Activity — Day 10: Reviews Console

## Day 10 — Reviews Console — Credit & Data Compliance Scenario

**Source JavaScript:** `reviews-console.js`  
**Corresponding HTML:** `reviews.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Compliance Review Dashboard</h1>
<p id="review-summary">Checking record...</p>
```

### JavaScript panel
```javascript
let reviews = [
  { customer: "Amina Yusuf", urgent: true },
  { customer: "Daniel Hughes", urgent: false },
  { customer: "Meera Shah", urgent: true },
  { customer: "Oliver Grant", urgent: false },
  { customer: "Elena Costa", urgent: true }
];

let urgentCount = 0;

for (let i = 0; i < reviews.length; i++) {
  if (reviews[i].urgent === true) {
    urgentCount = urgentCount + 1;
  }
}

console.log("Urgent reviews: " + urgentCount);

// Your task: move this report from the console onto the page.
// First: select #review-summary and store it in a variable called summary.
// Second: replace the console.log line above with a textContent assignment.
// Third: refresh the browser and confirm the count appears where "Checking record..." used to be.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
