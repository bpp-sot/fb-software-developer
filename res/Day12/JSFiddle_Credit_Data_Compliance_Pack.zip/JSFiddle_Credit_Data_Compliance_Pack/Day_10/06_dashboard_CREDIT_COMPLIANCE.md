# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard — Credit & Data Compliance Scenario

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Credit Decision Dashboard</h1>
<p id="requires review-count">Checking record...</p>
<p id="requires review-list">Checking record...</p>
```

### JavaScript panel
```javascript
let applications = [
  { id: "CASE1001", status: "requires review" },
  { id: "CASE1002", status: "cleared" },
  { id: "CASE1014", status: "requires review" },
  { id: "CASE1025", status: "cleared" },
  { id: "CASE1030", status: "requires review" }
];

// Your task: build a dashboard that reports requires review application counts and ids.
// First: loop through applications and count how many have status "requires review".
// Second: loop through applications and build a comma-separated list of requires review ids.
// Third: select #requires review-count and update its text with the count.
// Fourth: select #requires review-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
