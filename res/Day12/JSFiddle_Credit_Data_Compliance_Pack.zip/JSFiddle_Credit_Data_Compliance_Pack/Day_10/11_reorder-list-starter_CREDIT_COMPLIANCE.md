# JSFiddle Activity — Day 10: Reorder List Starter

## Day 10 — Reorder List Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `reorder-list-starter.js`  
**Corresponding HTML:** `reorder-list.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Stock Room Dashboard</h1>
<p id="reorder-summary">Checking record...</p>
```

### JavaScript panel
```javascript
let stock = [
  { name: "Filing box", quantity: 4 },
  { name: "Printer paper", quantity: 0 },
  { name: "Desk lamp", quantity: 12 },
  { name: "Staplers", quantity: 2 },
  { name: "Notebooks", quantity: 9 }
];

// Your task: build a reorder list on the page for items running low on stock.
// First: create an empty string called nameList to collect matching names.
// Second: loop through stock and add each item's name to nameList when quantity is less than 5.
// Third: select #reorder-summary and assign the finished list to its text.
// Each update should display a clear, helpful list of products needing reorder.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
