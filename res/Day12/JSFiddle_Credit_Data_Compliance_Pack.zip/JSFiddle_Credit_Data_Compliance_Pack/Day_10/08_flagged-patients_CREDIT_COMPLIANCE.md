# JSFiddle Activity — Day 10: High-Risk Customers

## Day 10 — High-Risk Customers — Credit & Data Compliance Scenario

**Source JavaScript:** `flagged-customers.js`  
**Corresponding HTML:** `flagged-customers.html`  
**Type:** Provided activity script

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Customer Dashboard</h1>
<p id="flag-summary">Checking record...</p>
```

### JavaScript panel
```javascript
// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let customers = [
  { name: "Amina Yusuf", flagged: true },
  { name: "Daniel Hughes", flagged: false },
  { name: "Meera Shah", flagged: true }
];

let nameList = "";

for (let i = 0; i < customers.length; i++) {
  if (customers[i].flagged === true) {
    nameList = nameList + customers[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
