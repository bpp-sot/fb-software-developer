# JSFiddle Activity — Day 10: Flagged Transactions Starter

## Day 10 — Flagged Transactions Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `flagged-transactions-starter.js`  
**Corresponding HTML:** `flagged-transactions.html`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Compliance Dashboard

Use DOM manipulation to display customer-risk, consent and review information in a browser. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<h1>Transaction Dashboard</h1>
<p id="flagged-count">Checking record...</p>
<p id="flagged-list">Checking record...</p>
```

### JavaScript panel
```javascript
let transactions = [
  { id: "T2001", amount: 450 },
  { id: "T2002", amount: 1250 },
  { id: "T2003", amount: 980 },
  { id: "T2004", amount: 3200 },
  { id: "T2005", amount: 1100 }
];

// Your task: apply the dashboard pattern to flag large transactions.
// First: loop through transactions and count how many have amount greater than 1000.
// Second: loop through transactions and build a comma-separated list of flagged transaction ids.
// Third: select #flagged-count and update its text with the count.
// Fourth: select #flagged-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
