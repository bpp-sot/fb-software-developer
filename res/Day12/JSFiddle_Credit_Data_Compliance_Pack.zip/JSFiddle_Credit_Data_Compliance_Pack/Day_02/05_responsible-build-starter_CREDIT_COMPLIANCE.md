# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationCredit Score = 110;
let approveMark = 75;

// Your task: build a responsible checker that validates the creditCredit Score and age before deciding approve or fail.
// First: check if applicationCredit Score is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationCredit Score meets or exceeds approveMark and print a approve message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
