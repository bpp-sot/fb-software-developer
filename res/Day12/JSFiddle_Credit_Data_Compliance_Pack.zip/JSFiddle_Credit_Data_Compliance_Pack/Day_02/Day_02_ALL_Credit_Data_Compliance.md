# Day 2 — Credit & Data Compliance Scenarios

**Theme:** Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes.

**Activities:** 5

# JSFiddle Activity — Day 2: Approve Checker V2

## Day 2 — Approve Checker V2 — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateCredit Score and the value of approveMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateCredit Score = 105;
let approveMark = 50;

if (candidateCredit Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker V3

## Day 2 — Approve Checker V3 — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated approve checker with three different creditCredit Scores and record what happens.
// First: run the file with candidateCredit Score set to 105 and write down the output.
// Second: change candidateCredit Score to 72, run it again, and write down the output.
// Third: change candidateCredit Score to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateCredit Score = 105;
let approveMark = 50;

if (candidateCredit Score < 0 || candidateCredit Score > 100) {
  console.log("Invalid creditCredit Score. Please enter a number between 0 and 100.");
} else if (candidateCredit Score >= approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker V4

## Day 2 — Approve Checker V4 — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker-v4.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this file with approve-checker.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateCredit Score = 60;
let approveMark = 60;

if (candidateCredit Score < 0 || candidateCredit Score > 100) {
  console.log("Invalid creditCredit Score. Please enter a number between 0 and 100.");
} else if (candidateCredit Score >= approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker

## Day 2 — Approve Checker — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's approve checker with approve-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateCredit Score = 72;
let approveMark = 50;

if (candidateCredit Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Credit & Data Compliance Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationCredit Score = 110;
let approveMark = 75;

// Your task: build a responsible checker that validates the creditCredit Score and age before deciding approve or fail.
// First: check if applicationCredit Score is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationCredit Score meets or exceeds approveMark and print a approve message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

