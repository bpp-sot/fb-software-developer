# JSFiddle Activity — Day 2: Approve Checker

## Day 2 — Approve Checker — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's approve checker with approve-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateCredit Score = 72;
let approveMark = 50;

if (candidateCredit Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
