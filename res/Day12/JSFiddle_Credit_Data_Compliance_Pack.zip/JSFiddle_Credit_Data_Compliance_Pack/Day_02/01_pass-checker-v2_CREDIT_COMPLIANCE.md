# JSFiddle Activity — Day 2: Approve Checker V2

## Day 2 — Approve Checker V2 — Credit & Data Compliance Scenario

**Source JavaScript:** `approve-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit Scoring & Affordability

Use comparisons and decision logic for credit scores, affordability thresholds and lending outcomes. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateCredit Score and the value of approveMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateCredit Score = 105;
let approveMark = 50;

if (candidateCredit Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
