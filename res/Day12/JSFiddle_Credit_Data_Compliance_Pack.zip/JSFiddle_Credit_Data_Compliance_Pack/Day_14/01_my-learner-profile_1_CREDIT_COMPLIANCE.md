# JSFiddle Activity — Day 14: My Analyst Profile (1)

## Day 14 — My Analyst Profile (1) — Credit & Data Compliance Scenario

**Source JavaScript:** `my-analyst-profile (1).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Credit & data compliance scenario — Credit / Compliance Analyst Profile

Reuse the final profile pattern for a credit-risk, data-governance or compliance analyst. The **JavaScript concept stays the same** as the original exercise, but the practice context is now credit-risk, data-governance or compliance focused.

**Delegate challenge:** get the exercise working, then change at least **two policy values, customer details, thresholds or messages** and predict the result before clicking **Run**.

> Training scenario only: values and rules are illustrative and are not intended to represent any real bank's policy or legal/regulatory requirement.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 analyst profile script
// This file is already staged and ready to become your first Git commit.

let analystName = "Sam";
let analystCourse = "Level 3 Diploma";

console.log(analystName + " is studying " + analystCourse);

// Your task: record this file as your first permanent entry in your data remediation project's history.
// First: run git add my-analyst-profile.js in your git-practice folder.
// Second: run git commit -m with a short, honest message describing the file.
// Third: read the confirmation output Git gives you after the commit.
// Fourth: compare your commit message with a neighbour's message.
// Each step should print a clear, helpful message confirming what Git has done.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
