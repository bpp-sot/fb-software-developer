# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Banking Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationRisk Score = 110;
let approveMark = 75;

// Your task: build a responsible checker that validates the riskRisk Score and age before deciding approve or fail.
// First: check if applicationRisk Score is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationRisk Score meets or exceeds approveMark and print a approve message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
