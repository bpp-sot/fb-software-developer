# Day 2 — Banking Scenarios

**Theme:** Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks.

**Activities:** 5

# JSFiddle Activity — Day 2: Approve Checker V2

## Day 2 — Approve Checker V2 — Banking Scenario

**Source JavaScript:** `approve-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateRisk Score and the value of approveMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateRisk Score = 105;
let approveMark = 50;

if (candidateRisk Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker V3

## Day 2 — Approve Checker V3 — Banking Scenario

**Source JavaScript:** `approve-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated approve checker with three different riskRisk Scores and record what happens.
// First: run the file with candidateRisk Score set to 105 and write down the output.
// Second: change candidateRisk Score to 72, run it again, and write down the output.
// Third: change candidateRisk Score to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateRisk Score = 105;
let approveMark = 50;

if (candidateRisk Score < 0 || candidateRisk Score > 100) {
  console.log("Invalid riskRisk Score. Please enter a number between 0 and 100.");
} else if (candidateRisk Score >= approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker V4

## Day 2 — Approve Checker V4 — Banking Scenario

**Source JavaScript:** `approve-checker-v4.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this file with approve-checker.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateRisk Score = 60;
let approveMark = 60;

if (candidateRisk Score < 0 || candidateRisk Score > 100) {
  console.log("Invalid riskRisk Score. Please enter a number between 0 and 100.");
} else if (candidateRisk Score >= approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Approve Checker

## Day 2 — Approve Checker — Banking Scenario

**Source JavaScript:** `approve-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this morning's approve checker with approve-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateRisk Score = 72;
let approveMark = 50;

if (candidateRisk Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter — Banking Scenario

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationRisk Score = 110;
let approveMark = 75;

// Your task: build a responsible checker that validates the riskRisk Score and age before deciding approve or fail.
// First: check if applicationRisk Score is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationRisk Score meets or exceeds approveMark and print a approve message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

