# JSFiddle Activity — Day 2: Approve Checker V2

## Day 2 — Approve Checker V2 — Banking Scenario

**Source JavaScript:** `approve-checker-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateRisk Score and the value of approveMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateRisk Score = 105;
let approveMark = 50;

if (candidateRisk Score > approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
