# JSFiddle Activity — Day 2: Approve Checker V3

## Day 2 — Approve Checker V3 — Banking Scenario

**Source JavaScript:** `approve-checker-v3.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Credit & Risk Decisions

Use comparisons and pass/fail logic for affordability, risk and eligibility checks. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this validated approve checker with three different riskRisk Scores and record what happens.
// First: run the file with candidateRisk Score set to 105 and write down the output.
// Second: change candidateRisk Score to 72, run it again, and write down the output.
// Third: change candidateRisk Score to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateRisk Score = 105;
let approveMark = 50;

if (candidateRisk Score < 0 || candidateRisk Score > 100) {
  console.log("Invalid riskRisk Score. Please enter a number between 0 and 100.");
} else if (candidateRisk Score >= approveMark) {
  console.log("Approve");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
