# JSFiddle Banking Scenarios Pack

This pack mirrors the original 14-day JSFiddle delegate pack but rewrites the practice context for banking and financial services.

## Suggested uses
- second attempt after the main Skillable exercise;
- industry-specific reinforcement;
- paired debugging;
- extension work for faster delegates;
- homework or revision;
- showing how the same JavaScript pattern transfers to real banking workflows.

## JSFiddle workflow
1. Paste the HTML block into the HTML panel.
2. Paste JavaScript into the JavaScript panel.
3. Paste CSS if supplied.
4. Click Run and check the browser output or Console.

Starter/debugging activities remain starter/debugging activities.
