# JSFiddle Activity — Day 9: Morning Build Starter

## Day 9 — Morning Build Starter — Banking Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Banking MI & Reporting

Build reports from accounts, payments, service cases and operational data. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Meera Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];

// Your task: build a loop that prints each learner's name, then checks who passed.
// First: write a for loop that prints each learner's name only.
// Second: run it and confirm all four names print correctly.
// Third: add an if statement checking score >= 50 inside the loop.
// Each stage should print a clear, correct result before you move to the next one.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
