# JSFiddle Activity — Day 3: Clarity Build Starter

## Day 3 — Clarity Build Starter — Banking Scenario

**Source JavaScript:** `clarity-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Customer Service & Payments

Apply conditions to card, payment, refund and account-support scenarios. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite this file so it reads clearly to a new teammate, using everything you practised today.
// First: rename x, y and z to descriptive names and fix or remove the misleading comment.
// Second: rewrite "yes" and "no" into clear, full sentences.
// Third: run the file and confirm the logic still works for both outcomes.
// Each part of the file should read clearly on its own, with no explanation needed.

// set x to 5
let x = 5;
let y = 3;
let z = false;

if (x > y) {
  z = true;
}

if (z === true) {
  console.log("yes");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
