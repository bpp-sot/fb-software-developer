# JSFiddle Activity — Day 3: Chargeback Check

## Day 3 — Chargeback Check — Banking Scenario

**Source JavaScript:** `chargeback-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Service & Payments

Apply conditions to card, payment, refund and account-support scenarios. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this chargeback check to a customer service colleague using no technical words at all.
// First: write what the code decides in one plain sentence as a comment.
// Second: remove any word from that sentence a non-developer would not know.
// Third: read it to a partner playing the customer service role and ask them to flag any word they did not understand.
// Each explanation should be fully understandable to someone with no coding background.

let orderAge = 45;
let chargebackWindow = 30;

if (orderAge > chargebackWindow) {
  console.log("Outside the chargeback window.");
} else {
  console.log("Chargeback can be processed.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
