# JSFiddle Activity — Day 6: Access Log

## Day 6 — Access Log — Banking Scenario

**Source JavaScript:** `access-log.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file with one more push and predict the results.
// First: predict the current length and last index before running the file.
// Second: add one more push of a value you choose.
// Third: predict the new length and the new last index, then run to check.
// Each prediction should be confirmed by the printed output.

let failedAttempts = [1, 1, 0];

failedAttempts.push(1);

console.log(failedAttempts.length);
console.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
