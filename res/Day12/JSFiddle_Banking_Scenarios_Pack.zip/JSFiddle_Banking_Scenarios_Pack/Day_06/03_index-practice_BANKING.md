# JSFiddle Activity — Day 6: Index Practice

## Day 6 — Index Practice — Banking Scenario

**Source JavaScript:** `index-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: edit the code below so it prints three different wait times from the list.
// First: change the second console.log so it prints the third wait time.
// Second: change the third console.log so it prints the last wait time.
// Third: run the file and check three different numbers appear.
// Fourth: write down which index gave you the last value, and why.
// Each console.log should print a different, correct wait time from the array.

let waitTimes = [12, 5, 30, 8, 21];

console.log(waitTimes[0]);
console.log(waitTimes[0]);
console.log(waitTimes[0]);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
