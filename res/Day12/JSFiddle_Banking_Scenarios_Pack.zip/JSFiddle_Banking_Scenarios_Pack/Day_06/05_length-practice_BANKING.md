# JSFiddle Activity — Day 6: Length Practice

## Day 6 — Length Practice — Banking Scenario

**Source JavaScript:** `length-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file so it also reports the last stock level in the list.
// First: add a variable that stores the last index using .length minus one.
// Second: add a console.log that prints the last stock level using that index.
// Third: add a clear label line before it, like "Last stock level:".
// Each console.log should print a clear, correctly labelled value.

let stockLevels = [200, 45, 130, 90, 15, 60];

console.log("Number of items:");
console.log(stockLevels.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
