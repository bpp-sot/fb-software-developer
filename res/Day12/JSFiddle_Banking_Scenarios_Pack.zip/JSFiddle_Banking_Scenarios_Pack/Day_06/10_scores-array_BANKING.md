# JSFiddle Activity — Day 6: Balances Array

## Day 6 — Balances Array — Banking Scenario

**Source JavaScript:** `balances-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: a single named array holding five related score values.

let balances = [72, 65, 90, 48, 81];

console.log(balances);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
