# JSFiddle Activity — Day 6: My First Array

## Day 6 — My First Array — Banking Scenario

**Source JavaScript:** `my-first-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: create your own array of related values from a sector you know and print it.
// First: choose a context, such as wait times, transaction amounts, or stock levels.
// Second: create an array with a clear, descriptive name and at least four values.
// Third: print the whole array with console.log so all the values show at once.
// Each array should print a clear, complete list of values.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
