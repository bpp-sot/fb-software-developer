# JSFiddle Activity — Day 6: Order Report Starter

## Day 6 — Order Report Starter — Banking Scenario

**Source JavaScript:** `order-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete the weekly order report using the arrays and functions given.
// First: print how many days were recorded using .length with a clear label.
// Second: call getFirst and print the first day's total with a label.
// Third: call getLast and print the last day's total with a label.
// Each fact should print with a clear, correct label so the report reads easily.

function getFirst(list) {
  return list[0];
}

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let dailyOrders = [120, 145, 98, 160, 132];

console.log("Weekly order report");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
