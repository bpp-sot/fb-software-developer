# JSFiddle Activity — Day 6: First Value Starter

## Day 6 — First Value Starter — Banking Scenario

**Source JavaScript:** `first-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Transactions & Account Data

Use arrays to process balances, transactions, products and account activity. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the first transaction in the list.
// First: call getFirst with the transactions array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "First transaction:".
// Each label and value should print together, clearly showing the first transaction.

function getFirst(list) {
  return list[0];
}

let transactions = [40, 125, 18, 60];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
