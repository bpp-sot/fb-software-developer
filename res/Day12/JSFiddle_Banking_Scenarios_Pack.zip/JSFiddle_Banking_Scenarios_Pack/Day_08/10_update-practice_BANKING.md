# JSFiddle Activity — Day 8: Update Practice

## Day 8 — Update Practice — Banking Scenario

**Source JavaScript:** `update-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Fraud & Case Management

Use objects and loops to handle fraud alerts, investigation cases and priority records. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: update two properties on a patient object using dot notation
// First: read the two console.log lines below and predict what they will print
// Second: change the score property to 95 using dot notation
// Third: change the verified property from false to true
// Each change should be reflected in the console output when you run the file

let patient = {
  name: "Grace Oduya",
  ward: "Cardiology",
  score: 84,
  verified: false,
  highRisk: "standard"
};

console.log(patient.score);
console.log(patient.verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
