# JSFiddle Activity — Day 8: Predict Array

## Day 8 — Predict Array — Banking Scenario

**Source JavaScript:** `predict-array.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Fraud & Case Management

Use objects and loops to handle fraud alerts, investigation cases and priority records. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this array of objects by hand before running the file
// First: write down what each console.log below will print
// Second: run the file and check your predictions were correct
// Third: write a sentence explaining what learners[1].score means in plain English
// Each prediction should be checked against the real output

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

console.log(learners[0].name);
console.log(learners[1].score);
console.log(learners[2].verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
