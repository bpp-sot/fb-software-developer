# JSFiddle Activity — Day 8: Morning Build Starter

## Day 8 — Morning Build Starter — Banking Scenario

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Fraud & Case Management

Use objects and loops to handle fraud alerts, investigation cases and priority records. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a loop that updates each learner's passed status and prints a report
// First: write a for loop that reads each learner in the array
// Second: inside the loop, set passed to true if score is 65 or above
// Third: inside the loop, print a line naming the learner and whether they passed
// Each learner should have a clear, human-readable line printed to the console

let learners = [
  { name: "Priya", score: 82, passed: false },
  { name: "Marcus", score: 58, passed: false },
  { name: "Leila", score: 74, passed: false },
  { name: "Tom", score: 63, passed: false },
  { name: "Yuki", score: 91, passed: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
