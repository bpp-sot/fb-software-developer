# JSFiddle Activity — Day 11: Payment Flag Starter

## Day 11 — Payment Flag Starter — Banking Scenario

**Source JavaScript:** `payment-flag-starter.js`  
**Corresponding HTML:** `payment-flag-starter.html`  
**Type:** Debug/starter activity

### Banking practice scenario — Interactive Banking Forms

Use inputs, buttons, events and validation for account and transaction workflows. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<input id="payment referenceInput" type="text" />
  <button id="checkPaymentButton">Check payment</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a payment payment reference checker that validates a typed payment reference number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty payment reference number
// Third: add a check using payment referenceInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const payment referenceInput = document.querySelector("#payment referenceInput");
const button = document.querySelector("#checkPaymentButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
