# JSFiddle Activity — Day 11: Version B

## Day 11 — Version B — Banking Scenario

**Source JavaScript:** `version-b.js`  
**Corresponding HTML:** `version-b.html`  
**Type:** Provided activity script

### Banking practice scenario — Interactive Banking Forms

Use inputs, buttons, events and validation for account and transaction workflows. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<input id="risk bandInput" type="text" />
  <button id="checkAccessButton">Check access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the single combined condition using logical OR
// Second: notice the message is built dynamically using the risk band variable itself
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const risk bandInput = document.querySelector("#risk bandInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const risk band = risk bandInput.value;

  if (risk band === "") {
    result.textContent = "Please enter a risk band level";
  } else if (risk band === "standard" || risk band === "elevated" || risk band === "restricted") {
    result.textContent = risk band + " access granted";
  } else {
    result.textContent = "Unrecognised risk band level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
