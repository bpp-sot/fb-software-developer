# JSFiddle Activity — Day 11: Validated Score Check

## Day 11 — Validated Score Check — Banking Scenario

**Source JavaScript:** `validated-score-check.js`  
**Corresponding HTML:** `validated-score-check.html`  
**Type:** Provided activity script

### Banking practice scenario — Interactive Banking Forms

Use inputs, buttons, events and validation for account and transaction workflows. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this fully validated score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  } else if (score < 0 || score > 100) {
    result.textContent = "Score must be between 0 and 100";
  } else if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
