# Day 1 — Banking Scenarios

**Theme:** Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context.

**Activities:** 3

# JSFiddle Activity — Day 1: Greet Learner

## Day 1 — Greet Learner — Banking Scenario

**Source JavaScript:** `greet-learner.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Aisha Rahman");
greetLearner("James Clarke");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: Learner Profile

## Day 1 — Learner Profile — Banking Scenario

**Source JavaScript:** `learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a new property to the learner profile object and print it.
// First: read the existing learner object below and notice how each property is written.
// Second: add a new property called "city" with your city name as the value, remembering the comma after the previous property.
// Third: add a console.log line that prints the new "city" property.
// Each console.log line should print a clear, correct value for that property.

let learner = {
  name: "Nina Patel",
  age: 24,
  cohort: "Digital Banking Academy",
  employer: "Northbank Retail"
};

console.log(learner.name);
console.log(learner.employer);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

# JSFiddle Activity — Day 1: My Learner Profile

## Day 1 — My Learner Profile — Banking Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build your own personalised learner profile using the pattern from today.
// First: change the property values in the learner object below to your own name, age, cohort, employer, and start year.
// Second: run the file and confirm the welcome message shows your own name.
// Third: write down exactly what appears in the console.
// Each console.log message should print a clear, personalised welcome message using your own details.

let learner = {
  name: "James Clarke",
  age: 23,
  cohort: "Digital Banking Academy",
  employer: "Westbridge Bank",
  startYear: 2025
};

function greetLearner(name) {
  let message = "Welcome to Digital Banking, " + name;
  console.log(message);
}

greetLearner(learner.name);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

