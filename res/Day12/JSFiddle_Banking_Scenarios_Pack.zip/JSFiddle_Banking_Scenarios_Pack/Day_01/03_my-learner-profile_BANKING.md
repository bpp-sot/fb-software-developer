# JSFiddle Activity — Day 1: My Learner Profile

## Day 1 — My Learner Profile — Banking Scenario

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build your own personalised learner profile using the pattern from today.
// First: change the property values in the learner object below to your own name, age, cohort, employer, and start year.
// Second: run the file and confirm the welcome message shows your own name.
// Third: write down exactly what appears in the console.
// Each console.log message should print a clear, personalised welcome message using your own details.

let learner = {
  name: "James Clarke",
  age: 23,
  cohort: "Digital Banking Academy",
  employer: "Westbridge Bank",
  startYear: 2025
};

function greetLearner(name) {
  let message = "Welcome to Digital Banking, " + name;
  console.log(message);
}

greetLearner(learner.name);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
