# JSFiddle Activity — Day 1: Greet Learner

## Day 1 — Greet Learner — Banking Scenario

**Source JavaScript:** `greet-learner.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Customer Accounts & Onboarding

Use simple variables, strings and messages in a retail-banking onboarding context. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this code and observe exactly what appears in the console.
// First: read the code below from top to bottom before running anything.
// Second: run the file in your editor or console.
// Third: write down exactly what appears, in the order it appears.
// Each console.log line inside the function should print a clear, personalised welcome message.

function greetLearner(name) {
  let message = "Welcome, " + name;
  console.log(message);
}

greetLearner("Aisha Rahman");
greetLearner("James Clarke");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
