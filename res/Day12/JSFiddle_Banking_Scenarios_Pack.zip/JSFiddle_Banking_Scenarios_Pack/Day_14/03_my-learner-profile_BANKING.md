# JSFiddle Activity — Day 14: My Analyst Profile

## Day 14 — My Analyst Profile — Banking Scenario

**Source JavaScript:** `my-analyst-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Banking Analyst Profile

Reuse the final profile pattern for a banking analyst or technology professional. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 analyst profile script
// This is the file you will copy into your git-practice folder for today's activity.

let analystName = "Sam";
let analystCourse = "Level 3 Diploma";

console.log(analystName + " is studying " + analystCourse);

// Your task: turn this transformation project folder into a Git repository ready to track changes.
// First: create a new folder called git-practice on your desktop and copy this file into it.
// Second: open a terminal in that folder and run git init.
// Third: confirm the terminal shows the "Initialized empty Git repository" message.
// Each step should print a clear, helpful confirmation in your terminal before you move on.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
