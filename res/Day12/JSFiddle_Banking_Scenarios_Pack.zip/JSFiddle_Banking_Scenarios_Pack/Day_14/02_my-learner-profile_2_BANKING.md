# JSFiddle Activity — Day 14: My Analyst Profile (2)

## Day 14 — My Analyst Profile (2) — Banking Scenario

**Source JavaScript:** `my-analyst-profile (2).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Banking Analyst Profile

Reuse the final profile pattern for a banking analyst or technology professional. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 analyst profile script
// This file already has one commit in its history. You will now make a second change.

let analystName = "Sam";
let analystCourse = "Level 4 Software Developer Apprenticeship";

console.log(analystName + " is studying " + analystCourse);

// Your task: commit a second, real change to this file with its own clear message.
// First: change the analystCourse value above to reflect a new course name.
// Second: save the file, then stage and commit the change with a new message.
// Third: run git log to confirm both commits now appear in your transformation project's history.
// Each step should print a clear, helpful message confirming what Git has recorded.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
