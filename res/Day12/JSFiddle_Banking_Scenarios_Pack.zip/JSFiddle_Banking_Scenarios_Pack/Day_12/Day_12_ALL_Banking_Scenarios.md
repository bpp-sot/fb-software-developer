# Day 12 — Banking Scenarios

**Theme:** Product & Customer Functions

Refactor functions that work with customers, products, limits and eligibility.

**Activities:** 1

# JSFiddle Activity — Day 12: Refactor Starter

## Day 12 — Refactor Starter — Banking Scenario

**Source JavaScript:** `refactor-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### Banking practice scenario — Product & Customer Functions

Refactor functions that work with customers, products, limits and eligibility. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function reviewApplication(wordCount, hasReferences, isLate) {
  let verdict = "";

  if (wordCount >= 500) {
    verdict = verdict + "Meets word count. ";
  } else {
    verdict = verdict + "Below word count. ";
  }

  if (hasReferences) {
    verdict = verdict + "References included. ";
  } else {
    verdict = verdict + "References missing. ";
  }

  if (isLate) {
    verdict = verdict + "Submitted late, one grade band lower.";
  } else {
    verdict = verdict + "Submitted on time.";
  }

  return verdict;
}

console.log(reviewApplication(620, true, false));
console.log(reviewApplication(410, false, true));
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


---

