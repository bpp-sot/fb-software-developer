# JSFiddle Activity — Day 5: Eligibility Return

## Day 5 — Eligibility Return — Banking Scenario

**Source JavaScript:** `eligibility-return.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Branch & Operations Functions

Apply functions and return values to branch, access and payment-processing decisions. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let result = isEligible(22, true);
console.log(result);

// Your task: trace the returned value through this file, then change one value and observe
// First: predict what isEligible(22, true) returns and what result will hold
// Second: run the file and confirm result prints true
// Third: change the call to isEligible(16, true) and run it again
// Each run should print a clear true or false value based on the returned result
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
