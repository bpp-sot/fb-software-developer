# JSFiddle Activity — Day 5: Repayment Check

## Day 5 — Repayment Check — Banking Scenario

**Source JavaScript:** `repayment-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### Banking practice scenario — Branch & Operations Functions

Apply functions and return values to branch, access and payment-processing decisions. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsRepayment(stockLevel, repaymentPoint) {
  if (stockLevel < repaymentPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnMilk = needsRepayment(3, 10);
console.log(lowOnMilk);

// Your task: predict what this file prints before you run it
// First: work out what needsRepayment(3, 10) returns
// Second: work out what lowOnMilk then holds
// Third: work out what console.log(lowOnMilk) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
