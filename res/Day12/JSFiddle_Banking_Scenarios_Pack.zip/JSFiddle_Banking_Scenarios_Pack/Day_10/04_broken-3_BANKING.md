# JSFiddle Activity — Day 10: Broken 3

## Day 10 — Broken 3 — Banking Scenario

**Source JavaScript:** `broken-3.js`  
**Corresponding HTML:** `broken-3.html`  
**Type:** Debug/starter activity

### Banking practice scenario — Online Banking Dashboard

Use DOM manipulation to update account, payment and customer information in a browser. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<p id="status-line">Current status</p>
```

### JavaScript panel
```javascript
let status = document.querySelector("#status-line");

let currentText = status.textContent;

// Your task: find and fix the one bug in this script.
// First: read the two lines above and work out what they actually do.
// Second: fix the bug so the page genuinely changes, using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
