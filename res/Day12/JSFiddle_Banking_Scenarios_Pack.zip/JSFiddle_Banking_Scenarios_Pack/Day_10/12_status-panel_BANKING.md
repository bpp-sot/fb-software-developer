# JSFiddle Activity — Day 10: Status Panel

## Day 10 — Status Panel — Banking Scenario

**Source JavaScript:** `status-panel.js`  
**Corresponding HTML:** `status-panel.html`  
**Type:** Provided activity script

### Banking practice scenario — Online Banking Dashboard

Use DOM manipulation to update account, payment and customer information in a browser. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1 id="panel-title">System Status</h1>
<p id="panel-message">Checking...</p>
```

### JavaScript panel
```javascript
// Your task: update the status panel so it reports the system as healthy.
// First: select #panel-title and store it in a variable called title.
// Second: select #panel-message and store it in a variable called message.
// Third: assign "All Systems Normal" to the title's text.
// Fourth: assign a short reassuring sentence to the message's text.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
