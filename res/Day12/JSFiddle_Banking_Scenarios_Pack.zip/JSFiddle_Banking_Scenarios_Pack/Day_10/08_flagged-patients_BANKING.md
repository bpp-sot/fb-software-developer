# JSFiddle Activity — Day 10: High-Risk Customers

## Day 10 — High-Risk Customers — Banking Scenario

**Source JavaScript:** `flagged-customers.js`  
**Corresponding HTML:** `flagged-customers.html`  
**Type:** Provided activity script

### Banking practice scenario — Online Banking Dashboard

Use DOM manipulation to update account, payment and customer information in a browser. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Customer Dashboard</h1>
<p id="flag-summary">Checking...</p>
```

### JavaScript panel
```javascript
// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let customers = [
  { name: "Aisha Rahman", flagged: true },
  { name: "Daniel Hughes", flagged: false },
  { name: "Meera Shah", flagged: true }
];

let nameList = "";

for (let i = 0; i < customers.length; i++) {
  if (customers[i].flagged === true) {
    nameList = nameList + customers[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
