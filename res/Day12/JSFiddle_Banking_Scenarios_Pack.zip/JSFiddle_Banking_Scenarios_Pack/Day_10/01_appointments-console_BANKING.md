# JSFiddle Activity — Day 10: Payments Console

## Day 10 — Payments Console — Banking Scenario

**Source JavaScript:** `payments-console.js`  
**Corresponding HTML:** `payments.html`  
**Type:** Provided activity script

### Banking practice scenario — Online Banking Dashboard

Use DOM manipulation to update account, payment and customer information in a browser. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Customer Account Dashboard</h1>
<p id="payment-summary">Checking...</p>
```

### JavaScript panel
```javascript
let payments = [
  { customer: "Aisha Rahman", urgent: true },
  { customer: "Daniel Hughes", urgent: false },
  { customer: "Meera Shah", urgent: true },
  { customer: "Oliver Grant", urgent: false },
  { customer: "Elena Costa", urgent: true }
];

let urgentCount = 0;

for (let i = 0; i < payments.length; i++) {
  if (payments[i].urgent === true) {
    urgentCount = urgentCount + 1;
  }
}

console.log("Urgent payments: " + urgentCount);

// Your task: move this report from the console onto the page.
// First: select #payment-summary and store it in a variable called summary.
// Second: replace the console.log line above with a textContent assignment.
// Third: refresh the browser and confirm the count appears where "Checking..." used to be.
// Each update should display a clear, helpful message on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
