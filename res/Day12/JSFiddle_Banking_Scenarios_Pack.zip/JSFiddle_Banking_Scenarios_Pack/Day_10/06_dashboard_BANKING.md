# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard — Banking Scenario

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### Banking practice scenario — Online Banking Dashboard

Use DOM manipulation to update account, payment and customer information in a browser. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Payments Operations Dashboard</h1>
<p id="pending review-count">Checking...</p>
<p id="pending review-list">Checking...</p>
```

### JavaScript panel
```javascript
let payments = [
  { id: "TX1001", status: "pending review" },
  { id: "TX1002", status: "processed" },
  { id: "TX1014", status: "pending review" },
  { id: "TX1025", status: "processed" },
  { id: "TX1030", status: "pending review" }
];

// Your task: build a dashboard that reports pending review payment counts and ids.
// First: loop through payments and count how many have status "pending review".
// Second: loop through payments and build a comma-separated list of pending review ids.
// Third: select #pending review-count and update its text with the count.
// Fourth: select #pending review-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
