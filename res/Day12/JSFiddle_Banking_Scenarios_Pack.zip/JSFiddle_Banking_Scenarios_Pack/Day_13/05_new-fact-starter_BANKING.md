# JSFiddle Activity — Day 13: New Fact Starter

## Day 13 — New Fact Starter — Banking Scenario

**Source JavaScript:** `new-fact-starter.js`  
**Corresponding HTML:** `new-fact.html`  
**Type:** Debug/starter activity

### Banking practice scenario — Banking API Widgets

Use fetch() for small widgets that could sit inside an internal banking portal. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Fact Refresh Widget</h1>
  <button id="new-fact-button">New Fact</button>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
