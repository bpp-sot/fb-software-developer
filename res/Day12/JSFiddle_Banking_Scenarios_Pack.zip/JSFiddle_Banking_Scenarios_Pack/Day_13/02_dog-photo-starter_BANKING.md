# JSFiddle Activity — Day 13: Dog Photo Starter

## Day 13 — Dog Photo Starter — Banking Scenario

**Source JavaScript:** `dog-photo-starter.js`  
**Corresponding HTML:** `dog-photo.html`  
**Type:** Debug/starter activity

### Banking practice scenario — Banking API Widgets

Use fetch() for small widgets that could sit inside an internal banking portal. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Document Image Widget</h1>
  <button id="new-dog-button">New Dog Photo</button>
  <img id="dog-photo" src="" alt="A random dog">
```

### JavaScript panel
```javascript
const dogButton = document.querySelector("#new-dog-button");
const dogImage = document.querySelector("#dog-photo");

dogButton.addEventListener("click", function() {
  // Your task: fetch a new random dog photo every time the button is clicked and show it.
  // First: call fetch with the web address "https://dog.ceo/api/breeds/image/random"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.message and set it as the dogImage src
  // Each click should replace the current photo with a new random dog picture

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
