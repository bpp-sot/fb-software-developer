# JSFiddle Activity — Day 13: Customer Tip Widget Starter

## Day 13 — Customer Tip Widget Starter — Banking Scenario

**Source JavaScript:** `advice-generator-starter.js`  
**Corresponding HTML:** `advice-generator.html`  
**Type:** Debug/starter activity

### Banking practice scenario — Banking API Widgets

Use fetch() for small widgets that could sit inside an internal banking portal. The **JavaScript technique remains the same** as the original exercise, but the context has been rewritten for banking and financial-services delegates.

**Delegate challenge:** get the exercise working, then change at least **two banking values, customer details or messages** and predict the result before clicking **Run**.

### HTML panel
```html
<h1>Customer Tip Widget</h1>
  <button id="new-advice-button">New Advice</button>
  <p id="advice-display">Loading advice...</p>
```

### JavaScript panel
```javascript
const newAdviceButton = document.querySelector("#new-advice-button");
const adviceBox = document.querySelector("#advice-display");

newAdviceButton.addEventListener("click", function() {
  // Your task: build a working advice generator that shows new advice on every click.
  // First: call fetch with the web address "https://api.adviceslip.com/advice"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.slip.advice and set it as the adviceBox textContent
  // Each click should display a new piece of advice on the page

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
