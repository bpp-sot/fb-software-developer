# Day 3 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 3. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 8

## Day 3 — Access Check

**Source JavaScript:** `access-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this access check two ways, once for a developer and once for a non-technical manager.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one was clearer.
// Each explanation should give a clear, accurate sentence for its intended audience.

let accessLevel = 2;
let requiredLevel = 3;

if (accessLevel >= requiredLevel) {
  console.log("Access granted.");
} else {
  console.log("Access not granted.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Clarity Build Starter

**Source JavaScript:** `clarity-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite this file so it reads clearly to a new teammate, using everything you practised today.
// First: rename x, y and z to descriptive names and fix or remove the misleading comment.
// Second: rewrite "yes" and "no" into clear, full sentences.
// Third: run the file and confirm the logic still works for both outcomes.
// Each part of the file should read clearly on its own, with no explanation needed.

// set x to 5
let x = 5;
let y = 3;
let z = false;

if (x > y) {
  z = true;
}

if (z === true) {
  console.log("yes");
} else {
  console.log("no");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Fix Comments

**Source JavaScript:** `fix-comments.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix every comment in this fraud check so each one earns its place.
// First: delete the comment that only restates the code.
// Second: replace the vague "check" comment with a comment saying what the check actually decides.
// Third: add one comment explaining why riskLimit might be set to 70.
// Each remaining comment should add real meaning that the code on its own cannot give.

// set score to 80
let fraudScore = 80;
let riskLimit = 70;

// check
if (fraudScore > riskLimit) {
  console.log("review needed");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Loyalty Check

**Source JavaScript:** `loyalty-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this loyalty check two ways, once for a developer and once for a non-technical colleague.
// First: write one technical sentence as a comment, using the variable names.
// Second: write one plain sentence as a comment, with no code words at all.
// Third: read both explanations aloud to your partner and ask which one they understood faster.
// Each explanation should give a clear, accurate sentence for its intended audience.

let pointsBalance = 420;
let rewardThreshold = 400;

if (pointsBalance >= rewardThreshold) {
  console.log("Reward unlocked.");
} else {
  console.log("Keep collecting points.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Messages Starter

**Source JavaScript:** `messages-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite the console messages so a non-technical reader understands them.
// First: replace "temp high" with a clear, full-sentence warning.
// Second: replace "ok" with a clear, reassuring message.
// Third: run the file with temperature set to 39, then set it to 36, and check both messages.
// Each message should print a clear, helpful sentence for someone with no technical background.

let temperature = 39;
let safeLimit = 38;

if (temperature > safeLimit) {
  console.log("temp high");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Refund Check

**Source JavaScript:** `refund-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: explain this refund check to a customer service colleague using no technical words at all.
// First: write what the code decides in one plain sentence as a comment.
// Second: remove any word from that sentence a non-developer would not know.
// Third: read it to a partner playing the customer service role and ask them to flag any word they did not understand.
// Each explanation should be fully understandable to someone with no coding background.

let orderAge = 45;
let refundWindow = 30;

if (orderAge > refundWindow) {
  console.log("Outside the refund window.");
} else {
  console.log("Refund can be processed.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Rename Me

**Source JavaScript:** `rename-me.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rename every variable in this stock check so the file explains itself.
// First: read the comparison below and work out what a, b and c represent.
// Second: replace a, b and c with descriptive names everywhere they appear.
// Third: run the file and confirm the output logic is unchanged.
// Each variable name should make the comparison and result clear on first read.

let a = 250;
let b = 300;
let c = false;

if (a < b) {
  c = true;
}

console.log(c);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 3 — Shipment Check

**Source JavaScript:** `shipment-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite both messages so a customer checking their order understands them.
// First: replace "late" with a message the customer could act on.
// Second: replace "ok" with a message that reassures without sounding robotic.
// Third: run the file with daysInTransit at 9, then set it to 3, and check both messages.
// Each message should print a clear, helpful sentence for the customer reading it.

let daysInTransit = 9;
let maxTransitDays = 5;

if (daysInTransit > maxTransitDays) {
  console.log("late");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

