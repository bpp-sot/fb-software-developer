# JSFiddle Activity — Day 3: Messages Starter

## Day 3 — Messages Starter

**Source JavaScript:** `messages-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite the console messages so a non-technical reader understands them.
// First: replace "temp high" with a clear, full-sentence warning.
// Second: replace "ok" with a clear, reassuring message.
// Third: run the file with temperature set to 39, then set it to 36, and check both messages.
// Each message should print a clear, helpful sentence for someone with no technical background.

let temperature = 39;
let safeLimit = 38;

if (temperature > safeLimit) {
  console.log("temp high");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
