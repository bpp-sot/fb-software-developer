# JSFiddle Activity — Day 3: Shipment Check

## Day 3 — Shipment Check

**Source JavaScript:** `shipment-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: rewrite both messages so a customer checking their order understands them.
// First: replace "late" with a message the customer could act on.
// Second: replace "ok" with a message that reassures without sounding robotic.
// Third: run the file with daysInTransit at 9, then set it to 3, and check both messages.
// Each message should print a clear, helpful sentence for the customer reading it.

let daysInTransit = 9;
let maxTransitDays = 5;

if (daysInTransit > maxTransitDays) {
  console.log("late");
} else {
  console.log("ok");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
