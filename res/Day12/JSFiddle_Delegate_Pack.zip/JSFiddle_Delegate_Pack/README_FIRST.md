# Software Dev Accelerator — Complete JSFiddle Delegate Pack

This pack converts the supplied Skillable starter files into a consistent JSFiddle copy/paste format.

For every activity:

1. Copy the **HTML panel** block into JSFiddle's HTML panel.
2. Copy the **JavaScript panel** block into the JavaScript panel.
3. Copy the **CSS panel** block into CSS where content is provided; otherwise leave CSS empty.
4. Click **Run** and use the Console when the exercise uses `console.log()`.

The original JavaScript has been preserved. Starter, broken, prediction and debugging activities have **not** been silently corrected. HTML has only been adapted to remove full-document boilerplate and external script linking that JSFiddle does not require.

## Pack contents

| Day | JavaScript activities | Supplied HTML files |
|---:|---:|---:|
| 1 | 3 | 0 |
| 2 | 5 | 0 |
| 3 | 8 | 0 |
| 4 | 2 | 0 |
| 5 | 5 | 0 |
| 6 | 11 | 0 |
| 7 | 4 | 0 |
| 8 | 10 | 0 |
| 9 | 5 | 0 |
| 10 | 13 | 12 |
| 11 | 14 | 13 |
| 12 | 1 | 0 |
| 13 | 5 | 5 |
| 14 | 3 | 0 |

**Total JavaScript activities: 89**

## Folder structure

Each `Day_XX` folder contains:

- one `Day_XX_ALL_Activities.md` file containing the whole day; and
- one small `.md` file per JavaScript activity, useful when you want to give delegates only a single exercise.

