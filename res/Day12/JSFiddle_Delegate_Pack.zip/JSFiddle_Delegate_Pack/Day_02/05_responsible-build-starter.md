# JSFiddle Activity — Day 2: Responsible Build Starter

## Day 2 — Responsible Build Starter

**Source JavaScript:** `responsible-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let applicantAge = 17;
let applicationScore = 110;
let passMark = 75;

// Your task: build a responsible checker that validates the score and age before deciding pass or fail.
// First: check if applicationScore is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationScore meets or exceeds passMark and print a pass message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
