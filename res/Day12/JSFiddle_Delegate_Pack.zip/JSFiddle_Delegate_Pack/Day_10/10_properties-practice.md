# JSFiddle Activity — Day 10: Properties Practice

## Day 10 — Properties Practice

**Source JavaScript:** `properties-practice.js`  
**Corresponding HTML:** `properties-practice.html`  
**Type:** Provided activity script

### HTML panel
```html
<h1>Status Display</h1>
<p id="status-a">Pending</p>
<p id="status-b">Pending</p>
```

### JavaScript panel
```javascript
// Your task: update two elements with the same string, one using textContent and one using innerHTML.
// First: select #status-a and assign it the string "<i>Confirmed</i>" using textContent.
// Second: select #status-b and assign it the same string using innerHTML.
// Third: refresh the browser and compare how each element displays the string.
// Each element should show a clear, different result so the distinction is obvious.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
