# JSFiddle Activity — Day 10: Find Message

## Day 10 — Find Message

**Source JavaScript:** `find-message.js`  
**Corresponding HTML:** `welcome.html`  
**Type:** Provided activity script

### HTML panel
```html
<h1 id="page-title">Welcome</h1>
<p id="page-message">Loading...</p>
```

### JavaScript panel
```javascript
// Your task: select the paragraph on the page and log it, then read its plain text.
// First: use querySelector to select #page-message and store it in a variable called message.
// Second: log message to the console and check what it shows.
// Third: read message.textContent into a variable called messageText and log that too.
// Each console.log should print a clear, helpful result you can check against the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
