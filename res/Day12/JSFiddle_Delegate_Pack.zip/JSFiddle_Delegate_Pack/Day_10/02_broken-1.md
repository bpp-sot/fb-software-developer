# JSFiddle Activity — Day 10: Broken 1

## Day 10 — Broken 1

**Source JavaScript:** `broken-1.js`  
**Corresponding HTML:** `broken-1.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1 id="page-title">Welcome</h1>
```

### JavaScript panel
```javascript
let title = document.querySelector("page-title");

title.textContent = "Updated";

// Your task: find and fix the one bug in this script.
// First: compare the selector string against the matching HTML file.
// Second: fix the bug using the patterns practised today.
// Third: write a one-line comment explaining what the bug was.
// Each fix should make the page update with a clear, correct result.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
