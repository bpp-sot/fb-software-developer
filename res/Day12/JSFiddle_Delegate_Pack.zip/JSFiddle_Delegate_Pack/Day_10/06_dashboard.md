# JSFiddle Activity — Day 10: Dashboard

## Day 10 — Dashboard

**Source JavaScript:** `dashboard.js`  
**Corresponding HTML:** `dashboard.html`  
**Type:** Provided activity script

### HTML panel
```html
<h1>Delivery Dashboard</h1>
<p id="delayed-count">Loading...</p>
<p id="delayed-list">Loading...</p>
```

### JavaScript panel
```javascript
let deliveries = [
  { id: "D1021", status: "delayed" },
  { id: "D1022", status: "on time" },
  { id: "D1034", status: "delayed" },
  { id: "D1045", status: "on time" },
  { id: "D1050", status: "delayed" }
];

// Your task: build a dashboard that reports delayed delivery counts and ids.
// First: loop through deliveries and count how many have status "delayed".
// Second: loop through deliveries and build a comma-separated list of delayed ids.
// Third: select #delayed-count and update its text with the count.
// Fourth: select #delayed-list and update its text with the id list.
// Each update should display a clear, helpful summary on the page.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
