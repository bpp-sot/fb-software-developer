# JSFiddle Activity — Day 10: Flagged Patients

## Day 10 — Flagged Patients

**Source JavaScript:** `flagged-patients.js`  
**Corresponding HTML:** `flagged-patients.html`  
**Type:** Provided activity script

### HTML panel
```html
<h1>Patient Dashboard</h1>
<p id="flag-summary">Loading...</p>
```

### JavaScript panel
```javascript
// Reference example: this file is already complete and working.
// It shows the finished shape of the nameList concatenation pattern
// covered on the slides, so you can compare it line by line against
// your own file in the next activity.

let patients = [
  { name: "Amara Okafor", flagged: true },
  { name: "Liam Doyle", flagged: false },
  { name: "Priya Shah", flagged: true }
];

let nameList = "";

for (let i = 0; i < patients.length; i++) {
  if (patients[i].flagged === true) {
    nameList = nameList + patients[i].name + ", ";
  }
}

let summary = document.querySelector("#flag-summary");
summary.textContent = "Flagged: " + nameList;
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
