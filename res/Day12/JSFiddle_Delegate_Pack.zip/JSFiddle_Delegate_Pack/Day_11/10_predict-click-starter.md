# JSFiddle Activity — Day 11: Predict Click Starter

## Day 11 — Predict Click Starter

**Source JavaScript:** `predict-click-starter.js`  
**Corresponding HTML:** `predict-click-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<button id="checkButton">Check</button>
```

### JavaScript panel
```javascript
// Your task: predict what prints to the console and in what order, before running this file
// First: read every line below without running it
// Second: write down what you think will print, and in what order
// Third: run the file and click the button to check your prediction
// Each prediction should be written down clearly before you run any code

const button = document.querySelector("#checkButton");

button.addEventListener("click", function () {
  console.log("Checking now");
});

console.log("Script finished loading");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
