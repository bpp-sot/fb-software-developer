# JSFiddle Activity — Day 11: Delivery Flag Starter

## Day 11 — Delivery Flag Starter

**Source JavaScript:** `delivery-flag-starter.js`  
**Corresponding HTML:** `delivery-flag-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="trackingInput" type="text" />
  <button id="checkDeliveryButton">Check delivery</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a delivery tracking checker that validates a typed tracking number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty tracking number
// Third: add a check using trackingInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const trackingInput = document.querySelector("#trackingInput");
const button = document.querySelector("#checkDeliveryButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
