# JSFiddle Activity — Day 11: Pass Checker Event

## Day 11 — Pass Checker Event

**Source JavaScript:** `pass-checker-event.js`  
**Corresponding HTML:** `pass-checker-event.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this event-driven pass checker against your Day 2 pass-checker.js
// First: read through this file line by line
// Second: list which lines are genuinely new compared to the Day 2 version
// Third: list which lines are unchanged in logic from the Day 2 version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
