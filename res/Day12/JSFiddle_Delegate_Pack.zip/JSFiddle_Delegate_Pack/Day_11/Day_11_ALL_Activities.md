# Day 11 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 11. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 14

## Day 11 — Afternoon Build Starter

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `afternoon-build-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a validated, event-driven access request checker
// First: add an addEventListener for a click on the button
// Second: read clearanceInput.value inside the click handler and store it in a variable
// Third: add a guard for a blank submission
// Fourth: add branches for standard, elevated, restricted and unrecognised values
// Fifth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid and valid clearance levels

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Broken Click

**Source JavaScript:** `broken-click.js`  
**Corresponding HTML:** `broken-click.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: find and fix the bug that stops the button from working
// First: run this file and click the button, notice that nothing happens
// Second: check the browser console for an error message
// Third: read the error carefully and compare it against a working example from earlier today
// Fourth: fix the bug and confirm the button now updates the result text
// Each fix should make the result text update with a clear, helpful message when clicked

const input = document.querySelector("#scoreInput")
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListner("click", function () {
  result.textContent = "Score received: " + input.value;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Delivery Flag Starter

**Source JavaScript:** `delivery-flag-starter.js`  
**Corresponding HTML:** `delivery-flag-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="trackingInput" type="text" />
  <button id="checkDeliveryButton">Check delivery</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: build a delivery tracking checker that validates a typed tracking number
// First: add an addEventListener for a click on the button
// Second: add a guard for an empty tracking number
// Third: add a check using trackingInput.value.length for a length that is not exactly 6
// Fourth: write each result to the page using result.textContent
// Each result should show a clear, helpful message for blank, invalid-length and valid submissions

const trackingInput = document.querySelector("#trackingInput");
const button = document.querySelector("#checkDeliveryButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Extend Validation Starter

**Source JavaScript:** `extend-validation-starter.js`  
**Corresponding HTML:** `extend-validation-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: extend a single-guard checker into a full four-branch validated version
// First: read the existing empty-input guard already written below
// Second: add a range check using else if and logical OR, catching scores below 0 or above 100
// Third: add the final pass or fail branches for valid scores
// Fourth: test with an empty box, an out-of-range number, and a valid number
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  }

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Greet Input Starter

**Source JavaScript:** `greet-input-starter.js`  
**Corresponding HTML:** `greet-input-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="learnerName" type="text" />
  <button id="greetButton">Greet</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire up a button that reads a typed name and prints a greeting to the console
// First: select the input, the button and store them in variables
// Second: add an addEventListener for a click on the button
// Third: inside the click handler, read the input's value and store it in a variable
// Fourth: build a greeting message using that variable and print it
// Each greeting should print a clear, helpful message that includes the typed name

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Guarded Greet

**Source JavaScript:** `guarded-greet.js`  
**Corresponding HTML:** `guarded-greet.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="learnerName" type="text" />
  <button id="greetButton">Greet</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this worked example showing a guard against an empty typed name
// First: notice the empty string check written before the greeting is built
// Second: notice the else branch only runs once the guard passes
// Third: compare this shape against your own stock lookup guard
// Each result should show a clear, helpful message whether the box is empty or filled in

const nameInput = document.querySelector("#learnerName");
const button = document.querySelector("#greetButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const typedName = nameInput.value;

  if (typedName === "") {
    result.textContent = "Please type your name first";
  } else {
    result.textContent = "Hello, " + typedName;
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Morning Build Starter

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `morning-build-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="ageInput" type="text" />
  <button id="checkButton">Check eligibility</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: wire the Day 4 eligibility logic up to a real button and input
// First: add an addEventListener for a click on the button
// Second: read ageInput.value inside the click handler and store it in a variable
// Third: reuse the Day 4 if/else logic, an applicant qualifies if age is 18 or over
// Fourth: write the result to the page using result.textContent
// Each result should show a clear, helpful message of Eligible or Not eligible

const ageInput = document.querySelector("#ageInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Pass Checker Event

**Source JavaScript:** `pass-checker-event.js`  
**Corresponding HTML:** `pass-checker-event.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this event-driven pass checker against your Day 2 pass-checker.js
// First: read through this file line by line
// Second: list which lines are genuinely new compared to the Day 2 version
// Third: list which lines are unchanged in logic from the Day 2 version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Pass Checker

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this Day 2 pass checker against the event-driven version
// First: read through this file line by line
// Second: note that this version runs immediately, using a fixed score variable
// Third: identify the if/else block that is identical in shape to the newer version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const score = 72;

if (score >= 50) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Predict Click Starter

**Source JavaScript:** `predict-click-starter.js`  
**Corresponding HTML:** `predict-click-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<button id="checkButton">Check</button>
```

### JavaScript panel
```javascript
// Your task: predict what prints to the console and in what order, before running this file
// First: read every line below without running it
// Second: write down what you think will print, and in what order
// Third: run the file and click the button to check your prediction
// Each prediction should be written down clearly before you run any code

const button = document.querySelector("#checkButton");

button.addEventListener("click", function () {
  console.log("Checking now");
});

console.log("Script finished loading");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Stock Lookup Starter

**Source JavaScript:** `stock-lookup-starter.js`  
**Corresponding HTML:** `stock-lookup-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<input id="stockInput" type="text" />
  <button id="lookupButton">Look up</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: add a guard so an empty stock code shows a helpful message instead of a blank result
// First: read the existing addEventListener block below
// Second: add an if check for an empty string before the lookup message
// Third: test with an empty box and then with real text typed in
// Each result should show a clear, helpful message whether the box is empty or filled in

const stockInput = document.querySelector("#stockInput");
const button = document.querySelector("#lookupButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const stockCode = stockInput.value;
  result.textContent = "Looking up stock code: " + stockCode;
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Validated Score Check

**Source JavaScript:** `validated-score-check.js`  
**Corresponding HTML:** `validated-score-check.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="scoreInput" type="text" />
  <button id="checkButton">Check</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: read this fully validated score checker as a reference example
// First: notice the empty guard runs before anything else
// Second: notice the range guard runs before the pass or fail decision
// Third: trace through a few sample scores by hand: "", "150", "42", "75"
// Each result should show a clear, helpful message matching the correct branch

const scoreInput = document.querySelector("#scoreInput");
const button = document.querySelector("#checkButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const score = scoreInput.value;

  if (score === "") {
    result.textContent = "Please enter a score";
  } else if (score < 0 || score > 100) {
    result.textContent = "Score must be between 0 and 100";
  } else if (score >= 50) {
    result.textContent = "Pass";
  } else {
    result.textContent = "Fail";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Version A

**Source JavaScript:** `version-a.js`  
**Corresponding HTML:** `version-a.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the separate else if branches used here
// Second: notice each valid clearance level has its own distinct message written out in full
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard") {
    result.textContent = "Standard access granted";
  } else if (clearance === "elevated") {
    result.textContent = "Elevated access granted";
  } else if (clearance === "restricted") {
    result.textContent = "Restricted access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 11 — Version B

**Source JavaScript:** `version-b.js`  
**Corresponding HTML:** `version-b.html`  
**Type:** Provided activity script

### HTML panel
```html
<input id="clearanceInput" type="text" />
  <button id="checkAccessButton">Check access</button>
  <p id="result"></p>
```

### JavaScript panel
```javascript
// Your task: compare this version of the access checker against your own build
// First: read through the single combined condition using logical OR
// Second: notice the message is built dynamically using the clearance variable itself
// Third: decide which version your own build is closer to
// Each comparison should produce a clear, helpful note on the difference you found

const clearanceInput = document.querySelector("#clearanceInput");
const button = document.querySelector("#checkAccessButton");
const result = document.querySelector("#result");

button.addEventListener("click", function () {
  const clearance = clearanceInput.value;

  if (clearance === "") {
    result.textContent = "Please enter a clearance level";
  } else if (clearance === "standard" || clearance === "elevated" || clearance === "restricted") {
    result.textContent = clearance + " access granted";
  } else {
    result.textContent = "Unrecognised clearance level";
  }
});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

