# JSFiddle Activity — Day 11: Pass Checker

## Day 11 — Pass Checker

**Source JavaScript:** `pass-checker.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: compare this Day 2 pass checker against the event-driven version
// First: read through this file line by line
// Second: note that this version runs immediately, using a fixed score variable
// Third: identify the if/else block that is identical in shape to the newer version
// Each comparison should produce a clear, helpful list of new versus unchanged lines

const score = 72;

if (score >= 50) {
  console.log("Pass");
} else {
  console.log("Fail");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
