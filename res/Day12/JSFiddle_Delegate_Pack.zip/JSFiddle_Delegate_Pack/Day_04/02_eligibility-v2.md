# JSFiddle Activity — Day 4: Eligibility V2

## Day 4 — Eligibility V2

**Source JavaScript:** `eligibility-v2.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: run this improved draft with age 16 and compare its output to eligibility-v1.js.
// First: run this file with age 16 and note the output.
// Second: compare the message here to the message you got from eligibility-v1.js with age 16.
// Third: write one sentence on what changed between the two files and what stayed the same.
// Each note should describe the output clearly enough for a neighbour to follow.

let age = 20;
let identityVerified = true;

if (age >= 18 && identityVerified === true) {
  console.log("Eligible to open a savings account.");
} else {
  console.log("Not eligible to open a savings account yet.");
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
