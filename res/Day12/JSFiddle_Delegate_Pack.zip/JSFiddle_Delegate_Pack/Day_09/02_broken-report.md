# JSFiddle Activity — Day 9: Broken Report

## Day 9 — Broken Report

**Source JavaScript:** `broken-report.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 }
];

let passCount = 0;

for (let i = 0; i <= learners.length; i++) {
  if (learners[i].score >= 50) {
    passCount = passCount + 1;
  }
}

console.log(passCount);

// Your task: find and explain the bug that breaks this loop.
// First: read the loop condition carefully before running anything.
// Second: predict what learners.length equals and what the loop will do.
// Third: run the file and compare the actual error to your prediction.
// Each answer should be a clear, written sentence identifying the bug and why it happens.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
