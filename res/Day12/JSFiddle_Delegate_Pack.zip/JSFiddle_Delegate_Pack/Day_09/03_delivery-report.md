# JSFiddle Activity — Day 9: Delivery Report

## Day 9 — Delivery Report

**Source JavaScript:** `delivery-report.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
let deliveries = [
  { driver: "Jodie Marsh", parcels: 42, onTimeRate: 96 },
  { driver: "Tomasz Nowak", parcels: 18, onTimeRate: 71 },
  { driver: "Aisha Bello", parcels: 35, onTimeRate: 88 }
];

let totalParcels = 0;
let lowPerformers = [];

// Your task: apply the same report pattern to this delivery dataset.
// First: write a for loop adding each driver's parcels to totalParcels.
// Second: inside the loop, push drivers with onTimeRate below 80 to lowPerformers.
// Third: print both totalParcels and lowPerformers after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
