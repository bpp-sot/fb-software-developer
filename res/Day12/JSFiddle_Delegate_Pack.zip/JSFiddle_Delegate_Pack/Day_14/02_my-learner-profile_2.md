# JSFiddle Activity — Day 14: My Learner Profile (2)

## Day 14 — My Learner Profile (2)

**Source JavaScript:** `my-learner-profile (2).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file already has one commit in its history. You will now make a second change.

let learnerName = "Sam";
let learnerCourse = "Level 4 Software Developer Apprenticeship";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: commit a second, real change to this file with its own clear message.
// First: change the learnerCourse value above to reflect a new course name.
// Second: save the file, then stage and commit the change with a new message.
// Third: run git log to confirm both commits now appear in your project's history.
// Each step should print a clear, helpful message confirming what Git has recorded.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
