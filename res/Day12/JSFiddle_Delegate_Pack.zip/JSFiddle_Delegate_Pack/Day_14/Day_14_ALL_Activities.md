# Day 14 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 14. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 3

## Day 14 — My Learner Profile (1)

**Source JavaScript:** `my-learner-profile (1).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file is already staged and ready to become your first Git commit.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: record this file as your first permanent entry in your project's history.
// First: run git add my-learner-profile.js in your git-practice folder.
// Second: run git commit -m with a short, honest message describing the file.
// Third: read the confirmation output Git gives you after the commit.
// Fourth: compare your commit message with a neighbour's message.
// Each step should print a clear, helpful message confirming what Git has done.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 14 — My Learner Profile (2)

**Source JavaScript:** `my-learner-profile (2).js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This file already has one commit in its history. You will now make a second change.

let learnerName = "Sam";
let learnerCourse = "Level 4 Software Developer Apprenticeship";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: commit a second, real change to this file with its own clear message.
// First: change the learnerCourse value above to reflect a new course name.
// Second: save the file, then stage and commit the change with a new message.
// Third: run git log to confirm both commits now appear in your project's history.
// Each step should print a clear, helpful message confirming what Git has recorded.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 14 — My Learner Profile

**Source JavaScript:** `my-learner-profile.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Day 1 learner profile script
// This is the file you will copy into your git-practice folder for today's activity.

let learnerName = "Sam";
let learnerCourse = "Level 3 Diploma";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: turn this project folder into a Git repository ready to track changes.
// First: create a new folder called git-practice on your desktop and copy this file into it.
// Second: open a terminal in that folder and run git init.
// Third: confirm the terminal shows the "Initialized empty Git repository" message.
// Each step should print a clear, helpful confirmation in your terminal before you move on.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

