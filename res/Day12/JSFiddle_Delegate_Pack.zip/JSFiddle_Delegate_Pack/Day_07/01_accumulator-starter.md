# JSFiddle Activity — Day 7: Accumulator Starter

## Day 7 — Accumulator Starter

**Source JavaScript:** `accumulator-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete this accumulator loop so it adds up every value in the array.
// First: read the array and the total variable that starts at zero.
// Second: read the for loop header that already visits every item in the array.
// Third: add the missing line inside the loop body that updates total with the current item.
// Fourth: run the file and check the printed total is correct.
// Each pass of the loop should add the current item to the running total.

let bookings = [14, 22, 9, 31, 18, 27, 12];
let total = 0;

for (let i = 0; i < bookings.length; i++) {

}

console.log("Total: " + total);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
