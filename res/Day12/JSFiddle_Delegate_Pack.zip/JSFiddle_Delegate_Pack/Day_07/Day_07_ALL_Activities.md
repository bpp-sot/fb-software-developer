# Day 7 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 7. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 4

## Day 7 — Accumulator Starter

**Source JavaScript:** `accumulator-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete this accumulator loop so it adds up every value in the array.
// First: read the array and the total variable that starts at zero.
// Second: read the for loop header that already visits every item in the array.
// Third: add the missing line inside the loop body that updates total with the current item.
// Fourth: run the file and check the printed total is correct.
// Each pass of the loop should add the current item to the running total.

let bookings = [14, 22, 9, 31, 18, 27, 12];
let total = 0;

for (let i = 0; i < bookings.length; i++) {

}

console.log("Total: " + total);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 7 — Predict Loop

**Source JavaScript:** `predict-loop.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this loop will print before you run it.
// First: read the array and the loop carefully without running the file yet.
// Second: write down each line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your prediction to the actual output.
// Fourth: if the output surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let parcels = [154, 89, 203, 47, 176];

for (let i = 0; i < parcels.length; i++) {
  console.log(parcels[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 7 — Predict While

**Source JavaScript:** `predict-while.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what this while loop will print before you run it.
// First: read the while loop and trace it on paper, one pass at a time.
// Second: write down every line you expect to see printed, in order, as a comment below.
// Third: run the file and compare your written prediction to the actual output.
// Fourth: if anything surprised you, add one sentence explaining why.
// Each prediction should describe a clear, specific value you expect to see printed.

// Write your prediction here as comments:


let dosesRemaining = 4;

while (dosesRemaining > 0) {
  console.log("Doses remaining: " + dosesRemaining);
  dosesRemaining = dosesRem
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 7 — Print All Starter

**Source JavaScript:** `print-all-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: modify this loop so it prints a clearer, more useful message for each value.
// First: read the existing loop and the array of dispatch counts.
// Second: change the console.log message so it includes a label and a unit.
// Third: add one more item to the array and run the file to confirm it is printed too.
// Each printed line should show a clear, labelled message including the value and its unit.

let dispatches = [120, 95, 140, 88, 132, 76];

for (let i = 0; i < dispatches.length; i++) {
  console.log(dispatches[i]);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

