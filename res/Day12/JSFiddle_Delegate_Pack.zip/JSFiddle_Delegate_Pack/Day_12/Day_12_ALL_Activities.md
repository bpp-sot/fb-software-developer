# Day 12 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 12. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 1

## Day 12 — Refactor Starter

**Source JavaScript:** `refactor-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function reviewSubmission(wordCount, hasReferences, isLate) {
  let verdict = "";

  if (wordCount >= 500) {
    verdict = verdict + "Meets word count. ";
  } else {
    verdict = verdict + "Below word count. ";
  }

  if (hasReferences) {
    verdict = verdict + "References included. ";
  } else {
    verdict = verdict + "References missing. ";
  }

  if (isLate) {
    verdict = verdict + "Submitted late, one grade band lower.";
  } else {
    verdict = verdict + "Submitted on time.";
  }

  return verdict;
}

console.log(reviewSubmission(620, true, false));
console.log(reviewSubmission(410, false, true));
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Original activity briefs supplied with this day

### build-record-brief.txt

```text
Write a function called buildOrderSummary that takes itemName, price and
quantity. It should return an object with four properties: itemName,
price, quantity, and total, where total is price multiplied by quantity.
```

### complete-the-function.txt

```text
let products = [
  { name: "Notebook", price: 4 },
  { name: "Pen", price: 2 },
  { name: "Folder", price: 6 }
];

// averagePrice should take an array of product objects
// and return the average of their price values
function averagePrice(products) {

}

console.log(averagePrice(products));
```

### name-the-three-jobs.txt

```text
A single function named handleOrder takes an order's weight, a customer's
loyalty status, and an item price. It checks whether the delivery is over
20kg and needs a surcharge, works out a 10 percent discount for loyalty
members, and then builds a final message showing the total price and
delivery notes.

Decide how many separate functions this should become, and name each one.
For each one, write a single sentence describing exactly what it does.

1.


2.


3.
```

### predict-array-function.txt

```text
function countAbove(scores, threshold) {
  let count = 0;
  for (let i = 0; i < scores.length; i++) {
    if (scores[i] > threshold) {
      count = count + 1;
    }
  }
  return count;
}

console.log(countAbove([45, 82, 91, 38, 76], 50));
```

### toolkit-brief.txt

```text
Build three functions using the array of learner objects below.

filterPassed(learners) returns only the learner objects where passed is
true.

averageScore(learners) returns the average score across the array.

buildReport(learners) calls both of the above and returns a summary
object.

Write your functions into a new file called toolkit.js.

let learners = [
  { name: "Priya", score: 78, passed: true },
  { name: "Deshawn", score: 41, passed: false },
  { name: "Aoife", score: 92, passed: true },
  { name: "Marcus", score: 55, passed: true },
  { name: "Yuki", score: 38, passed: false }
];
```

### trace-the-call.txt

```text
function doubleIt(number) {
  return number * 2;
}

function describeNumber(number) {
  let doubled = doubleIt(number);
  return "Double of " + number + " is " + doubled;
}

console.log(describeNumber(6));
```
