# Day 5 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 5. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 5

## Day 5 — Access Tools

**Source JavaScript:** `access-tools.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isAdult(age) {
  if (age >= 18) {
    return true;
  } else {
    return false;
  }
}

function isVerified(status) {
  if (status === true) {
    return true;
  } else {
    return false;
  }
}

let adultCheck = isAdult(22);
let verifiedCheck = isVerified(false);

console.log(adultCheck);
console.log(verifiedCheck);

// Your task: trace both functions, then run the file and change one call to see what happens
// First: predict what isAdult(22) and isVerified(false) each return
// Second: run the file and confirm the two printed lines match your prediction
// Third: change isVerified(false) to isVerified(true) and run it again
// Each printed line should clearly show true or false for its matching function
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 5 — Eligibility Day5

**Source JavaScript:** `eligibility-day5.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let personOne = isEligible(30, true);
let personTwo = isEligible(17, true);
let personThree = isEligible(45, false);

console.log(personOne);
console.log(personTwo);
console.log(personThree);

// Your task: predict every line this file prints, then change one call and check again
// First: write down what personOne, personTwo and personThree will each print
// Second: run the file and confirm your predictions
// Third: change isEligible(17, true) to isEligible(19, true) and run it again
// Each printed line should clearly show true or false for its matching person
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 5 — Eligibility Function

**Source JavaScript:** `eligibility-function.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function checkEligibility(age, verified) {
  if (age >= 18 && verified === true) {
    console.log("Eligible");
  } else {
    console.log("Not eligible");
  }
}

checkEligibility(22, true);
checkEligibility(16, true);
checkEligibility(40, false);

// Your task: run this file and then change one value to see how reuse works
// First: run the file and read the three printed lines
// Second: change the first call from 22 to 15
// Third: run it again and compare the new output with the old output
// Each printed line should clearly show Eligible or Not eligible for its matching call
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 5 — Eligibility Return

**Source JavaScript:** `eligibility-return.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function isEligible(age, verified) {
  if (age >= 18 && verified === true) {
    return true;
  } else {
    return false;
  }
}

let result = isEligible(22, true);
console.log(result);

// Your task: trace the returned value through this file, then change one value and observe
// First: predict what isEligible(22, true) returns and what result will hold
// Second: run the file and confirm result prints true
// Third: change the call to isEligible(16, true) and run it again
// Each run should print a clear true or false value based on the returned result
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 5 — Reorder Check

**Source JavaScript:** `reorder-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsReorder(stockLevel, reorderPoint) {
  if (stockLevel < reorderPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnMilk = needsReorder(3, 10);
console.log(lowOnMilk);

// Your task: predict what this file prints before you run it
// First: work out what needsReorder(3, 10) returns
// Second: work out what lowOnMilk then holds
// Third: work out what console.log(lowOnMilk) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

