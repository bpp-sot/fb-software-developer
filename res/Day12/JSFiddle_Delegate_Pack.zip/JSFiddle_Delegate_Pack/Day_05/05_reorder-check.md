# JSFiddle Activity — Day 5: Reorder Check

## Day 5 — Reorder Check

**Source JavaScript:** `reorder-check.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
function needsReorder(stockLevel, reorderPoint) {
  if (stockLevel < reorderPoint) {
    return true;
  } else {
    return false;
  }
}

let lowOnMilk = needsReorder(3, 10);
console.log(lowOnMilk);

// Your task: predict what this file prints before you run it
// First: work out what needsReorder(3, 10) returns
// Second: work out what lowOnMilk then holds
// Third: work out what console.log(lowOnMilk) will print
// Each prediction should state a clear true or false value
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
