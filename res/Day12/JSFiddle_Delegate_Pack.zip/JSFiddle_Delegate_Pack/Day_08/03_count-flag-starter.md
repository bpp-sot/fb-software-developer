# JSFiddle Activity — Day 8: Count Flag Starter

## Day 8 — Count Flag Starter

**Source JavaScript:** `count-flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: combine a flag update with a running count in one loop
// First: read the existing array and empty loop below
// Second: declare a flaggedCount variable set to 0 before the loop
// Third: inside the loop, flag records where score is below 60 and add to the count
// Fourth: after the loop, print the total number of flagged records
// Each low-scoring record should be flagged and the final count should print clearly

let assessments = [
  { name: "Elena Cruz", score: 55, flagged: false },
  { name: "Noah Bright", score: 71, flagged: false },
  { name: "Aisha Bello", score: 48, flagged: false },
  { name: "Kofi Mensah", score: 66, flagged: false },
  { name: "Ines Duarte", score: 59, flagged: false },
  { name: "Sam Foster", score: 82, flagged: false },
  { name: "Wei Zhang", score: 37, flagged: false },
  { name: "Rosa Alvarez", score: 91, flagged: false }
];

for (let i = 0; i < assessments.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
