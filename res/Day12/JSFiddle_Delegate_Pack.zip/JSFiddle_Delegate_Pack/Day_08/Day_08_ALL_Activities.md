# Day 8 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 8. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 10

## Day 8 — Afternoon Build Starter

**Source JavaScript:** `afternoon-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a stock report that updates, counts, and collects low-stock products
// First: write a for loop that checks each product's stockLevel
// Second: inside the loop, set reorderNeeded to true if stockLevel is below 20
// Third: inside the loop, increment the counter and push the product to the reorderList
// Fourth: after the loop, print the count and each product name in the reorderList
// Each low-stock product should be flagged, counted, and listed in the final report

let products = [
  { name: "Paracetamol 500mg", category: "pharmacy",
    stockLevel: 12, reorderNeeded: false },
  { name: "Vinyl gloves M", category: "PPE",
    stockLevel: 45, reorderNeeded: false },
  { name: "Saline solution", category: "pharmacy",
    stockLevel: 8, reorderNeeded: false },
  { name: "Alcohol wipes", category: "PPE",
    stockLevel: 3, reorderNeeded: false },
  { name: "Blood pressure cuff", category: "equipment",
    stockLevel: 22, reorderNeeded: false },
  { name: "Surgical tape", category: "consumables",
    stockLevel: 17, reorderNeeded: false },
  { name: "Disposable cups", category: "consumables",
    stockLevel: 60, reorderNeeded: false },
  { name: "Pulse oximeter", category: "equipment",
    stockLevel: 5, reorderNeeded: false }
];

// 1. Declare your counter variable here
// 2. Declare your reorderList array here
// 3. Write your loop below
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Broken Objects

**Source JavaScript:** `broken-objects.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: fix the two bugs in this loop so the count and collected array are correct
// First: move the counter declaration to before the loop
// Second: move the push statement inside the if block
// Third: run the file and check the count and the collected array are now correct
// Each fix should result in an accurate count and a lowStock array with only matching products

let products = [
  { name: "Nitrile gloves S", category: "PPE", stockLevel: 14 },
  { name: "Cotton bandages", category: "consumables", stockLevel: 55 },
  { name: "Insulin vials", category: "pharmacy", stockLevel: 6 },
  { name: "Thermometer digital", category: "equipment", stockLevel: 30 },
  { name: "Face shields", category: "PPE", stockLevel: 9 },
  { name: "Gauze pads", category: "consumables", stockLevel: 18 }
];

let lowStock = [];

for (let i = 0; i < products.length; i++) {
  let count = 0;
  if (products[i].stockLevel < 20) {
    count = count + 1;
  }
  lowStock.push(products[i]);
}

console.log(count);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Count Flag Starter

**Source JavaScript:** `count-flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: combine a flag update with a running count in one loop
// First: read the existing array and empty loop below
// Second: declare a flaggedCount variable set to 0 before the loop
// Third: inside the loop, flag records where score is below 60 and add to the count
// Fourth: after the loop, print the total number of flagged records
// Each low-scoring record should be flagged and the final count should print clearly

let assessments = [
  { name: "Elena Cruz", score: 55, flagged: false },
  { name: "Noah Bright", score: 71, flagged: false },
  { name: "Aisha Bello", score: 48, flagged: false },
  { name: "Kofi Mensah", score: 66, flagged: false },
  { name: "Ines Duarte", score: 59, flagged: false },
  { name: "Sam Foster", score: 82, flagged: false },
  { name: "Wei Zhang", score: 37, flagged: false },
  { name: "Rosa Alvarez", score: 91, flagged: false }
];

for (let i = 0; i < assessments.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Flag Starter

**Source JavaScript:** `flag-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: write a loop that flags high-value transactions
// First: read the existing array below
// Second: write a for loop that reads each transaction object
// Third: inside the loop, add an if statement: if amount is above 5000, set flagged to true
// Fourth: after the loop, log the flagged value for each transaction to check your work
// Each transaction over 5000 should print true and each other transaction should print false

let transactions = [
  { reference: "TXN-101", customerName: "Freya Lindqvist", amount: 2200, flagged: false },
  { reference: "TXN-102", customerName: "Ben Okafor", amount: 6100, flagged: false },
  { reference: "TXN-103", customerName: "Anya Petrov", amount: 480, flagged: false },
  { reference: "TXN-104", customerName: "Chidi Nwosu", amount: 9800, flagged: false },
  { reference: "TXN-105", customerName: "Laura Kim", amount: 3050, flagged: false },
  { reference: "TXN-106", customerName: "Omar Farouk", amount: 15200, flagged: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Loop Read Starter

**Source JavaScript:** `loop-read-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend the loop below to print a third property from each learner
// First: read the existing loop and predict what the two console.log lines will print
// Second: add a third console.log inside the loop to also print verified
// Third: run the file and check your output matches your prediction
// Each learner should have their name, score, and verified value printed clearly

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

for (let i = 0; i < learners.length; i++) {
  console.log(learners[i].name);
  console.log(learners[i].score);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Morning Build Starter

**Source JavaScript:** `morning-build-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: build a loop that updates each learner's passed status and prints a report
// First: write a for loop that reads each learner in the array
// Second: inside the loop, set passed to true if score is 65 or above
// Third: inside the loop, print a line naming the learner and whether they passed
// Each learner should have a clear, human-readable line printed to the console

let learners = [
  { name: "Priya", score: 82, passed: false },
  { name: "Marcus", score: 58, passed: false },
  { name: "Leila", score: 74, passed: false },
  { name: "Tom", score: 63, passed: false },
  { name: "Yuki", score: 91, passed: false }
];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Predict Array

**Source JavaScript:** `predict-array.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this array of objects by hand before running the file
// First: write down what each console.log below will print
// Second: run the file and check your predictions were correct
// Third: write a sentence explaining what learners[1].score means in plain English
// Each prediction should be checked against the real output

let learners = [
  { name: "Amara", score: 84, verified: true },
  { name: "Joel", score: 61, verified: false },
  { name: "Fatima", score: 77, verified: true }
];

console.log(learners[0].name);
console.log(learners[1].score);
console.log(learners[2].verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Transactions

**Source JavaScript:** `transactions.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: trace this loop by hand, then run the file to check your work
// First: write down what the loop will print for iterations 3 and 4
// Second: run the file and compare the actual output with your trace
// Third: write one sentence explaining what transactions[i].amount means
// Each iteration should print the reference and amount for that transaction

let transactions = [
  { reference: "TXN-001", customerName: "Sofia Andersen",
    amount: 4750, status: "pending", flagged: false },
  { reference: "TXN-002", customerName: "David Osei",
    amount: 320, status: "cleared", flagged: false },
  { reference: "TXN-003", customerName: "Mei Lin",
    amount: 12800, status: "pending", flagged: false },
  { reference: "TXN-004", customerName: "Ravi Patel",
    amount: 95, status: "cleared", flagged: false }
];

for (let i = 0; i < transactions.length; i++) {
  console.log(transactions[i].reference);
  console.log(transactions[i].amount);
}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Update Loop Starter

**Source JavaScript:** `update-loop-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add a conditional update inside the loop that flags low-scoring records
// First: read the existing array and loop below
// Second: inside the loop, add an if statement checking whether score is below 65
// Third: if the condition is true, set that object's flagged property to true
// Fourth: after the loop, log the flagged value for each object to check your work
// Each flagged record should print true and each unflagged record should print false

let patients = [
  { name: "Helen Wren", score: 58, flagged: false },
  { name: "Marcus Reid", score: 72, flagged: false },
  { name: "Ola Adeyemi", score: 61, flagged: false },
  { name: "Sian Blake", score: 89, flagged: false },
  { name: "Tomasz Nowak", score: 45, flagged: false }
];

for (let i = 0; i < patients.length; i++) {

}
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 8 — Update Practice

**Source JavaScript:** `update-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: update two properties on a patient object using dot notation
// First: read the two console.log lines below and predict what they will print
// Second: change the score property to 95 using dot notation
// Third: change the verified property from false to true
// Each change should be reflected in the console output when you run the file

let patient = {
  name: "Grace Oduya",
  ward: "Cardiology",
  score: 84,
  verified: false,
  priority: "standard"
};

console.log(patient.score);
console.log(patient.verified);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

