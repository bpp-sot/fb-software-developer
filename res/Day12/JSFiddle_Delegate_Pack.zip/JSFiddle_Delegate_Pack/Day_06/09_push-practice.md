# JSFiddle Activity — Day 6: Push Practice

## Day 6 — Push Practice

**Source JavaScript:** `push-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add two more items to the basket and report the new count.
// First: use .push to add one more product name to the basket.
// Second: use .push again to add a second product name.
// Third: add a label line and print the new count with .length.
// Each addition should grow the basket, and the printed count should reflect it clearly.

let basket = ["Shampoo", "Towel"];

console.log("Items at start:");
console.log(basket.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
