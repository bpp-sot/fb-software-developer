# JSFiddle Activity — Day 6: Transactions Read

## Day 6 — Transactions Read

**Source JavaScript:** `transactions-read.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what each line below will print, then run the file to check.
// First: write down your predicted output for all four console.log lines.
// Second: run the file and compare the real output to your predictions.
// Third: note any line where your prediction was different, and why.
// Each prediction should be checked against the real, printed value.

let amounts = [40, 125, 9, 300, 15];

console.log(amounts[0]);
console.log(amounts[4]);
console.log(amounts[2]);
console.log(amounts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
