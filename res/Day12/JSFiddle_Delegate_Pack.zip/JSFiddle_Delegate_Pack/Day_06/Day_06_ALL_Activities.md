# Day 6 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 6. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 11

## Day 6 — Access Log

**Source JavaScript:** `access-log.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file with one more push and predict the results.
// First: predict the current length and last index before running the file.
// Second: add one more push of a value you choose.
// Third: predict the new length and the new last index, then run to check.
// Each prediction should be confirmed by the printed output.

let failedAttempts = [1, 1, 0];

failedAttempts.push(1);

console.log(failedAttempts.length);
console.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — First Value Starter

**Source JavaScript:** `first-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the first transaction in the list.
// First: call getFirst with the transactions array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "First transaction:".
// Each label and value should print together, clearly showing the first transaction.

function getFirst(list) {
  return list[0];
}

let transactions = [40, 125, 18, 60];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Index Practice

**Source JavaScript:** `index-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: edit the code below so it prints three different wait times from the list.
// First: change the second console.log so it prints the third wait time.
// Second: change the third console.log so it prints the last wait time.
// Third: run the file and check three different numbers appear.
// Fourth: write down which index gave you the last value, and why.
// Each console.log should print a different, correct wait time from the array.

let waitTimes = [12, 5, 30, 8, 21];

console.log(waitTimes[0]);
console.log(waitTimes[0]);
console.log(waitTimes[0]);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Last Value Starter

**Source JavaScript:** `last-value-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: use the given function to print the most recent reading in the list.
// First: call getLast with the readings array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "Most recent reading:".
// Each label and value should print together, clearly showing the last reading.

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let readings = [4, 7, 2, 9, 5];
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Length Practice

**Source JavaScript:** `length-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: extend this file so it also reports the last stock level in the list.
// First: add a variable that stores the last index using .length minus one.
// Second: add a console.log that prints the last stock level using that index.
// Third: add a clear label line before it, like "Last stock level:".
// Each console.log should print a clear, correctly labelled value.

let stockLevels = [200, 45, 130, 90, 15, 60];

console.log("Number of items:");
console.log(stockLevels.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — My First Array

**Source JavaScript:** `my-first-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: create your own array of related values from a sector you know and print it.
// First: choose a context, such as wait times, transaction amounts, or stock levels.
// Second: create an array with a clear, descriptive name and at least four values.
// Third: print the whole array with console.log so all the values show at once.
// Each array should print a clear, complete list of values.
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Order Report Starter

**Source JavaScript:** `order-report-starter.js`  
**Corresponding HTML:** `None`  
**Type:** Debug/starter activity

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: complete the weekly order report using the arrays and functions given.
// First: print how many days were recorded using .length with a clear label.
// Second: call getFirst and print the first day's total with a label.
// Third: call getLast and print the last day's total with a label.
// Each fact should print with a clear, correct label so the report reads easily.

function getFirst(list) {
  return list[0];
}

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let dailyOrders = [120, 145, 98, 160, 132];

console.log("Weekly order report");
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Push Demo

**Source JavaScript:** `push-demo.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: an empty array that grows as values are pushed onto it.

let alerts = [];

console.log(alerts.length);

alerts.push("Fridge door open");
alerts.push("Low battery");

console.log(alerts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Push Practice

**Source JavaScript:** `push-practice.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: add two more items to the basket and report the new count.
// First: use .push to add one more product name to the basket.
// Second: use .push again to add a second product name.
// Third: add a label line and print the new count with .length.
// Each addition should grow the basket, and the printed count should reflect it clearly.

let basket = ["Shampoo", "Towel"];

console.log("Items at start:");
console.log(basket.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Scores Array

**Source JavaScript:** `scores-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: a single named array holding five related score values.

let scores = [72, 65, 90, 48, 81];

console.log(scores);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 6 — Transactions Read

**Source JavaScript:** `transactions-read.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Your task: predict what each line below will print, then run the file to check.
// First: write down your predicted output for all four console.log lines.
// Second: run the file and compare the real output to your predictions.
// Third: note any line where your prediction was different, and why.
// Each prediction should be checked against the real, printed value.

let amounts = [40, 125, 9, 300, 15];

console.log(amounts[0]);
console.log(amounts[4]);
console.log(amounts[2]);
console.log(amounts.length);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

