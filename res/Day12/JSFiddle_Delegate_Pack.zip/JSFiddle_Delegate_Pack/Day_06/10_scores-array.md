# JSFiddle Activity — Day 6: Scores Array

## Day 6 — Scores Array

**Source JavaScript:** `scores-array.js`  
**Corresponding HTML:** `None`  
**Type:** Provided activity script

### HTML panel
```html
<!-- No HTML required for this activity. -->
```

### JavaScript panel
```javascript
// Example: a single named array holding five related score values.

let scores = [72, 65, 90, 48, 81];

console.log(scores);
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
