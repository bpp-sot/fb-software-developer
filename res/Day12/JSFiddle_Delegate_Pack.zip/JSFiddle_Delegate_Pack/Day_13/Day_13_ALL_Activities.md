# Day 13 — JSFiddle Copy/Paste Pack

This file contains every supplied JavaScript activity for Day 13. Where an HTML file corresponds to the script, the browser-ready body content is included in the HTML panel. External `<script src="...">` wiring has been removed because JSFiddle provides the JavaScript panel separately.

**Activities:** 5

## Day 13 — Advice Generator Starter

**Source JavaScript:** `advice-generator-starter.js`  
**Corresponding HTML:** `advice-generator.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>Advice Generator</h1>
  <button id="new-advice-button">New Advice</button>
  <p id="advice-display">Loading advice...</p>
```

### JavaScript panel
```javascript
const newAdviceButton = document.querySelector("#new-advice-button");
const adviceBox = document.querySelector("#advice-display");

newAdviceButton.addEventListener("click", function() {
  // Your task: build a working advice generator that shows new advice on every click.
  // First: call fetch with the web address "https://api.adviceslip.com/advice"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.slip.advice and set it as the adviceBox textContent
  // Each click should display a new piece of advice on the page

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 13 — Dog Photo Starter

**Source JavaScript:** `dog-photo-starter.js`  
**Corresponding HTML:** `dog-photo.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>Dog Photo Generator</h1>
  <button id="new-dog-button">New Dog Photo</button>
  <img id="dog-photo" src="" alt="A random dog">
```

### JavaScript panel
```javascript
const dogButton = document.querySelector("#new-dog-button");
const dogImage = document.querySelector("#dog-photo");

dogButton.addEventListener("click", function() {
  // Your task: fetch a new random dog photo every time the button is clicked and show it.
  // First: call fetch with the web address "https://dog.ceo/api/breeds/image/random"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.message and set it as the dogImage src
  // Each click should replace the current photo with a new random dog picture

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 13 — Fact Display Starter

**Source JavaScript:** `fact-display-starter.js`  
**Corresponding HTML:** `fact-display.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>Random Cat Fact</h1>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const factBox = document.querySelector("#fact-display");

// Your task: fetch a random cat fact and display just the fact text on the page.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to read data.fact and set it as the factBox textContent
// Each step should leave the page showing a real fact instead of the placeholder text
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 13 — First Fetch Starter

**Source JavaScript:** `first-fetch-starter.js`  
**Corresponding HTML:** `first-fetch-starter.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>First Fetch</h1>
  <p>Open the browser console to see the result.</p>
```

### JavaScript panel
```javascript
// Your task: run a fetch request to a public API and see live data arrive in the console.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to print the data to the console
// Each step should print a clear, helpful result so you can confirm the request worked
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.


## Day 13 — New Fact Starter

**Source JavaScript:** `new-fact-starter.js`  
**Corresponding HTML:** `new-fact.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>Cat Fact Generator</h1>
  <button id="new-fact-button">New Fact</button>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const newFactButton = document.querySelector("#new-fact-button");
const factBox = document.querySelector("#fact-display");

newFactButton.addEventListener("click", function() {
  // Your task: fetch a new cat fact every time the button is clicked and display it.
  // First: call fetch with the web address "https://catfact.ninja/fact"
  // Second: use .then to convert the response into usable JSON data
  // Third: use a second .then to read data.fact and set it as the factBox textContent
  // Each click should replace the current fact with a new one from the API

});
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.

