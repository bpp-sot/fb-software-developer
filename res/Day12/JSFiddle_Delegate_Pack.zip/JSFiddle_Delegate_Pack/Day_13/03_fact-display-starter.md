# JSFiddle Activity — Day 13: Fact Display Starter

## Day 13 — Fact Display Starter

**Source JavaScript:** `fact-display-starter.js`  
**Corresponding HTML:** `fact-display.html`  
**Type:** Debug/starter activity

### HTML panel
```html
<h1>Random Cat Fact</h1>
  <p id="fact-display">Loading a fact...</p>
```

### JavaScript panel
```javascript
const factBox = document.querySelector("#fact-display");

// Your task: fetch a random cat fact and display just the fact text on the page.
// First: call fetch with the web address "https://catfact.ninja/fact"
// Second: use .then to convert the response into usable JSON data
// Third: use a second .then to read data.fact and set it as the factBox textContent
// Each step should leave the page showing a real fact instead of the placeholder text
```

### CSS panel
```css
/* No CSS required for this activity. */
```

### JSFiddle use
Paste each block into the panel with the same name, then click **Run**. For activities containing starter/broken/predict instructions, follow the comments in the supplied JavaScript rather than treating the code as a completed answer.
