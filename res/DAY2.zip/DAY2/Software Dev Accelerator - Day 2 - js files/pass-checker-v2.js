// Your task: predict what this code will print, then run it and check your prediction.
// First: read the value of candidateScore and the value of passMark.
// Second: decide whether the condition on the if line is true or false.
// Third: write down your prediction before running the file.
// Fourth: run the file and write down the actual output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}