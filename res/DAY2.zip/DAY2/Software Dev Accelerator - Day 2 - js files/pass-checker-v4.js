// Your task: compare this file with pass-checker.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 60;
let passMark = 60;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}