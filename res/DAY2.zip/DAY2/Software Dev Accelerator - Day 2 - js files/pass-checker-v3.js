// Your task: run this validated pass checker with three different scores and record what happens.
// First: run the file with candidateScore set to 105 and write down the output.
// Second: change candidateScore to 72, run it again, and write down the output.
// Third: change candidateScore to 30, run it again, and write down the output.
// Each observation should record the exact text printed by console.log.

let candidateScore = 105;
let passMark = 50;

if (candidateScore < 0 || candidateScore > 100) {
  console.log("Invalid score. Please enter a number between 0 and 100.");
} else if (candidateScore >= passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}