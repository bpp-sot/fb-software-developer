let applicantAge = 17;
let applicationScore = 110;
let passMark = 75;

// Your task: build a responsible checker that validates the score and age before deciding pass or fail.
// First: check if applicationScore is outside the range 0 to 100 and print a clear, helpful message.
// Second: check if applicantAge is below 18 and print a message explaining the minimum age requirement.
// Third: check if applicationScore meets or exceeds passMark and print a pass message.
// Fourth: if none of the above conditions are true, print a fail message.
// Each condition should print a clear, helpful message.