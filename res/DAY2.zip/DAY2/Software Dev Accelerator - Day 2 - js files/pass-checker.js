// Your task: compare this morning's pass checker with pass-checker-v4.js and find every difference.
// First: open both files side by side in your editor.
// Second: write down every difference you can find between the two files.
// Third: for each difference, write one sentence explaining why the change was made.
// Each explanation should give a clear, helpful reason for the change.

let candidateScore = 72;
let passMark = 50;

if (candidateScore > passMark) {
  console.log("Pass");
} else {
  console.log("Fail");
}