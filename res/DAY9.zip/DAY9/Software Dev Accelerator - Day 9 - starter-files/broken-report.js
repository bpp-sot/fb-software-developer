let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 }
];

let passCount = 0;

for (let i = 0; i <= learners.length; i++) {
  if (learners[i].score >= 50) {
    passCount = passCount + 1;
  }
}

console.log(passCount);

// Your task: find and explain the bug that breaks this loop.
// First: read the loop condition carefully before running anything.
// Second: predict what learners.length equals and what the loop will do.
// Third: run the file and compare the actual error to your prediction.
// Each answer should be a clear, written sentence identifying the bug and why it happens.