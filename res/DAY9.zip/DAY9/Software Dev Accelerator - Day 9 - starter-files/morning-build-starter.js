let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];

// Your task: build a loop that prints each learner's name, then checks who passed.
// First: write a for loop that prints each learner's name only.
// Second: run it and confirm all four names print correctly.
// Third: add an if statement checking score >= 50 inside the loop.
// Each stage should print a clear, correct result before you move to the next one.