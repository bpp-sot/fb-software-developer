let learners = [
  { name: "Amara Musa", score: 72, attendance: 91 },
  { name: "Priya Shah", score: 45, attendance: 88 },
  { name: "Callum Reid", score: 58, attendance: 76 },
  { name: "Fatima Iqbal", score: 39, attendance: 95 }
];

let passCount = 0;
let passNames = [];
let atRiskNames = [];
let totalScore = 0;

// Your task: build one loop that updates all four variables and prints a complete report.
// First: write a for loop counting passes and collecting pass names.
// Second: inside the same loop, collect at-risk names and add to totalScore.
// Third: after the loop, calculate averageScore and print all five results.
// Each printed result should be a clear, correct value matching a hand-worked trace.