let appointments = [
  { patient: "Grace Okoro", waitDays: 12, urgent: true },
  { patient: "Liam Foster", waitDays: 34, urgent: false },
  { patient: "Nadia Hussain", waitDays: 21, urgent: true },
  { patient: "Robert Chen", waitDays: 8, urgent: false }
];

let totalWaitDays = 0;
let overdueUrgent = [];

// Your task: apply the same report pattern to this appointment dataset.
// First: write a for loop adding each waitDays value to totalWaitDays.
// Second: inside the loop, push patients where urgent is true and waitDays > 14 to overdueUrgent.
// Third: print totalWaitDays and overdueUrgent after the loop.
// Each printed result should be a clear, correct value matching a hand-worked check.