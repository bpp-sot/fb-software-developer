// Day 1 learner profile script
// This file already has one commit in its history. You will now make a second change.

let learnerName = "Sam";
let learnerCourse = "Level 4 Software Developer Apprenticeship";

console.log(learnerName + " is studying " + learnerCourse);

// Your task: commit a second, real change to this file with its own clear message.
// First: change the learnerCourse value above to reflect a new course name.
// Second: save the file, then stage and commit the change with a new message.
// Third: run git log to confirm both commits now appear in your project's history.
// Each step should print a clear, helpful message confirming what Git has recorded.