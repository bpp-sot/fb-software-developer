// Your task: use the given function to print the first transaction in the list.
// First: call getFirst with the transactions array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "First transaction:".
// Each label and value should print together, clearly showing the first transaction.

function getFirst(list) {
  return list[0];
}

let transactions = [40, 125, 18, 60];