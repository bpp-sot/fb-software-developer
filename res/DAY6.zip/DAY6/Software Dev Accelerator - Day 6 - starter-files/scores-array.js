// Example: a single named array holding five related score values.

let scores = [72, 65, 90, 48, 81];

console.log(scores);