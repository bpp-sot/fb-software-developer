// Example: an empty array that grows as values are pushed onto it.

let alerts = [];

console.log(alerts.length);

alerts.push("Fridge door open");
alerts.push("Low battery");

console.log(alerts.length);