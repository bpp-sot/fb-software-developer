// Your task: extend this file with one more push and predict the results.
// First: predict the current length and last index before running the file.
// Second: add one more push of a value you choose.
// Third: predict the new length and the new last index, then run to check.
// Each prediction should be confirmed by the printed output.

let failedAttempts = [1, 1, 0];

failedAttempts.push(1);

console.log(failedAttempts.length);
console.