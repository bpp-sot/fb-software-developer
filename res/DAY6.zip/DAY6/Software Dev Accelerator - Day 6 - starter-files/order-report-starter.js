// Your task: complete the weekly order report using the arrays and functions given.
// First: print how many days were recorded using .length with a clear label.
// Second: call getFirst and print the first day's total with a label.
// Third: call getLast and print the last day's total with a label.
// Each fact should print with a clear, correct label so the report reads easily.

function getFirst(list) {
  return list[0];
}

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let dailyOrders = [120, 145, 98, 160, 132];

console.log("Weekly order report");