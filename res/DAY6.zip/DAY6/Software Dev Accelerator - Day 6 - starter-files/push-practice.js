// Your task: add two more items to the basket and report the new count.
// First: use .push to add one more product name to the basket.
// Second: use .push again to add a second product name.
// Third: add a label line and print the new count with .length.
// Each addition should grow the basket, and the printed count should reflect it clearly.

let basket = ["Shampoo", "Towel"];

console.log("Items at start:");
console.log(basket.length);