// Your task: predict what each line below will print, then run the file to check.
// First: write down your predicted output for all four console.log lines.
// Second: run the file and compare the real output to your predictions.
// Third: note any line where your prediction was different, and why.
// Each prediction should be checked against the real, printed value.

let amounts = [40, 125, 9, 300, 15];

console.log(amounts[0]);
console.log(amounts[4]);
console.log(amounts[2]);
console.log(amounts.length);