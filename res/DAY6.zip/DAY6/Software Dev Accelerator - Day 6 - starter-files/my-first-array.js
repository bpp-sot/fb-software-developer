// Your task: create your own array of related values from a sector you know and print it.
// First: choose a context, such as wait times, transaction amounts, or stock levels.
// Second: create an array with a clear, descriptive name and at least four values.
// Third: print the whole array with console.log so all the values show at once.
// Each array should print a clear, complete list of values.