// Your task: edit the code below so it prints three different wait times from the list.
// First: change the second console.log so it prints the third wait time.
// Second: change the third console.log so it prints the last wait time.
// Third: run the file and check three different numbers appear.
// Fourth: write down which index gave you the last value, and why.
// Each console.log should print a different, correct wait time from the array.

let waitTimes = [12, 5, 30, 8, 21];

console.log(waitTimes[0]);
console.log(waitTimes[0]);
console.log(waitTimes[0]);