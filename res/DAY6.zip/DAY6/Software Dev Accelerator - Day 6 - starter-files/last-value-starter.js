// Your task: use the given function to print the most recent reading in the list.
// First: call getLast with the readings array.
// Second: catch the returned value in a clearly named variable.
// Third: print it with a label like "Most recent reading:".
// Each label and value should print together, clearly showing the last reading.

function getLast(list) {
  let lastIndex = list.length - 1;
  return list[lastIndex];
}

let readings = [4, 7, 2, 9, 5];