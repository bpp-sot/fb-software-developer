// Your task: extend this file so it also reports the last stock level in the list.
// First: add a variable that stores the last index using .length minus one.
// Second: add a console.log that prints the last stock level using that index.
// Third: add a clear label line before it, like "Last stock level:".
// Each console.log should print a clear, correctly labelled value.

let stockLevels = [200, 45, 130, 90, 15, 60];

console.log("Number of items:");
console.log(stockLevels.length);